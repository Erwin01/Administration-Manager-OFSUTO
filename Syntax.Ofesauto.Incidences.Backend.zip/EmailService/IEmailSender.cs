﻿using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Services.WebApi.Email
{
    public interface IEmailSender
    {
        void SendEmail(Message message);

        Task SendEmailAsync(Message message);
    }
}
