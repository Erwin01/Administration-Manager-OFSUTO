﻿using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Transversal.EmailService.Interface
{
    public interface IMailService
    {
        Task SendEmailAsync(MailRequest mailRequest);
    }
}
