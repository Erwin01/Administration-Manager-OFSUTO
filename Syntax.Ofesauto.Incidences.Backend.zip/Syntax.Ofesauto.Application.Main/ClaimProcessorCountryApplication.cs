﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class ClaimProcessorCountryApplication : IClaimProcessorCountryApplication
    {
        private readonly IClaimProcessorCountryDomain _repository;
        private readonly IAppLogger<ClaimProcessorCountryApplication> _logger;
        public ClaimProcessorCountryApplication(IClaimProcessorCountryDomain repository,
            IAppLogger<ClaimProcessorCountryApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<ClaimProcessorCountryDTO>> Add(ClaimProcessorCountryDTO obj)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<ClaimProcessorCountryDTO, ClaimProcessorCountry>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.CountryClaimProcessorId = add.CountryClaimProcessorId;
                return Response<ClaimProcessorCountryDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<ClaimProcessorCountryDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.CountryClaimProcessorId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<ClaimProcessorCountryDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<ClaimProcessorCountry, ClaimProcessorCountryDTO>.ConvertList2(ListData);
                return Response<List<ClaimProcessorCountryDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<ClaimProcessorCountryDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<ClaimProcessorCountryDTO>> GetById(int id)
        {
            Response<ClaimProcessorCountryDTO> ListRta = new Response<ClaimProcessorCountryDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<ClaimProcessorCountry, ClaimProcessorCountryDTO>.Convert(ListData);
                return Response<ClaimProcessorCountryDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<ClaimProcessorCountryDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<ClaimProcessorCountryDTO>> GetClaimByCountry(int sourceCountry, int caussantCountry, int openingReasonId)
        {
            try
            {
                var ListData = await _repository.GetByParamFirst(c => c.AccidentCountryId == sourceCountry && c.CauseRegistrationCountryId == caussantCountry
                && c.OpeningReasonId == openingReasonId);
                var data = Infraestructure.Data.AutoMapp<ClaimProcessorCountry, ClaimProcessorCountryDTO>.Convert(ListData);
                return Response<ClaimProcessorCountryDTO>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<ClaimProcessorCountryDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<ResponseClaimsByCountryDto>>> GetListClaimsByCountry()
        {
            try
            {
                var ListData = await _repository.GetListClaimsByCountry();
                var mapp = Infraestructure.Data.AutoMapp<ResponseClaimsByCountry, ResponseClaimsByCountryDto>.ConvertList2(ListData);
                return Response<List<ResponseClaimsByCountryDto>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<ResponseClaimsByCountryDto>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<ClaimProcessorCountryDTO>> Update(ClaimProcessorCountryDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<ClaimProcessorCountryDTO, ClaimProcessorCountry>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<ClaimProcessorCountryDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<ClaimProcessorCountryDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
