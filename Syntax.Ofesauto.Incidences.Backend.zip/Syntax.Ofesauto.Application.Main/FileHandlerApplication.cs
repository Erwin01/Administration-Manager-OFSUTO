﻿using Microsoft.AspNetCore.Http;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    /// <summary>
    /// Esta clase se encargará de guardar los archivos inicialmente en el servidor local
    /// lo ideal es que se pase a azure storage para el almacenamiento de los archivos
    /// </summary>
    public class FileHandlerApplication : IFileHandlerApplication
    {
        /// <summary>
        /// Se crea la variable de tipo interfaz setting application
        /// Esta es la que contiene los metodos a invocar desde donde se requiera almacenar archivos
        /// </summary>
        private IFileUploadApplication _fileHandler;
        private ISettingsApplication _settings;
        /// <summary>
        /// constructor que inyecta la interfaz
        /// </summary>
        /// <param name="settings"></param>
        public FileHandlerApplication(ISettingsApplication settings, IFileUploadApplication fileHandler)
        {
            _settings = settings;
            _fileHandler = fileHandler;
        }
        /// <summary>
        /// Implementación de guardado de archivos multiples
        /// </summary>
        /// <param name="List"></param>
        /// <returns></returns>
        public async Task<Response<List<FileUploadDto>>> SaveAllFiles(List<IFormFile> List)
        {
            var ListResp = new List<FileUploadDto>();
            var folderPath = await _settings.GetByNameSetting("save_folder");
            foreach (var item in List)
            {
                var newItem = new FileUploadDto();
                newItem.SavePath = folderPath.Data.Value;
                var result = await _fileHandler.Upload(item, newItem.SavePath);
                if (result.IsSuccess)
                {
                    newItem.SavePath = result.Data;
                    newItem.file = item;
                    newItem.fileName = item.FileName;
                }
                else
                {
                    newItem.SavePath = string.Empty;
                }
                ListResp.Add(newItem);
            }

            return Response<List<FileUploadDto>>.Sucess(ListResp, "", true);
        }
    }
}
