﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class CommunicationAttachmentsApplication : ICommunicationAttachmentsApplication
    {
        private readonly ICommunicationAttachmentsDomain _repository;
        private readonly IAppLogger<CommunicationAttachmentsApplication> _logger;
        public CommunicationAttachmentsApplication(ICommunicationAttachmentsDomain repository,
            IAppLogger<CommunicationAttachmentsApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<CommunicationAttachmentsDTO>> Add(CommunicationAttachmentsDTO obj)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<CommunicationAttachmentsDTO, CommunicationAttachments>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.CommunicationsHistoryId = add.CommunicationsHistoryId;
                return Response<CommunicationAttachmentsDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<CommunicationAttachmentsDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<CommunicationAttachmentsDTO>>> AddList(List<CommunicationAttachmentsDTO> obj)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<CommunicationAttachmentsDTO, CommunicationAttachments>.ConvertList2(obj);
                var add = await _repository.AddList(mapp);
                var response = Infraestructure.Data.AutoMapp<CommunicationAttachments, CommunicationAttachmentsDTO>.ConvertList2(mapp);
                return Response<List<CommunicationAttachmentsDTO>>.Sucess(response, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<List<CommunicationAttachmentsDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.CommunicationsHistoryId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<CommunicationAttachmentsDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<CommunicationAttachments, CommunicationAttachmentsDTO>.ConvertList2(ListData);
                return Response<List<CommunicationAttachmentsDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<CommunicationAttachmentsDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<CommunicationAttachmentsDTO>> GetById(int id)
        {
            Response<CommunicationAttachmentsDTO> ListRta = new Response<CommunicationAttachmentsDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<CommunicationAttachments, CommunicationAttachmentsDTO>.Convert(ListData);
                return Response<CommunicationAttachmentsDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<CommunicationAttachmentsDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<CommunicationAttachmentsDTO>>> GetByParam(Func<CommunicationAttachmentsDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<Response<CommunicationAttachmentsDTO>> GetByParamFirst(Func<CommunicationAttachmentsDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<CommunicationAttachmentsDTO>> Update(CommunicationAttachmentsDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<CommunicationAttachmentsDTO, CommunicationAttachments>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<CommunicationAttachmentsDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<CommunicationAttachmentsDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
