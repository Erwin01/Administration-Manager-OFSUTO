﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class InternalNoteApplication : IInternalNoteApplication
    {

        private readonly IInternalNoteDomain _repository;


        public InternalNoteApplication(IInternalNoteDomain repository)
        {
            _repository = repository;
        }


        public async Task<Response<InternalNoteDTO>> Add(InternalNoteDTO obj)
        {
            try
            {
                var mapp = AutoMapp<InternalNoteDTO, InternalNote>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.InternalNoteId = add.InternalNoteId;
                return Response<InternalNoteDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<InternalNoteDTO>.Sucess(null, ex.Message, false);
            };
        }


        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.InternalNoteId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public Task<Response<bool>> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<List<InternalNoteDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = AutoMapp<InternalNote, InternalNoteDTO>.ConvertList2(ListData);
                return Response<List<InternalNoteDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<InternalNoteDTO>>.Sucess(null, ex.Message, false);
            }
        }


        public async Task<Response<InternalNoteDTO>> GetById(int id)
        {
            try
            {
                var ListData = await _repository.GetById(id);
                var data = AutoMapp<InternalNote, InternalNoteDTO>.Convert(ListData);
                return Response<InternalNoteDTO>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<InternalNoteDTO>.Sucess(null, ex.Message, false);
            }
        }


        public async Task<Response<InternalNoteDTO>> Update(InternalNoteDTO obj, int id)
        {
            try
            {
                var mapp = AutoMapp<InternalNoteDTO, InternalNote>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<InternalNoteDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<InternalNoteDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
