﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class TypeTrazabilityApplication : ITypeTrazabilityApplication
    {
        private readonly ITypeTrazabilityDomain _repository;
        private readonly IAppLogger<TypeTrazabilityApplication> _logger;
        public TypeTrazabilityApplication(ITypeTrazabilityDomain repository,
            IAppLogger<TypeTrazabilityApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<TypeTrazabilityDTO>> Add(TypeTrazabilityDTO obj)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<TypeTrazabilityDTO, TypeTrazability>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.TypeTrazabilityId = add.TypeTrazabilityId;
                return Response<TypeTrazabilityDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<TypeTrazabilityDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.TypeTrazabilityId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<TypeTrazabilityDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<TypeTrazability, TypeTrazabilityDTO>.ConvertList2(ListData);
                return Response<List<TypeTrazabilityDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<TypeTrazabilityDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<TypeTrazabilityDTO>> GetById(int id)
        {
            Response<TypeTrazabilityDTO> ListRta = new Response<TypeTrazabilityDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<TypeTrazability, TypeTrazabilityDTO>.Convert(ListData);
                return Response<TypeTrazabilityDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<TypeTrazabilityDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<TypeTrazabilityDTO>> GetByNameTypeTrazability(string name)
        {
            Response<TypeTrazabilityDTO> ListRta = new Response<TypeTrazabilityDTO>();
            try
            {

                var ListData = await _repository.GetByParamFirst(c => c.Name == name);
                ListRta.Data = Infraestructure.Data.AutoMapp<TypeTrazability, TypeTrazabilityDTO>.Convert(ListData);
                return Response<TypeTrazabilityDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<TypeTrazabilityDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<TypeTrazabilityDTO>>> GetByParam(Func<TypeTrazabilityDTO, bool> pre)
        {
            throw new NotImplementedException();
        }



        public async Task<Response<TypeTrazabilityDTO>> Update(TypeTrazabilityDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<TypeTrazabilityDTO, TypeTrazability>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<TypeTrazabilityDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<TypeTrazabilityDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
