﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class IncidenceClassifyApplication : IIncidenceClassifyApplication
    {

        private readonly IIncidenceClassifyDomain _repository;


        public IncidenceClassifyApplication(IIncidenceClassifyDomain repository)
        {
            _repository = repository;
        }


        #region [ INSERT ]
        public async Task<Response<IncidenceClassifyDTO>> Add(IncidenceClassifyDTO obj)
        {
            try
            {
                var mapp = AutoMapp<IncidenceClassifyDTO, IncidenceClassify>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.IncidenceClassifyId = add.IncidenceClassifyId;
                return Response<IncidenceClassifyDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IncidenceClassifyDTO>.Sucess(null, ex.Message, false);
            };
        }
        #endregion


        #region [ DELETE ]
        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.IncidenceClassifyId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public Task<Response<bool>> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }
        #endregion


        #region [ GET ALL ]
        public async Task<Response<List<IncidenceClassifyDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = AutoMapp<IncidenceClassify, IncidenceClassifyDTO>.ConvertList2(ListData);
                return Response<List<IncidenceClassifyDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<IncidenceClassifyDTO>>.Sucess(null, ex.Message, false);
            }
        }
        #endregion


        #region [ GET BY ID ]
        public async Task<Response<IncidenceClassifyDTO>> GetById(int id)
        {
            try
            {
                var ListData = await _repository.GetById(id);
                var data = AutoMapp<IncidenceClassify, IncidenceClassifyDTO>.Convert(ListData);
                return Response<IncidenceClassifyDTO>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IncidenceClassifyDTO>.Sucess(null, ex.Message, false);
            }
        }
        #endregion


        #region [ UPDATE ]
        public async Task<Response<IncidenceClassifyDTO>> Update(IncidenceClassifyDTO obj, int id)
        {
            try
            {
                var mapp = AutoMapp<IncidenceClassifyDTO, IncidenceClassify>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<IncidenceClassifyDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IncidenceClassifyDTO>.Sucess(null, ex.Message, false);
            }
        }
        #endregion
    }
}
