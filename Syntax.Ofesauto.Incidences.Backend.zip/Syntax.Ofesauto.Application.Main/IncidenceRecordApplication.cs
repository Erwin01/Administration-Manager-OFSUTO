﻿using AutoMapper;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class IncidenceRecordApplication : IIncidenceRecordApplication
    {

        private readonly IIncidenceRecordDomain _repository;
        private readonly IMapper _mapper;

        public IncidenceRecordApplication(IIncidenceRecordDomain repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        #region [ INSERT ]
        public async Task<Response<IncidenceRecordDTO>> Add(IncidenceRecordDTO obj)
        {
            try
            {
                //var mapp = AutoMapp<IncidenceRecordDTO, IncidenceRecord>.Convert(obj);
                //var mapp = _mapper.Map<IncidenceRecordDTO, IncidenceRecord>(obj);

                IncidenceRecord ObjSave = new IncidenceRecord();
                ObjSave.IncidenceRecordId = obj.IncidenceRecordId;
                ObjSave.IncidenceRecordNumber = $"{ObjSave.IncidenceRecordId}{DateTime.Now.Day}{DateTime.Now.Year}";
                ObjSave.IncidenceAccidentDate = obj.IncidenceAccidentDate;
                ObjSave.IncidenceCauseVehicleRegistration = obj.IncidenceCauseVehicleRegistration;
                ObjSave.IncidenceAffectedVehicleRegistration = obj.IncidenceAffectedVehicleRegistration;
                ObjSave.IncidenceRecordName = obj.IncidenceRecordName;
                ObjSave.IncidenceRecordLastName = obj.IncidenceRecordLastName;
                ObjSave.IncidenceDateHigh = obj.IncidenceAccidentDate;
                ObjSave.IncidenceClaimManagerId = obj.IncidenceClaimManagerId;
                ObjSave.IncidenceOrganismId = obj.IncidenceOrganismId;
                ObjSave.IncidenceClaimProcessorId = obj.IncidenceClaimProcessorId;
                ObjSave.IncidenceOfesautoStateId = obj.IncidenceOfesautoStateId;
                ObjSave.IncidenceRecordStateDate = obj.IncidenceRecordStateDate;
                ObjSave.OfesautoStatesId = obj.OfesautoStatesId;
                ObjSave.UserId = obj.UserId;
                ObjSave.IncidenceRecordType = AutoMapp<IncidenceRecordTypeDTO, IncidenceRecordType>.ConvertList2(obj.IncidenceRecordType);

                var add = await _repository.Add(ObjSave);

                add.IncidenceRecordNumber = add.IncidenceRecordId.ToString().Length == 1 ? $"0{add.IncidenceRecordId}" : $"{add.IncidenceRecordId}";
                add.IncidenceRecordNumber = add.IncidenceRecordNumber + (DateTime.Now.Month.ToString().Length == 1 ? $"0{DateTime.Now.Month}{DateTime.Now.Year}" : $"{DateTime.Now.Month}{DateTime.Now.Year}").ToString();
                add = await _repository.Update(add, add.IncidenceRecordId);
                obj.IncidenceRecordId = add.IncidenceRecordId;

                return Response<IncidenceRecordDTO>.Sucess(obj, "Success", true);

            }
            catch (Exception ex)
            {
                return Response<IncidenceRecordDTO>.Sucess(null, ex.Message, false);
            };
        }
        #endregion


        #region [ DELETE ]
        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.IncidenceRecordId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        /// <summary>
        /// Delete By State
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Response<bool>> DeleteLogicalByState(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.IncidenceRecordId > 0)
                {
                    await _repository.DeleteLogicalByState(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }
        #endregion


        #region [ GET ALL ]
        public async Task<Response<List<IncidenceRecordDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAllIncidences();
                var ListRta = new List<IncidenceRecordDTO>(); 
                foreach (var obj in ListData)
                {
                    var ObjSave = new IncidenceRecordDTO();

                    ObjSave.IncidenceAccidentDate = obj.IncidenceAccidentDate;
                    ObjSave.IncidenceAffectedVehicleRegistration = obj.IncidenceAffectedVehicleRegistration;
                    ObjSave.IncidenceCauseVehicleRegistration = obj.IncidenceCauseVehicleRegistration;
                    ObjSave.IncidenceClaimManagerId = obj.IncidenceClaimManagerId;
                    ObjSave.IncidenceClaimProcessorId = obj.IncidenceClaimProcessorId;
                    ObjSave.IncidenceDateHigh = obj.IncidenceDateHigh;
                    ObjSave.IncidenceOfesautoStateId = obj.IncidenceOfesautoStateId;
                    ObjSave.IncidenceOrganismId = obj.IncidenceOrganismId;
                    ObjSave.IncidenceRecordId = obj.IncidenceRecordId;
                    ObjSave.IncidenceRecordLastName = obj.IncidenceRecordLastName;
                    ObjSave.IncidenceRecordName = obj.IncidenceRecordName;
                    ObjSave.IncidenceRecordNumber = obj.IncidenceRecordNumber;
                    ObjSave.IncidenceRecordStateDate = obj.IncidenceRecordStateDate;
                    ObjSave.UserId = obj.UserId;
                    ObjSave.IncidenceRecordType = AutoMapp<IncidenceRecordType,IncidenceRecordTypeDTO>.ConvertList2(obj.IncidenceRecordType);
                    ListRta.Add(ObjSave);
                }
                //var mapp = AutoMapp<IncidenceRecord, IncidenceRecordDTO>.ConvertList2(ListData);
                return Response<List<IncidenceRecordDTO>>.Sucess(ListRta, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<IncidenceRecordDTO>>.Sucess(null, ex.Message, false);
            }
        }
        #endregion


        #region [ GET BY ID ]
        public async Task<Response<IncidenceRecordDTO>> GetById(int id)
        {
            try
            {
                var data = await _repository.GetIncidenceById(id);
                //var data = AutoMapp<IncidenceRecord, IncidenceRecordDTO>.Convert(ListData);

                IncidenceRecordDTO ObjSave = new IncidenceRecordDTO();

                //ObjSave = AutoMapp<IncidenceRecord, IncidenceRecordDTO>.Convert(data);
                
                ObjSave.IncidenceAccidentDate = data.IncidenceAccidentDate;
                ObjSave.IncidenceAffectedVehicleRegistration = data.IncidenceAffectedVehicleRegistration;
                ObjSave.IncidenceCauseVehicleRegistration = data.IncidenceCauseVehicleRegistration;
                ObjSave.IncidenceClaimManagerId = data.IncidenceClaimManagerId;
                ObjSave.IncidenceClaimProcessorId = data.IncidenceClaimProcessorId;
                ObjSave.IncidenceOfesautoStateId = data.IncidenceOfesautoStateId;
                ObjSave.IncidenceOrganismId = data.IncidenceOrganismId;
                ObjSave.IncidenceRecordId = data.IncidenceRecordId;
                ObjSave.IncidenceRecordLastName = data.IncidenceRecordLastName;
                ObjSave.IncidenceDateHigh = data.IncidenceDateHigh;
                ObjSave.IncidenceRecordName = data.IncidenceRecordName;
                ObjSave.IncidenceRecordNumber = data.IncidenceRecordNumber;
                ObjSave.IncidenceRecordStateDate = data.IncidenceRecordStateDate;
                ObjSave.UserId = data.UserId;
                ObjSave.IncidenceRecordType = AutoMapp<IncidenceRecordType, IncidenceRecordTypeDTO>.ConvertList2(data.IncidenceRecordType);

                return Response<IncidenceRecordDTO>.Sucess(ObjSave, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IncidenceRecordDTO>.Sucess(null, ex.Message, false);
            }
        }

        public Task<Response<List<HistoryIncidentDTO>>> GetTrazibilityById(int incidenceId)
        {
            throw new NotImplementedException();
        }

        //public async Task<Response<List<HistoryIncidentDTO>>> GetTrazibilityIncidenceById(int incidenceId)
        //{
        //    try
        //    {
        //        var ListData = await _repository.GetTrazabilityIncidenceById(incidenceId);
        //        var mapp = Infraestructure.Data.AutoMapp<HistoryIncident, HistoryIncidentDTO>.ConvertList2(ListData);
        //        return Response<List<HistoryIncidentDTO>>.Sucess(mapp, "Success", true);
        //    }

        //    catch (Exception ex)
        //    {

        //        return Response<List<HistoryIncidentDTO>>.Error(null, ex, ex.Message, false);

        //    }
        //}
        #endregion


        #region [ UPDATE ]
        public async Task<Response<IncidenceRecordDTO>> Update(IncidenceRecordDTO obj, int id)
        {
            try
            {
                //var mapp = AutoMapp<IncidenceRecordDTO, IncidenceRecord>.Convert(obj);
                //var add = await _repository.Update(mapp, id);
                IncidenceRecord ObjSave = new IncidenceRecord();
                ObjSave.IncidenceRecordId = obj.IncidenceRecordId;
                ObjSave.IncidenceRecordNumber = $"{ObjSave.IncidenceRecordId}{DateTime.Now.Day}{DateTime.Now.Year}";
                ObjSave.IncidenceDateHigh = obj.IncidenceDateHigh;
                ObjSave.IncidenceAccidentDate = obj.IncidenceAccidentDate;
                ObjSave.IncidenceAffectedVehicleRegistration = obj.IncidenceAffectedVehicleRegistration;
                ObjSave.IncidenceCauseVehicleRegistration = obj.IncidenceCauseVehicleRegistration;
                ObjSave.IncidenceClaimManagerId = obj.IncidenceClaimManagerId;
                ObjSave.IncidenceClaimProcessorId = obj.IncidenceClaimProcessorId;
                ObjSave.IncidenceOfesautoStateId = obj.IncidenceOfesautoStateId;
                ObjSave.IncidenceOrganismId = obj.IncidenceOrganismId;
                ObjSave.IncidenceRecordName = obj.IncidenceRecordName;
                ObjSave.IncidenceRecordLastName = obj.IncidenceRecordLastName;
                ObjSave.IncidenceRecordStateDate = obj.IncidenceRecordStateDate;
                ObjSave.OfesautoStatesId = obj.OfesautoStatesId;
                ObjSave.UserId = obj.UserId;
                ObjSave.IncidenceRecordType = AutoMapp<IncidenceRecordTypeDTO, IncidenceRecordType>.ConvertList2(obj.IncidenceRecordType);

                var add = await _repository.Add(ObjSave);

                add.IncidenceRecordNumber = add.IncidenceRecordId.ToString().Length == 1 ? $"0{add.IncidenceRecordId}" : $"{add.IncidenceRecordId}";
                add.IncidenceRecordNumber = add.IncidenceRecordNumber + (DateTime.Now.Month.ToString().Length == 1 ? $"0{DateTime.Now.Month}{DateTime.Now.Year}" : $"{DateTime.Now.Month}{DateTime.Now.Year}").ToString();
                add = await _repository.Update(add, add.IncidenceRecordId);
                obj.IncidenceRecordId = add.IncidenceRecordId;

                return Response<IncidenceRecordDTO>.Sucess(obj, "Success", true);

            }
            catch (Exception ex)
            {
                return Response<IncidenceRecordDTO>.Sucess(null, ex.Message, false);
            }
        }
        #endregion

    }
}
