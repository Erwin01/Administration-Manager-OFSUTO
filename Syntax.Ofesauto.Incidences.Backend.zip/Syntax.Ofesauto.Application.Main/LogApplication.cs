﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class LogApplication : ILogApplication
    {
        private readonly ILogDomain _repository;
        private readonly IAppLogger<LogApplication> _logger;
        public LogApplication(ILogDomain repository,
            IAppLogger<LogApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<LogDTO>> Add(LogDTO obj)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<LogDTO, IssuesLog>.Convert(obj);
                var add = await _repository.Add(mapp);

                // obj.LogId = add.LogId;
                return Response<LogDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<LogDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.LogId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<LogDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<IssuesLog, LogDTO>.ConvertList2(ListData);
                return Response<List<LogDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<LogDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<LogDTO>> GetById(int id)
        {
            Response<LogDTO> ListRta = new Response<LogDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<IssuesLog, LogDTO>.Convert(ListData);
                return Response<LogDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<LogDTO>.Sucess(null, ex.Message, false);
            }
        }



        public async Task<Response<List<LogDTO>>> GetByParam(Func<LogDTO, bool> pre)
        {
            throw new NotImplementedException();
        }



        public async Task<Response<LogDTO>> Update(LogDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<LogDTO, IssuesLog>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<LogDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<LogDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
