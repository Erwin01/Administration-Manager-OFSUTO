﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class IncidenceTypeApplication : IIncidenceTypeApplication
    {

        private readonly IIncidenceTypeDomain _repository;


        public IncidenceTypeApplication(IIncidenceTypeDomain repository)
        {
            _repository = repository;
        }

        #region [ INSERT ]
        public async Task<Response<IncidenceTypeDTO>> Add(IncidenceTypeDTO obj)
        {
            try
            {
                var mapp = AutoMapp<IncidenceTypeDTO, IncidenceType>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.IncidenceTypeId = add.IncidenceTypeId;
                return Response<IncidenceTypeDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IncidenceTypeDTO>.Sucess(null, ex.Message, false);
            };
        }
        #endregion


        #region [ DELETE ]
        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.IncidenceTypeId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public Task<Response<bool>> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }
        #endregion


        #region [ GET ALL ]
        public async Task<Response<List<IncidenceTypeDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = AutoMapp<IncidenceType, IncidenceTypeDTO>.ConvertList2(ListData);
                return Response<List<IncidenceTypeDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<IncidenceTypeDTO>>.Sucess(null, ex.Message, false);
            }
        }
        #endregion


        #region [ GET BY ID ]
        public async Task<Response<IncidenceTypeDTO>> GetById(int id)
        {
            try
            {
                var ListData = await _repository.GetById(id);
                var data = AutoMapp<IncidenceType, IncidenceTypeDTO>.Convert(ListData);
                return Response<IncidenceTypeDTO>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IncidenceTypeDTO>.Sucess(null, ex.Message, false);
            }
        }
        #endregion


        #region [ UPDATE ]
        public async Task<Response<IncidenceTypeDTO>> Update(IncidenceTypeDTO obj, int id)
        {
            try
            {
                var mapp = AutoMapp<IncidenceTypeDTO, IncidenceType>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<IncidenceTypeDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IncidenceTypeDTO>.Sucess(null, ex.Message, false);
            }
        }
        #endregion
    }
}
