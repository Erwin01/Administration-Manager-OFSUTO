﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class SettingsApplication : ISettingsApplication
    {
        private readonly ISettingsDomain _repository;
        private readonly IAppLogger<SettingsApplication> _logger;
        public SettingsApplication(ISettingsDomain repository,
            IAppLogger<SettingsApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<SettingsDTO>> Add(SettingsDTO obj)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<SettingsDTO, Settings>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.SettingId = add.SettingId;
                return Response<SettingsDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<SettingsDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.SettingId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<SettingsDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<Settings, SettingsDTO>.ConvertList2(ListData);
                return Response<List<SettingsDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<SettingsDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<SettingsDTO>> GetById(int id)
        {
            Response<SettingsDTO> ListRta = new Response<SettingsDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<Settings, SettingsDTO>.Convert(ListData);
                return Response<SettingsDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<SettingsDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<SettingsDTO>> GetByNameSetting(string name)
        {
            Response<SettingsDTO> ListRta = new Response<SettingsDTO>();
            try
            {

                var ListData = await _repository.GetByParamFirst(c => c.Name == name);
                ListRta.Data = Infraestructure.Data.AutoMapp<Settings, SettingsDTO>.Convert(ListData);
                return Response<SettingsDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<SettingsDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<SettingsDTO>>> GetByParam(Func<SettingsDTO, bool> pre)
        {
            throw new NotImplementedException();
        }



        public async Task<Response<SettingsDTO>> Update(SettingsDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<SettingsDTO, Settings>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<SettingsDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<SettingsDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
