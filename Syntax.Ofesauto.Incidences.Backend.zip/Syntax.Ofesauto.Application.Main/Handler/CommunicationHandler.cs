﻿namespace Syntax.Ofesauto.Incidence.Application.Main.Handler
{
    public class CommunicationHandler
    {

    }
}
