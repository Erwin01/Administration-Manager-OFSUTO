﻿using System.Collections.Generic;
using System.Net.Mail;
namespace Syntax.Ofesauto.Incidence.Application.Main.Handler
{
    public class SendMailHandler
    {
        public void SendMail(string body, List<Attachment> attachment)
        {

        }

    }
}
