﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class DataTypeApplication : IDataTypeApplication
    {

        private readonly IDataTypeDomain _repository;


        public DataTypeApplication(IDataTypeDomain repository)
        {
            _repository = repository;
        }


        #region [ INSERT ]
        public async Task<Response<DataTypesDTO>> Add(DataTypesDTO obj)
        {
            try
            {
                var mapp = AutoMapp<DataTypesDTO, DataTypes>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.DataTypeId = add.DataTypeId;
                return Response<DataTypesDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<DataTypesDTO>.Sucess(null, ex.Message, false);
            };
        }
        #endregion


        #region [ DELETE ]
        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.DataTypeId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public Task<Response<bool>> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }
        #endregion


        #region [ GET ALL ]
        public async Task<Response<List<DataTypesDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = AutoMapp<DataTypes, DataTypesDTO>.ConvertList2(ListData);
                return Response<List<DataTypesDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<DataTypesDTO>>.Sucess(null, ex.Message, false);
            }
        }
        #endregion


        #region [ GET BY ID ]
        public async Task<Response<DataTypesDTO>> GetById(int id)
        {
            try
            {
                var ListData = await _repository.GetById(id);
                var data = AutoMapp<DataTypes, DataTypesDTO>.Convert(ListData);
                return Response<DataTypesDTO>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<DataTypesDTO>.Sucess(null, ex.Message, false);
            }
        }
        #endregion


        #region [ UPDATE ]
        public async Task<Response<DataTypesDTO>> Update(DataTypesDTO obj, int id)
        {
            try
            {
                var mapp = AutoMapp<DataTypesDTO, DataTypes>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<DataTypesDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<DataTypesDTO>.Sucess(null, ex.Message, false);
            }
        }
        #endregion
    }
}
