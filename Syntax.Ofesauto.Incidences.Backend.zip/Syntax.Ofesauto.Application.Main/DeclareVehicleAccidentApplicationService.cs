﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class DeclareVehicleAccidentApplicationService : IDeclareVehicleAccident_Application
    {
        private readonly IDeclareVehicleAccident _repository;
        private readonly IUserApplication _IUserApplication;
        private readonly IOfesautoProcessApplication _ofesautoProcess;
        private readonly IActionsHistoryApplication _ActionHistory;
        private readonly IClaimProcessorCountryApplication _claimProcessorCountryApplication;
        private readonly IAppLogger<DeclareVehicleAccidentApplicationService> _logger;
        private readonly CustomDataContext _ctx;
        public DeclareVehicleAccidentApplicationService(IDeclareVehicleAccident repository,
                                             IAppLogger<DeclareVehicleAccidentApplicationService> appLogger,
                                             CustomDataContext ctx,
                                             IActionsHistoryApplication actionHistoryApplication,
                                             IClaimProcessorCountryApplication claimProcessorCountryApplication,
                                             IUserApplication userApplication,
                                             IOfesautoProcessApplication ofesautoProcess
                                             )
        {
            _ctx = ctx;
            _repository = repository;
            _logger = appLogger;
            _ActionHistory = actionHistoryApplication;
            _claimProcessorCountryApplication = claimProcessorCountryApplication;
            _ofesautoProcess = ofesautoProcess;
            _IUserApplication = userApplication;

        }

        public async Task<Response<DeclareVehicleAccidentDTO>> Add(DeclareVehicleAccidentDTO obj)
        {

            try
            {
                //using (var trans = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                //{
                var success = false;
                var claim = await _claimProcessorCountryApplication.GetClaimByCountry(obj.AccidentCountryId, obj.CauseCountryRegistrationId, obj.ReasonForOpeningId);
                if (claim.Data != null) { obj.ClaimsProcessorId = claim.Data.CountryClaimProcessorId; } else { obj.ClaimsProcessorId = null; };
                var mapp = Infraestructure.Data.AutoMapp<DeclareVehicleAccidentDTO, DeclareVehicleAccident>.Convert(obj);
                var add = await _repository.Add(mapp);
                obj.DeclareVehicleAccidentId = add.DeclareVehicleAccidentId;
                if (obj.DeclareVehicleAccidentId > 0)
                {
                    var actionHistory = new ActionsHistoryDTO(obj.DeclareVehicleAccidentId, obj.UserId, 1, obj.ReasonForOpeningId == 1 ? 1 : 2, obj.ClaimsProcessorId, obj.Files, obj.EmailSender, string.Empty, true);
                    var resulthist = await _ActionHistory.Add(actionHistory);
                    if (resulthist.IsSuccess)
                    {
                        success = true;
                        //return Response<DeclareVehicleAccidentDTO>.Sucess(obj, "record save!", success);
                    }
                    else
                    {

                    }

                }
                //trans.Dispose();
                //}

                return Response<DeclareVehicleAccidentDTO>.Sucess(obj, "Successful query", success);
            }
            //catch (TransactionAbortedException ex)
            //{
            //    _logger.LogError(ex.Message);
            //    return Response<DeclareVehicleAccidentDTO>.Sucess(obj, ex.Message, false);
            //}
            catch (Exception ex)
            {

                _logger.LogError(ex.Message);
                return Response<DeclareVehicleAccidentDTO>.Sucess(obj, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {

                var add = await _repository.GetById(id);

                if (add.DeclareVehicleAccidentId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", true);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
                _logger.LogError(ex.Message);
                return response;
            }
        }

        public async Task<Response<List<DeclareVehicleAccidentDTO>>> GetAll()
        {
            Response<List<DeclareVehicleAccidentDTO>> ListRta = new Response<List<DeclareVehicleAccidentDTO>>();
            try
            {
                var ListData = await _repository.GetAll();
                ListData = ListData.OrderByDescending(c => c.DeclareVehicleAccidentId).ToList();
                ListRta.Data = Infraestructure.Data.AutoMapp<DeclareVehicleAccident, DeclareVehicleAccidentDTO>.ConvertList2(ListData);
                return Response<List<DeclareVehicleAccidentDTO>>.Sucess(ListRta.Data, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<List<DeclareVehicleAccidentDTO>>.Sucess(null, ex.Message, false);
            }
        }

        /// <summary>
        /// Method for get all records to table  DeclareVehicleAccident by user
        /// With trazability-> ActionHistory->CommunicationsHistory-> CommunicationsAttachments
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<Response<List<DeclareVehicleAccidentDTO>>> GetAllWithTrazabilityByUserId(int userId)
        {
            Response<List<DeclareVehicleAccidentDTO>> ListRta = new Response<List<DeclareVehicleAccidentDTO>>();
            try
            {
                var ListData = await _repository.GetByParam(c => c.UserId == userId);
                //var data = await _ctx.ResponseSpDeclareVehicleAccident.FromSqlInterpolated($"GetDeclareAccidentTrazability {userId}").ToListAsync();
                ListData = ListData.OrderByDescending(c => c.DeclareVehicleAccidentId).ToList();

                var ListTemp = Infraestructure.Data.AutoMapp<DeclareVehicleAccident, DeclareVehicleAccidentDTO>.ConvertList2(ListData);
                ListTemp = await GetTrazability(ListTemp);
                ListRta.Data = ListTemp;
                return Response<List<DeclareVehicleAccidentDTO>>.Sucess(ListRta.Data, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<List<DeclareVehicleAccidentDTO>>.Sucess(null, ex.Message, false);
            }
        }

        /// <summary>
        /// Method for get all records to table  DeclareVehicleAccident
        /// With trazability-> ActionHistory->CommunicationsHistory-> CommunicationsAttachments
        /// </summary>
        /// <returns></returns>
        public async Task<Response<List<DeclareVehicleAccidentDTO>>> GetAllWithTrazability()
        {
            Response<List<DeclareVehicleAccidentDTO>> ListRta = new Response<List<DeclareVehicleAccidentDTO>>();
            try
            {
                var ListData = await _repository.GetAll();
                ListData = ListData.OrderBy(c => c.DeclareVehicleAccidentId).ToList();
                var ListTemp = Infraestructure.Data.AutoMapp<DeclareVehicleAccident, DeclareVehicleAccidentDTO>.ConvertList2(ListData);
                ListTemp = await GetTrazability(ListTemp);
                ListRta.Data = ListTemp;
                return Response<List<DeclareVehicleAccidentDTO>>.Sucess(ListRta.Data, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<List<DeclareVehicleAccidentDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<List<DeclareVehicleAccidentDTO>> GetTrazability(List<DeclareVehicleAccidentDTO> ListTemp)
        {
            foreach (var item in ListTemp)
            {
                var ListAttachments = await _ctx.ActionsHistory
                .Where(c => c.IdentificationRegister == item.DeclareVehicleAccidentId).ToListAsync();
                var ListActionHistoryDTO = Infraestructure.Data.AutoMapp<ActionsHistory, ActionsHistoryDTO>.ConvertList2(ListAttachments);
                foreach (var itemAttach in ListActionHistoryDTO)
                {
                    var actionType = await (from at in _ctx.ActionType
                                            where at.ActionTypeId == itemAttach.ActionTypeId
                                            select new
                                            {
                                                ActionTypeName = at.ActionTypeName,
                                            }).FirstOrDefaultAsync();
                    var Comm = await (from c in _ctx.CommunicationsHistory
                                      where c.ActionHistoryId == itemAttach.ActionHistoryId
                                      select new CommunicationsHistoryDTO
                                      {
                                          CommunicationSubject = c.CommunicationSubject,
                                          CommunicationId = c.CommunicationId,
                                          CommunicationText = c.CommunicationText
                                      }).ToListAsync();
                    foreach (var ItemComm in Comm)
                    {
                        itemAttach.CommunicationAttachments = await (from ca in _ctx.CommunicationAttachments
                                                                     where (ca.CommunicationsHistoryId == ItemComm.CommunicationId)
                                                                     select new CommunicationAttachmentsDTO
                                                                     {
                                                                         AttachmentId = ca.AttachmentId,
                                                                         CommunicationsHistoryId = ca.CommunicationsHistoryId,
                                                                         AttachmentDate = ca.AttachmentDate,
                                                                         AttachmentFileName = ca.AttachmentFileName,
                                                                         AttachmentPath = ca.AttachmentPath,
                                                                         AttachmentDescription = ca.AttachmentDescription,
                                                                         CreateDate = ca.CreateDate,
                                                                         UpdateDate = ca.UpdateDate
                                                                     }).ToListAsync();
                    }

                    itemAttach.ActionType = actionType.ActionTypeName;
                    if (Comm.Count > 0)
                    {
                        itemAttach.SubjectCommunication = Comm.FirstOrDefault().CommunicationSubject;
                        itemAttach.Message = Comm.FirstOrDefault().CommunicationText;
                    }
                    var user = await _IUserApplication.GetById(item.UserId);
                    if (user.Data != null)
                    {
                        switch (user.Data.UserTypeId)
                        {
                            case 3:
                                itemAttach.MadeBy = "Tramitador";
                                break;
                            case 4:
                                itemAttach.MadeBy = "Reclamante";
                                break;
                            default:
                                itemAttach.MadeBy = "Admin";
                                break;
                        }
                    }
                    var type = await _ofesautoProcess.GetById(itemAttach.OfesautoProcessId);
                    itemAttach.Trazability = type.Data.Name;

                }

                item.ActionHistory = ListActionHistoryDTO;
            }


            return ListTemp;
        }
        public async Task<Response<DeclareVehicleAccidentDTO>> GetById(int id)
        {
            Response<DeclareVehicleAccidentDTO> ListRta = new Response<DeclareVehicleAccidentDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<DeclareVehicleAccident, DeclareVehicleAccidentDTO>.Convert(ListData);
                return Response<DeclareVehicleAccidentDTO>.Sucess(ListRta.Data, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<DeclareVehicleAccidentDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<DeclareVehicleAccidentDTO>> Update(DeclareVehicleAccidentDTO obj, int id)
        {
            var response = new Response<DeclareVehicleAccidentDTO>();
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<DeclareVehicleAccidentDTO, DeclareVehicleAccident>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                response.Data = obj;
                return Response<DeclareVehicleAccidentDTO>.Sucess(response.Data, "Successful query", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<DeclareVehicleAccidentDTO>.Sucess(null, ex.Message, false);
            }
        }
        /// <summary>
        /// Get records to be classified and asign proccessor
        /// </summary>
        /// <returns></returns>
        public async Task<Response<List<ResponseRecorByClasificationDTO>>> GetRecordsToBeClassified()
        {
            try
            {
                var ListData = await _ctx.ResponseRecorByClasification.FromSqlInterpolated($"GetRecordByClasification").ToListAsync();
                var ListTemp = Infraestructure.Data.AutoMapp<ResponseRecorByClasification, ResponseRecorByClasificationDTO>.ConvertList2(ListData);
                return Response<List<ResponseRecorByClasificationDTO>>.Sucess(ListTemp, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<List<ResponseRecorByClasificationDTO>>.Sucess(null, ex.Message, false);
            }
        }
        /// <summary>
        /// get history to records in declarevehicleaccident table
        /// </summary>
        /// <returns></returns>
        public async Task<Response<List<ResponseRecorByClasificationDTO>>> GetRecordsHistory()
        {
            try
            {
                var ListData = await _ctx.ResponseRecorByClasification.FromSqlInterpolated($"GetRecordHistory").ToListAsync();
                var ListTemp = Infraestructure.Data.AutoMapp<ResponseRecorByClasification, ResponseRecorByClasificationDTO>.ConvertList2(ListData);
                return Response<List<ResponseRecorByClasificationDTO>>.Sucess(ListTemp, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<List<ResponseRecorByClasificationDTO>>.Sucess(null, ex.Message, false);
            }
        }
        /// <summary>
        /// reject claim by proccesor
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Response<bool>> RejectClaim(RejectClaimDTO obj)
        {
            try
            {
                var result = false;
                var Data = await _repository.GetById(obj.ClaimId);
                if (Data.DeclareVehicleAccidentId > 0)
                {
                    Data.StateId = 4;
                    var rt = await _repository.Update(Data, obj.ClaimId);
                    result = true;
                    var actionHistory = new ActionsHistoryDTO(Data.DeclareVehicleAccidentId, Data.UserId, obj.OffesautoProcessId, obj.ActionTypeId, Data.ClaimsProcessorId, null, obj.Email, obj.Observations);
                    var resulthist = await _ActionHistory.Add(actionHistory);
                    if (resulthist.IsSuccess)
                    {
                        return Response<bool>.Sucess(result, "record save!", true);
                    }
                }
                return Response<bool>.Sucess(result, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }

        }


        public async Task<Response<bool>> AssignClaim(AssignClaimDTO obj)
        {
            try
            {

                var result = false;
                var Data = await _repository.GetById(obj.ClaimId);

                if (Data.DeclareVehicleAccidentId > 0)
                {
                    Data.ClaimsProcessorId = obj.ProcessorId;
                    var rt = await _repository.Update(Data, obj.ClaimId);
                    result = true;
                    var actionHistory = new ActionsHistoryDTO(Data.DeclareVehicleAccidentId, Data.UserId, obj.OffesautoProcessId, obj.ActionTypeId, Data.ClaimsProcessorId, null, obj.Email, "");
                    var resulthist = await _ActionHistory.Add(actionHistory);
                    if (resulthist.IsSuccess)
                    {
                        return Response<bool>.Sucess(result, "record save!", true);
                    }
                }
                return Response<bool>.Sucess(result, "Successful query", true);
            }
            catch (Exception ex)
            {
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }
    }
}
