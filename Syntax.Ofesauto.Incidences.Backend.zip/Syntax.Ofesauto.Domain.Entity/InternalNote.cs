﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class InternalNote : DefaultEntity
    {

        [Key]
        public int InternalNoteId { get; set; }
        [Required]
        public int OfesautoProcessId { get; set; }
        [Required]
        public int IdentificationRegister { get; set; }
        public string Description { get; set; }

    }
}
