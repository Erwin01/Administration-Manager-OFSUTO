﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class IncidenceClassify : DefaultEntity
    {

        [Key]
        public int IncidenceClassifyId { get; set; }
        [Required]
        [MaxLength(50)]
        [MinLength(5)]
        public string IncidenceClassifyName { get; set; }
        [MaxLength(50)]
        [MinLength(5)]
        public string IncidenceClassifyNamEnglish { get; set; }
        [MaxLength(50)]
        [MinLength(5)]
        public string IncidenceClassifyDescription { get; set; }
        public bool IsDeleted { get; set; }

        

    }
}
