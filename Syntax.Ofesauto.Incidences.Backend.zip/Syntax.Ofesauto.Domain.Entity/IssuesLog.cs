﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class IssuesLog
    {
        [Key]
        public int LogId { get; set; }

        //[StringLength(128)]
        [MaxLength(150)]
        public string Source { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        [MaxLength(150)]
        //[StringLength(220)]
        public string Type { get; set; }
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        [Required]
        public DateTime CreatedOnDate { get; set; }
    }
}
