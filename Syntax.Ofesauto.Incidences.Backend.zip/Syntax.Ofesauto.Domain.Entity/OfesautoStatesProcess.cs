﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class OfesautoStatesProcess
    {

        [Key]
        public int OfesautoStatesProcessId { get; set; }

        public int OfesautoProcessId { get; set; }

        public int OfesautoStateId { get; set; }
        
        [ForeignKey("OfesautoStateId")]
        public OfesautoStates OfesautoStates { get; set; }

        [ForeignKey("OfesautoProcessId")]
        public OfesautoProcess OfesautoProcess { get; set; }

    }
}
