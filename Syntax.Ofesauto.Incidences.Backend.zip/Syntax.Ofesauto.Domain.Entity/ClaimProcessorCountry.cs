﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class ClaimProcessorCountry
    {
        [Key]
        [Required]
        public int CountryClaimProcessorId { get; set; }
        [Required]
        public int ClaimProcessorId { get; set; }
        [Required]
        public int AccidentCountryId { get; set; }
        [Required]
        public int CauseRegistrationCountryId { get; set; }
        [Required]
        public int OpeningReasonId { get; set; }
        public int UserId { get; set; } = 0;
        [Required]
        public DateTime CreateDate { get; set; }
        [Required]
        public DateTime UpdateDate { get; set; }

    }
}
