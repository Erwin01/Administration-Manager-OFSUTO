﻿using Microsoft.EntityFrameworkCore;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    ///  [Keyless]
    ///  
    [Keyless]
    public class ResponseSpDeclareVehicleAccident
    {
        public string data { get; set; }
    }
}
