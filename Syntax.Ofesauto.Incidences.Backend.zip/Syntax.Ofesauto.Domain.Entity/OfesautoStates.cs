﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class OfesautoStates : DefaultEntity
    {

        [Key]
        public int OfesautoStatesId { get; set; }

        [MaxLength(20)]
        [MinLength(5)]
        public string OfesautoStatesName { get; set; }

        [MaxLength(20)]
        [MinLength(5)]
        public string OfesautoStatesNamEnglish { get; set; }

        [MaxLength(20)]
        [MinLength(5)]
        public string OfesautoStatesDescription { get; set; }

        public List<OfesautoStatesProcess> OfesautoStatesProcess { get; set; }

        public List<IncidenceRecord> IncidenceRecords { get; set; }
    }
}
