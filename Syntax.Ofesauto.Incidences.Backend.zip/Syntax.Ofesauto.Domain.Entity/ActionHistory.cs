﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class ActionsHistory
    {
        [Key]
        [Required]
        public int ActionHistoryId { get; set; }
        [Required]
        public int OfesautoProcessId { get; set; }
        [Required]
        public int IdentificationRegister { get; set; }
        [Required]
        public int? StateId { get; set; }
        public string Observations { get; set; }
        [Required]
        public int UserId { get; set; }
        [Required]
        public int ActionTypeId { get; set; }
        public int? ClaimProcessorId { get; set; }
        public DateTime ActionDate { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        //public virtual DeclareVehicleAccident DeclareVehicleAccident { get; set; }
        [ForeignKey("ActionTypeId")]
        public ActionType ActionType { get; set; }

        [ForeignKey("OfesautoProcessId")]
        public OfesautoProcess OfesautoProcess { get; set; }
        public List<CommunicationsHistory> CommunicationsHistory { get; set; }


    }
}
