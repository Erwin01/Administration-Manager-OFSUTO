﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class OfesautoProcess
    {
        [Key]
        [Column("OfesautoProcessId")]
        public int Id { get; set; }

        [Column("OfesautoProcessName")]
        public string Name { get; set; }
        [Column("OfesautoProcessNamEnglish")]

        public string NamEnglish { get; set; }
        [Column("OfesautoProcessDescription")]
        public string Description { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }

        public List<OfesautoStatesProcess> OfesautoStatesProcess { get; set; }


    }
}
