﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class TypeTrazability
    {
        [Key]
        public int TypeTrazabilityId { get; set; }

        [Display(Name = "Status Name")]
        public string Name { get; set; }

        [Display(Name = "Status Name English")]
        public string NamEnglish { get; set; }


        public int UserId { get; set; }

        [Display(Name = "Created Date")]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }

    }
}
