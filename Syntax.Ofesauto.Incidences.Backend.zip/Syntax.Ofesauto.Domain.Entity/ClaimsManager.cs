﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class ClaimsManager : DefaultEntity
    {

        [Key]
        public int ClaimsManagerId { get; set; }

        [MaxLength(30)]
        [MinLength(5)]
        [Required]
        public string ClaimsManagerName { get; set; }

        public DateTime ClaimsAccidentDate { get; set; } = DateTime.Now;

        [MaxLength(20)]
        [MinLength(5)]
        public string ClaimsCauseVehicleRegistration { get; set; }

        public int ClaimsDeclareVehicleAccidentId { get; set; }

        public int ClaimsIncidenceRecordId { get; set; }

        public int ClaimsInvestigationRecordId { get; set; }

        public int ClaimsCompensationRecordId { get; set; }
    }
}
