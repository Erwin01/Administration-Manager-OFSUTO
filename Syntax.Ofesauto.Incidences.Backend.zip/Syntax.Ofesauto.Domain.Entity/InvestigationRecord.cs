﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class InvestigationRecord
    {

        public int InvestigationRecordId { get; set; }

        [Display(Name = "Investigation Record Number")]
        public int InvestigationRecordNumber { get; set; }

        public DateTime InvestigationRecordDateHigh { get; set; }

        public int DeclareVehicleAccidentId { get; set; }

        public int StateId { get; set; }

        [Display(Name = "Investigation Record Closing Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime InvestigationRecordClosingDate { get; set; }

        [Display(Name = "Created Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdateDate { get; set; }
    }
}
