﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class IncidenceType : DefaultEntity
    {
        [Key]
        public int IncidenceTypeId { get; set; }
        [Required]
        [MaxLength(50)]
        [MinLength(5)]
        public string IncidenceTypeName { get; set; }
        [MaxLength(50)]
        [MinLength(5)]
        public string IncidenceTypeNamEnglish { get; set; }
        [Required]
        public int IncidenceClassifyId { get; set; }
        [Required]
        public int DataTypeId { get; set; }

        //public IncidenceClassify IncidenceClassify { get; set; }


    }
}
