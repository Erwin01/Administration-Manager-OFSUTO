﻿using System;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class HistoryIncident
    {

        public DateTime IncidenceRecordStateDate { get; set; } = DateTime.Now;
        public int DeclareVehicleAccidentId { get; set; }
        public int IncidenceRecordId { get; set; }
        public string Claimant { get; set; }
        public string AffectedVehicleRegistrationidenceId { get; set; }
        public string OfesautoStateId { get; set; }
        public DateTime IncidenceRecordDateHigh { get; set; } = DateTime.Now;
        public string Message { get; set; }
        public string Document { get; set; }
        public string MakeBy { get; set; }
        public int StateId { get; set; }

    }
}
