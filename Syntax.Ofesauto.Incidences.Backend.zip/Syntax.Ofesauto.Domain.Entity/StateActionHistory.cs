﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class StateActionHistory
    {
        [Key]
        public int StateId { get; set; }

        [Display(Name = "Status Name")]
        public string StateName { get; set; }

        [Display(Name = "Status Name English")]
        public string StateNamEnglish { get; set; }


        public int UserId { get; set; }

        [Display(Name = "Created Date")]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }

    }
}
