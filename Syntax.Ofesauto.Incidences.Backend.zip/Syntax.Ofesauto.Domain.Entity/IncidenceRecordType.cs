﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class IncidenceRecordType : DefaultEntity
    {

        [Key]
        public int IncidenceRecordTypeId { get; set; }

        [Required]
        public int IncidenceTypeId { get; set; }

        [Required]
        public int IncidenceTypeStateId { get; set; }

    }
}
