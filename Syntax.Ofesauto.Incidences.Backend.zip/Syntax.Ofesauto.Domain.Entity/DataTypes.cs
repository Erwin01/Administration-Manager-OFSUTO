﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class DataTypes : DefaultEntity
    {
        [Key]
        public int DataTypeId { get; set; }
        [Required]
        [MaxLength(50)]
        [MinLength(5)]
        public string DataTypeName { get; set; }


    }
}
