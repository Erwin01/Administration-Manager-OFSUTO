﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class IncidenceRecord : DefaultEntity
    {

        [Key]
        public int IncidenceRecordId { get; set; }
        [Required]
        [MaxLength(20)]
        [MinLength(5)]
        public string IncidenceRecordNumber { get; set; }

        public DateTime IncidenceAccidentDate { get; set; } = DateTime.Now;

        [Required]
        public string IncidenceCauseVehicleRegistration { get; set; }

        [Required]
        public string IncidenceAffectedVehicleRegistration { get; set; }

        [Required]
        [MaxLength(30)]
        [MinLength(5)]
        public string IncidenceRecordName { get; set; }

        [Required]
        [MaxLength(30)]
        [MinLength(5)]
        public string IncidenceRecordLastName { get; set; }

        public DateTime IncidenceDateHigh { get; set; } = DateTime.Now;

        [Required]
        public int IncidenceClaimManagerId { get; set; }

        [Required]
        public int IncidenceOrganismId { get; set; }

        [Required]
        public int IncidenceClaimProcessorId { get; set; }

        [Required]
        public int IncidenceOfesautoStateId { get; set; }

        public DateTime IncidenceRecordStateDate { get; set; } = DateTime.Now;

        public int OfesautoStatesId { get; set; }

        [ForeignKey("OfesautoStateId")]
        public OfesautoStates OfesautoStates { get; set; }

        public List<IncidenceRecordType> IncidenceRecordType { get; set; }

    }
}
