﻿
using Microsoft.EntityFrameworkCore;
using System;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{


    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    ///  [Keyless]
    ///  
    [Keyless]
    public class ResponseClaimsByCountry
    {

        public int CountryClaimProcessorId { get; set; }

        public string OpeningReason { get; set; }
        public string AccidentCountry { get; set; }
        public int AccidentCountryId { get; set; }
        public string CauseAccidentCountry { get; set; }
        public int CauseAccidentCountryId { get; set; }
        public int ClaimProcessorId { get; set; }
        public string ClaimProcessorName { get; set; }
        public int OpeningReasonId { get; set; }
        public int UserId { get; set; }
        public DateTime UpdateDate { get; set; } = DateTime.UtcNow;
        public DateTime CreateDate { get; set; } = DateTime.UtcNow;
    }

}
