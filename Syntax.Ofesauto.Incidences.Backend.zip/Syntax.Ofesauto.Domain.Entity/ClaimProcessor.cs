﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class ClaimProcessor
    {
        [Key]
        [Required]
        public int ClaimProcessorId { get; set; }
        [Required]
        public int UserId { get; set; }
        [Required]
        public string ClaimProcessorName { get; set; }
        [Required]
        public string ClaimProcessorEmail { get; set; }
        [Required]
        public string ClaimProcessorEmailRedirect { get; set; }
        [Required]
        public Byte StateId { get; set; }
        [Required]
        public DateTime CreateDate { get; set; }
        [Required]
        public DateTime UpdateDate { get; set; }

    }
}
