﻿using System;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class Insurer
    {
        public int InsurerId { get; set; }
        public int InsurerCode { get; set; }
        public string InsurerName { get; set; }
        public string InsurerAddress { get; set; }
        public int InsurerPostalCode { get; set; }
        public int InsurerCountryId { get; set; }
        public int InsurerPhone { get; set; }
        public string InsurerEmail { get; set; }
        public int InsurerFax { get; set; }
        public string InsurerNif { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

    }
}
