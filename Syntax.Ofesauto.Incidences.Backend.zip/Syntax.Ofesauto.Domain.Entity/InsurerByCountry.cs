﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class InsurerByCountry
    {
        [Key]
        public int InsurerId { get; set; }

        [Display(Name = "Insurer Code")]
        public int InsurerCode { get; set; }

        [Display(Name = "Insurer Name")]
        public string InsurerName { get; set; }

        public int CountryId { get; set; }

        [Display(Name = "Country Name")]
        public string CountryName { get; set; }

    }
}
