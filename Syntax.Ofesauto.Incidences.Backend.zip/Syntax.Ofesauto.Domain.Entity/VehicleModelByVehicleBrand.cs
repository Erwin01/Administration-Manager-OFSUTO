﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class VehicleModelByVehicleBrand
    {
        [Key]
        public byte VehicleModelId { get; set; }

        [Display(Name = "Model Name")]
        public string ModelName { get; set; }

        [Display(Name = "Model Name English")]
        public string ModelNamEnglish { get; set; }

        public int VehicleBrandId { get; set; }

        [Display(Name = "Brand Name")]
        public string BrandName { get; set; }

        [Display(Name = "Brand Name English")]
        public string BrandNamEnglish { get; set; }

        [Display(Name = "Created Date")]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdateDate { get; set; }

    }
}
