﻿
using Microsoft.EntityFrameworkCore;
using System;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{

    #region [ DECLARE VEHICLE ACCIDENT DTO ]

    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    ///  [Keyless]
    ///  
    [Keyless]
    public class ResponseTrazability
    {

        public int ActionHistoryId { get; set; }

        public int ActionTypeId { get; set; }
        public int IdentificationRegister { get; set; }
        public string Reason { get; set; }
        public string ActionType { get; set; }

        public int OfesautoProcessId { get; set; }
        public int StateId { get; set; }
        public int UserId { get; set; }
        public string State { get; set; }
        public string MadeBy { get; set; }
        public DateTime ActionDate { get; set; }
    }
    #endregion

}
