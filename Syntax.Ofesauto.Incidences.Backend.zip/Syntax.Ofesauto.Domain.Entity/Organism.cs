﻿using System;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class Organism
    {

        public int OrganismId { get; set; }
        public int OrganismTypeId { get; set; }
        public int CountryId { get; set; }
        public int RegionId { get; set; }
        public int CityId { get; set; }
        public string OrganismName { get; set; }
        public string OrganismLastName { get; set; }
        public int DocumentTypeId { get; set; }
        public string OrganismAddress { get; set; }
        public string OrganismPostalCode { get; set; }
        public string OrganismCIF { get; set; }
        public string OrganismWebSite { get; set; }
        public string OrganismCode { get; set; }
        public int OrganismReasonLowId { get; set; }
        public DateTime OrganismLowDate { get; set; }
        public string OrganismIdPassTo { get; set; }
        public DateTime OrganismHightDate { get; set; }
        public int OrganismSubTypeId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }

    }
}
