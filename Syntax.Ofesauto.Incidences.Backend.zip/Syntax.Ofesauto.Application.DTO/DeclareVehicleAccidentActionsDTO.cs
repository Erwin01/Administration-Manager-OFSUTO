﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{

    #region [ DECLARE VEHICLE ACCIDENT ACTIONS DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    ///
    public class DeclareVehicleAccidentActionsDTO
    {

        //public int ActionId { get; set; }

        public int DeclareVehicleAccidentId { get; set; }

        //public int OfesautoProcessId { get; set; }

        public int StateId { get; set; }

        [Display(Name = "Observations")]
        public string Observations { get; set; }

        public int AttachmentId { get; set; }

        public int UserId { get; set; }

        public int ClaimProcessorId { get; set; }

        //[Display(Name = "Action Date")]
        //public DateTime ActionDate { get; set; }

        public int ActionTypeId { get; set; }

        //[Display(Name = "Created Date")]
        //[DataType(DataType.DateTime)]
        //[DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        //public DateTime CreatedDate { get; set; }

        //[Display(Name = "Updated Date")]
        //[DataType(DataType.DateTime)]
        //[DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        //public DateTime UpdateDate { get; set; }

    }
    #endregion

}