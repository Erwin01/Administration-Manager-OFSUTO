﻿namespace Syntax.Ofesauto.Incidence.Application.DTO
{

    #region [ INVESTIGATION RECORD DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class InvestigationRecordDTO
    {

        //public int InvestigationRecordId { get; set; }
        public int InvestigationRecordNumber { get; set; }
        //public DateTime InvestigationRecordDateHigh { get; set; }
        public int DeclareVehicleAccidentId { get; set; }
        public int StateId { get; set; }
        //public DateTime InvestigationRecordClosingDate { get; set; }
        //public DateTime CreateDate { get; set; }
        //public DateTime UpdateDate { get; set; }
    }
    #endregion
}
