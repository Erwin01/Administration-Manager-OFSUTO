﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class ActionsHistoryDTO
    {
        public ActionsHistoryDTO()
        {

        }
        public ActionsHistoryDTO(int identificationRegister, int userId, int ofesautoProcessId, int actionType, int? claimProcessor,

            List<IFormFile> files, string emailSender, string message, bool? firsTime = false)

        {
            IdentificationRegister = identificationRegister;
            UserId = userId;
            OfesautoProcessId = ofesautoProcessId;
            ActionTypeId = actionType;
            ClaimProcessorId = claimProcessor;
            Files = files;
            ActionDate = DateTime.UtcNow;
            CreateDate = DateTime.UtcNow;
            UpdateDate = DateTime.UtcNow;
            FirstTime = firsTime;
            EmailSender = emailSender;
            Message = message;
        }

        #region [ ACTIONS HISTORY DTO ]
        /// <summary>
        /// Method that allows placing only the attributes that are going to be exposed
        /// </summary>
        public int ActionHistoryId { get; set; }
        public int OfesautoProcessId { get; set; }
        public int IdentificationRegister { get; set; }
        public int StateId { get; set; } = 1;
        public string Observations { get; set; }
        public int UserId { get; set; }
        public int ActionTypeId { get; set; }
        public string EmailSender { get; set; }
        public bool? FirstTime { get; set; } = false;
        public int? ClaimProcessorId { get; set; }
        public DateTime ActionDate { get; set; } = DateTime.Now;
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime UpdateDate { get; set; } = DateTime.Now;
        /** Relations dtos*/
        public string SubjectCommunication { get; set; }
        public string Message { get; set; }
        public int TypeTrazabilityId { get; set; }
        public string ActionType { get; set; }
        public string MadeBy { get; set; }
        public string status { get; set; }
        public string Trazability { get; set; }
        public List<IFormFile> Files { get; set; }
        //public List<CommunicationsHistoryDTO> CommunicationsHistory { get; set; }
        public List<CommunicationAttachmentsDTO> CommunicationAttachments { get; set; }

    }
    #endregion
}
