﻿
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{

    #region [ DECLARE VEHICLE ACCIDENT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class CreateDeclareVehicleAccidentDTO
    {


        //public int UserId { get; set; }
        public int DeclareVehicleAccidentId { get; set; }
        //[Display(Name = "Claimant Fax")]
        //public string ClaimantFax { get; set; }

        [Display(Name = "Claimant Reference")]
        public string ClaimantReference { get; set; }

        public int DocumentTypeId { get; set; }

        [Display(Name = "Aplication Type")]
        public string ApplicationType { get; set; }

        [Display(Name = "Accident Date")]
        public DateTime AccidentDate { get; set; }

        public int AccidentCountryId { get; set; }

        public int AccidentRegionId { get; set; }

        [Display(Name = "Accident Version")]
        public string AccidentVersion { get; set; }

        public int ReasonForOpeningId { get; set; }

        public Byte CauseVehicleCategoryId { get; set; }

        public Byte CauseVehicleBrandId { get; set; }

        public Byte CauseVehicleModelId { get; set; }

        [Display(Name = "Cause Vehicle Registration")]
        public string CauseVehicleRegistration { get; set; }

        public Byte CauseCountryRegistrationId { get; set; }

        public Byte CauseInsuranceCompanyId { get; set; }

        [Display(Name = "Cause Number Policy")]
        public string CauseNumberPolicy { get; set; }

        [Display(Name = "Cause Address")]
        public string CauseAddress { get; set; }

        [Display(Name = "Comments")]
        public string Comments { get; set; }

        public Byte StateId { get; set; }

        public Byte AffectedVehicleBrandId { get; set; }

        public Byte AffectedVehicleCategoryId { get; set; }

        public Byte AffectedVehicleModelId { get; set; }

        [Display(Name = "Affected Vehicle Registration")]
        public string AffectedVehicleRegistration { get; set; }

        public int AffectedCountryRegistrationId { get; set; }

        public int AffectedInsuranceCompanyId { get; set; }

        [Display(Name = "Affected Number Policy")]
        public string AffectedNumberPolicy { get; set; }

        [Display(Name = "Affected Name")]
        public string AffectedName { get; set; }

        [Display(Name = "Affected Surname")]
        public string AffectedSurname { get; set; }

        [Display(Name = "Affected Address")]
        public string AffectedAddress { get; set; }

        public int AffectedCityId { get; set; }

        public int AffectedRegionId { get; set; }

        [Display(Name = "Affected Email")]
        public string AffectedEmail { get; set; }

        [Display(Name = "Affected Phone Number")]
        public string AffectedPhoneNumber { get; set; }

        [Display(Name = "Affected Damage Materials")]
        public bool AffectedDamageMaterials { get; set; }

        [Display(Name = "Affected Damage Personals")]
        public bool AffectedDamagePersonals { get; set; }

        [Display(Name = "Accept RGPD")]
        public bool AcceptRgpd { get; set; }
        public string EmailSender { get; set; }
        public int UserId { get; set; }
        public int? ClaimsProcessorId { get; set; }
        public int? OrganismId { get; set; }
        public DateTime UpdateDate { get; set; } = DateTime.UtcNow;
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public List<IFormFile> Files { get; set; }
    }
    #endregion

}
