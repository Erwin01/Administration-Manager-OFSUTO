﻿using System;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class IncidenceTypeDTO
    {

        public int IncidenceTypeId { get; set; }
        public string IncidenceTypeName { get; set; }
        public string IncidenceTypeNamEnglish { get; set; }
        public int IncidenceClassifyId { get; set; }
        public int DataTypeId { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime UpdateDate { get; set; } = DateTime.Now;

    }
}
