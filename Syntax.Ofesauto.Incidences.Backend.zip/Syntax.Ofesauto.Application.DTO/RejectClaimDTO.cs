﻿namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class RejectClaimDTO
    {
        public int ClaimId { get; set; }
        public string subject { get; set; }
        public string Observations { get; set; }
        public int UserId { get; set; }
        public string Email { get; set; }
        public int ActionTypeId { get; set; }
        public int OffesautoProcessId { get; set; }
    }
}
