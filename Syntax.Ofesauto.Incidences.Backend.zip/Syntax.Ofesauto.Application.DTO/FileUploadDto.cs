﻿using Microsoft.AspNetCore.Http;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class FileUploadDto
    {
        public IFormFile file { get; set; }
        public string fileName { get; set; }
        public string[] AllowedExtensions { get; set; }
        public string SavePath { get; set; }
    }
}
