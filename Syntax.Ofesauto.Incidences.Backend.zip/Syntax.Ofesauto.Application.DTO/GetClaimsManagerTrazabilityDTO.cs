﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class GetIncidenceTrazabilityDTO
    {

        public int DeclareVehicleAccidentId { get; set; }

        [Display(Name = "Accident Date")]
        public DateTime AccidentDate { get; set; }


    }
}
