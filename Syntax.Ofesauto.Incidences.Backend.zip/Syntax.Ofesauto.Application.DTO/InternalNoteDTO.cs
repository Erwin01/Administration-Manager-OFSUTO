﻿namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class InternalNoteDTO
    {

        public int InternalNoteId { get; set; }
        public int OfesautoProcessId { get; set; }
        public int IdentificationRegister { get; set; }
        public string Description { get; set; }
        public int UserId { get; set; }

    }
}
