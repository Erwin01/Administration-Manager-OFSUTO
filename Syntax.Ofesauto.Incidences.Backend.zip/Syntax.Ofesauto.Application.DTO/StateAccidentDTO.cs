﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{

    #region [ STATE ACCIDENT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class StateAccidentDTO
    {

        public int StateId { get; set; }

        [Display(Name = "Status Name")]
        public string StateName { get; set; }

        [Display(Name = "Status Name English")]
        public string StateNamEnglish { get; set; }

        //[Display(Name = "Status Description")]
        //public string StateDescription { get; set; }


    }
    #endregion

}
