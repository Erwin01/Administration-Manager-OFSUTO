﻿using System;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class ResponseTrazabilityDTO
    {
        public int ActionHistoryId { get; set; }

        public int ActionTypeId { get; set; }
        public int IdentificationRegister { get; set; }
        public string Reason { get; set; }
        public string ActionType { get; set; }

        public int OfesautoProcessId { get; set; }
        public int StateId { get; set; }
        public int UserId { get; set; }
        public string State { get; set; }
        public string MadeBy { get; set; }
        public DateTime ActionDate { get; set; }
    }
}
