﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class IncidenceClassifyDTO : DefaultEntity
    {

        [Key]
        public int IncidenceClassifyId { get; set; }
        public string IncidenceClassifyName { get; set; }
        public string IncidenceClassifyNamEnglish { get; set; }
        public string IncidenceClassifyDescription { get; set; }


    }
}
