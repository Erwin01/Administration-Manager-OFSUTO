﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class IncidenceRecordDTO
    {

        
        public int IncidenceRecordId { get; set; }
        public string IncidenceRecordNumber { get; set; }
        public DateTime IncidenceAccidentDate { get; set; } = DateTime.Now;
        public string IncidenceCauseVehicleRegistration { get; set; }
        public string IncidenceAffectedVehicleRegistration { get; set; }
        public string IncidenceRecordName { get; set; }
        public string IncidenceRecordLastName { get; set; }
        public DateTime IncidenceDateHigh { get; set; } = DateTime.Now;
        public int IncidenceClaimManagerId { get; set; }
        public int IncidenceOrganismId { get; set; }
        public int IncidenceClaimProcessorId { get; set; }
        public int IncidenceOfesautoStateId { get; set; }
        public int UserId { get; set; }
        public DateTime IncidenceRecordStateDate { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime UpdateDate { get; set; } = DateTime.Now;
        public int OfesautoStatesId { get; set; }

        public List<IncidenceRecordTypeDTO> IncidenceRecordType { get; set; }

    }
}
