﻿using System;

namespace Syntax.Ofesauto.Incidence.Domain.Entity
{
    public class ClaimsManagerDTO
    {

        public int ClaimsManagerId { get; set; }

        public string ClaimsManagerName { get; set; }

        public DateTime ClaimsAccidentDate { get; set; } = DateTime.Now;

        public string ClaimsCauseVehicleRegistration { get; set; }

        public int ClaimsDeclareVehicleAccidentId { get; set; }

        public int ClaimsIncidenceRecordId { get; set; }

        public int ClaimsInvestigationRecordId { get; set; }

        public int ClaimsCompensationRecordId { get; set; }
    }
}
