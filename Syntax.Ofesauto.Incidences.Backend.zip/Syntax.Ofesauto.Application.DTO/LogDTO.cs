﻿using System;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class LogDTO
    {
        public int LogId { get; set; }

        //[StringLength(128)]
        public string Source { get; set; }
        public string Description { get; set; }
        //[StringLength(220)]
        public string Type { get; set; }

        public DateTime CreatedOnDate { get; set; }
    }
}
