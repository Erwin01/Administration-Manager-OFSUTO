﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{

    #region [ VEHICLE MODEL DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class VehicleModelDTO
    {

        public byte VehicleModelId { get; set; }

        [Display(Name = "Model Name")]
        public string ModelName { get; set; }

        [Display(Name = "Model Name English")]
        public string ModelNamEnglish { get; set; }

    }
    #endregion

}
