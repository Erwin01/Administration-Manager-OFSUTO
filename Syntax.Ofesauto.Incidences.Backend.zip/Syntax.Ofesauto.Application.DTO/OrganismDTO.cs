﻿namespace Syntax.Ofesauto.Incidence.Application.DTO
{

    #region [ ORGANISM DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OrganismDTO
    {

        public int OrganismId { get; set; }
        public int OrganismTypeId { get; set; }
        public int CountryId { get; set; }
        public int RegionId { get; set; }
        public int CityId { get; set; }
        public string OrganismName { get; set; }
        public string OrganismLastName { get; set; }
        public string DocumentTypeId { get; set; }
        public string OrganismAddress { get; set; }
        public string OrganismPostalCode { get; set; }
        public string OrganismCIF { get; set; }
        public string OrganismWebSite { get; set; }
        public string OrganismCode { get; set; }
        public int OrganismSubTypeId { get; set; }
        public int OrganismReasonLowId { get; set; }


    }
    #endregion

}