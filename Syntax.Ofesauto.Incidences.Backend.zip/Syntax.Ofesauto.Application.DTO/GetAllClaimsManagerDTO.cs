﻿using System;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class GetAllIncidenceDTO
    {


        #region [ ACTIONS HISTORY DTO ]
        /// <summary>
        /// Method that allows placing only the attributes that are going to be exposed
        /// </summary>
        /// 
        public DateTime AccidentDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ClaimantReference { get; set; }
        public string CauseVehicleRegistration { get; set; }
        public string StateName { get; set; }
        public DateTime CommunicationDate { get; set; }
        public string CommunicationSubject { get; set; }
        public string CommunicationFileNameHtml { get; set; }
        public string CommunicationFrom { get; set; }


    }
    #endregion
}
