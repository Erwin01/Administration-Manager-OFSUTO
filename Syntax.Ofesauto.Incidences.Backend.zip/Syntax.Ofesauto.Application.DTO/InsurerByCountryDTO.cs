﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{

    #region [ INSURER BY COUNTRY DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class InsurerByCountryDTO
    {

        public int InsurerId { get; set; }

        [Display(Name = "Insurer Code")]
        public int InsurerCode { get; set; }

        [Display(Name = "Insurer Name")]
        public string InsurerName { get; set; }

    }
    #endregion

}
