﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{


    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class TypeTrazabilityDTO
    {

        public int TypeTrazabilityId { get; set; }

        [Display(Name = "Status Name")]
        public string Name { get; set; }

        [Display(Name = "Status Name English")]
        public string NamEnglish { get; set; }


        public int UserId { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }


    }

}