﻿using System;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class ClaimProcessorDTO
    {
        public int ClaimProcessorId { get; set; }
        public int UserId { get; set; }
        public string ClaimProcessorName { get; set; }
        public string ClaimProcessorEmail { get; set; }
        public string ClaimProcessorEmailRedirect { get; set; }
        public int StateId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
    }
}