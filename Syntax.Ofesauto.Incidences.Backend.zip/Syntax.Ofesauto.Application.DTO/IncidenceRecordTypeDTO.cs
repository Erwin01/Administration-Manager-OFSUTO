﻿namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class IncidenceRecordTypeDTO
    {

        public int IncidenceRecordTypeId { get; set; }
        public int IncidenceTypeId { get; set; }
        public int IncidenceTypeStateId { get; set; }

    }
}
