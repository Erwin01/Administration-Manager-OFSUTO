﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.Incidence.Application.DTO
{
    public class DataTypesDTO
    {
        [Key]
        public int DataTypeId { get; set; }
        public string DataTypeName { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime UpdateDate { get; set; } = DateTime.Now;

    }
}