﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.Incidence.Application.DTO;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
namespace Syntax.Ofesauto.Security.Services.Api.Helpers
{
    public class CustomControllerBase : ControllerBase
    {
        public static LoginResponseDTO user = new LoginResponseDTO();
        [ApiExplorerSettings(IgnoreApi = true)]
        public LoginResponseDTO GetDataUser()
        {
            string jwtInput = Request.Headers["Authorization"];

            if (!string.IsNullOrEmpty(jwtInput))
            {
                var result = new LoginResponseDTO();
                try
                {
                    var jwtHandler = new JwtSecurityTokenHandler();
                    if (!string.IsNullOrEmpty(jwtInput))
                    {
                        jwtInput = jwtInput.Replace("Bearer ", "");
                        var readableToken = jwtHandler.CanReadToken(jwtInput);
                        if (readableToken == true)
                        {
                            var token = jwtHandler.ReadJwtToken(jwtInput);
                            var headers = token.Header;
                            var jwtHeader = "{";
                            foreach (var h in headers)
                            {
                                jwtHeader += '"' + h.Key + "\":\"" + h.Value + "\",";
                            }
                            jwtHeader += "}";
                            var claims = token.Claims;
                            var jwtPayload = "{";
                            foreach (Claim c in claims)
                            {
                                jwtPayload += '"' + c.Type + "\":\"" + c.Value + "\",";
                            }
                            jwtPayload += "}";
                            user = Newtonsoft.Json.JsonConvert.DeserializeObject<LoginResponseDTO>(jwtPayload);
                        }

                    }
                    return user;
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
    }
}
