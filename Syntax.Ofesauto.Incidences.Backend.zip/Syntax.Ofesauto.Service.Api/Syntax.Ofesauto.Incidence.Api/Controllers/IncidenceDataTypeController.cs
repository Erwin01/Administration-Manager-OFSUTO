﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class IncidenceDataTypeController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IDataTypeApplication _dataTypeApplication;

        #region [ CONSTRUCTOR ]
        public IncidenceDataTypeController(IDataTypeApplication dataTypeApplication)
        {
            _dataTypeApplication = dataTypeApplication;

        }
        #endregion



        [HttpPost]
        public async Task<IActionResult> InsertDataTypeAsync([FromBody] DataTypesDTO dataTypesDTO)
        {
            if (dataTypesDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _dataTypeApplication.Add(dataTypesDTO);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllDataTypeAsync()
        {

            var response = await _dataTypeApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }
    }
}
