﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class IncidenceClassifyController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IIncidenceClassifyApplication _incidenceClassifyApplication;

        #region [ CONSTRUCTOR ]
        public IncidenceClassifyController(IIncidenceClassifyApplication incidenceClassifyApplication)
        {
            _incidenceClassifyApplication = incidenceClassifyApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertIncidenceClassifyAsync([FromBody] IncidenceClassifyDTO incidenceClassifyDTO)
        {
            if (incidenceClassifyDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _incidenceClassifyApplication.Add(incidenceClassifyDTO);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllIncidenceClassifyAsync()
        {

            var response = await _incidenceClassifyApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("id")]
        public async Task<IActionResult> GetIncidenceClassifyByIdAsync(int id)
        {

            var response = await _incidenceClassifyApplication.GetById(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateIncidenceClassifyAsync([FromBody] IncidenceClassifyDTO incidenceClassifyDTO)
        {
            if (incidenceClassifyDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _incidenceClassifyApplication.Update(incidenceClassifyDTO, incidenceClassifyDTO.IncidenceClassifyId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> RemoveIncidenceClassifyAsync(int id)
        {
            var response = await _incidenceClassifyApplication.Delete(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
