﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class IncidenceRecordController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IIncidenceRecordApplication _incidenceRecordApplication;
        private readonly IHubContext<IncidenceHub> _hubContext;

        #region [ CONSTRUCTOR ]
        public IncidenceRecordController(IIncidenceRecordApplication incidenceRecordApplication, IHubContext<IncidenceHub> hubContext)
        {
            _incidenceRecordApplication = incidenceRecordApplication;
            _hubContext = hubContext;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertIncidenceRecordAsync([FromBody] IncidenceRecordDTO incidenceRecordDTO)
        {
            if (incidenceRecordDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            //var name = HttpContext.User.Identity.Name;

            var response = await _incidenceRecordApplication.Add(incidenceRecordDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllIncidenceRecordAsync()
        {

            var response = await _incidenceRecordApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("id")]
        public async Task<IActionResult> GetIncidenceByIdAsync(int id)
        {

            var response = await _incidenceRecordApplication.GetById(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
