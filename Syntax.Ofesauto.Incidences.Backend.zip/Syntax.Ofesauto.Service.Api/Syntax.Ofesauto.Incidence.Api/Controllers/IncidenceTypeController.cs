﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class IncidenceTypeController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IIncidenceTypeApplication _incidenceTypeApplication;

        #region [ CONSTRUCTOR ]
        public IncidenceTypeController(IIncidenceTypeApplication incidenceRecordApplication)
        {
            _incidenceTypeApplication = incidenceRecordApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertIncidenceTypeAsync([FromBody] IncidenceTypeDTO incidenceTypeDTO)
        {
            if (incidenceTypeDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _incidenceTypeApplication.Add(incidenceTypeDTO);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllIncidenceTypeAsync()
        {

            var response = await _incidenceTypeApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("id")]
        public async Task<IActionResult> GetIncidenceTypeByIdAsync(int id)
        {

            var response = await _incidenceTypeApplication.GetById(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateIncidenceTypeAsync([FromBody] IncidenceTypeDTO incidenceTypeDTO)
        {
            if (incidenceTypeDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _incidenceTypeApplication.Update(incidenceTypeDTO, incidenceTypeDTO.IncidenceTypeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> RemoveIncidenceTypeAsync(int id)
        {
            var response = await _incidenceTypeApplication.Delete(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
