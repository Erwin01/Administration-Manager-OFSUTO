﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class InternalNote : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IInternalNoteApplication _internalNoteApplication;

        #region [ CONSTRUCTOR ]
        public InternalNote(IInternalNoteApplication internalNoteApplication)
        {
            _internalNoteApplication = internalNoteApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertInternalNoteAsync([FromBody] InternalNoteDTO internalNoteDTO)
        {
            if (internalNoteDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _internalNoteApplication.Add(internalNoteDTO);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllInternalNoteAsync()
        {

            var response = await _internalNoteApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("id")]
        public async Task<IActionResult> GetInternalNoteByIdAsync(int id)
        {

            var response = await _internalNoteApplication.GetById(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateInternalNoteAsync([FromBody] InternalNoteDTO internalNoteDTO)
        {
            if (internalNoteDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _internalNoteApplication.Update(internalNoteDTO, internalNoteDTO.InternalNoteId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> RemoveInternalNoteAsync(int id)
        {
            var response = await _internalNoteApplication.Delete(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
