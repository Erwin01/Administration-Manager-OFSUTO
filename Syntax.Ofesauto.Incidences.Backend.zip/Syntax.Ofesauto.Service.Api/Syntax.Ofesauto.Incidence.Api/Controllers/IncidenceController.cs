﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class IncidenceController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IIncidenceRecordApplication _incidenceRecordApplication;
        private readonly IHubContext<IncidenceHub> _hubContext;

        #region [ CONSTRUCTOR ]
        public IncidenceController(IIncidenceRecordApplication incidenceRecordApplication, IHubContext<IncidenceHub> hubContext)
        {
            _incidenceRecordApplication = incidenceRecordApplication;
            _hubContext = hubContext;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertIncidenceRecord([FromBody] IncidenceRecordDTO incidenceRecordDTO)
        {
            if (incidenceRecordDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _incidenceRecordApplication.Add(incidenceRecordDTO);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateIncidenceRecord([FromBody] IncidenceRecordDTO incidenceRecordDTO)
        {
            if (incidenceRecordDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _incidenceRecordApplication.Update(incidenceRecordDTO, incidenceRecordDTO.IncidenceRecordId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllIncidenceRecord()
        {

            var response = await _incidenceRecordApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("id")]
        public async Task<IActionResult> GetIncidenceRecordById(int id)
        {

            var response = await _incidenceRecordApplication.GetById(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> RemoveIncidenceRecord(int id)
        {

            var response = await _incidenceRecordApplication.DeleteLogicalByState(id);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
