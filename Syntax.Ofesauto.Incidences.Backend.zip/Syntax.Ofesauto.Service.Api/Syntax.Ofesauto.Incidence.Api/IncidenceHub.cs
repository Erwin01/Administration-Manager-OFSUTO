﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api
{
    public class IncidenceHub : Hub
    {

        //public async Task Send(string incidenceRecordNumber, DateTime incidenceHighDate, int declareVehicleAccidentId, int incidenceTypeId, int ofesautoStateId)
        //{
        //    await Clients.All.SendAsync("Receive", incidenceRecordNumber, incidenceHighDate, declareVehicleAccidentId, incidenceTypeId, ofesautoStateId);
        //}
    }
}
