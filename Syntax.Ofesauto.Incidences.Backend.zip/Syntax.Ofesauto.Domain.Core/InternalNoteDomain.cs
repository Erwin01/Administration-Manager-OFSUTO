﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class InternalNoteDomain : IInternalNoteDomain
    {

        private readonly IRepository<InternalNote> _repository;


        public InternalNoteDomain(IRepository<InternalNote> repository)
        {
            _repository = repository;
        }

        public async Task<InternalNote> Add(InternalNote obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public Task<bool> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<InternalNote>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<InternalNote> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public Task<List<InternalNote>> GetByParam(Func<InternalNote, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<InternalNote> GetByParamFirst(Func<InternalNote, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<InternalNote> Update(InternalNote obj, int id)
        {
            return await _repository.Update(obj, id);
        }

    }
}
