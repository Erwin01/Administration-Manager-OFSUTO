﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class UserDomain : IUserDomain
    {
        private readonly IRepository<User> _repository;
        public UserDomain(IRepository<User> repository)
        {
            _repository = repository;
        }
        public async Task<User> Add(User obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public Task<bool> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<User>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<User> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public Task<List<User>> GetByParam(Func<User, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<User> GetByParamFirst(Func<User, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<User> Update(User obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
