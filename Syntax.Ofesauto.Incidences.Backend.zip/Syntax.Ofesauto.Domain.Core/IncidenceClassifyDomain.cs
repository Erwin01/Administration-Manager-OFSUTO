﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class IncidenceClassifyDomain : IIncidenceClassifyDomain
    {

        private readonly IRepository<IncidenceClassify> _repository;


        public IncidenceClassifyDomain(IRepository<IncidenceClassify> repository)
        {
            _repository = repository;
        }

        public async Task<IncidenceClassify> Add(IncidenceClassify obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public Task<bool> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<IncidenceClassify>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<IncidenceClassify> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public Task<List<IncidenceClassify>> GetByParam(Func<IncidenceClassify, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<IncidenceClassify> GetByParamFirst(Func<IncidenceClassify, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<IncidenceClassify> Update(IncidenceClassify obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
