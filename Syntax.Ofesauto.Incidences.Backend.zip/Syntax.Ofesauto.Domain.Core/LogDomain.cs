﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class LogDomain : ILogDomain
    {
        private readonly IRepository<IssuesLog> _repository;
        public LogDomain(IRepository<IssuesLog> repository)
        {
            _repository = repository;
        }
        public async Task<IssuesLog> Add(IssuesLog obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<IssuesLog>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<IssuesLog> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public async Task<List<IssuesLog>> GetByParam(Func<IssuesLog, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<IssuesLog> GetByParamFirst(Func<IssuesLog, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<IssuesLog> Update(IssuesLog obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
