﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class DataTypeDomain : IDataTypeDomain
    {

        private readonly IRepository<DataTypes> _repository;


        public DataTypeDomain(IRepository<DataTypes> repository)
        {
            _repository = repository;
        }

        public async Task<DataTypes> Add(DataTypes obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public Task<bool> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<DataTypes>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<DataTypes> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public Task<List<DataTypes>> GetByParam(Func<DataTypes, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<DataTypes> GetByParamFirst(Func<DataTypes, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<DataTypes> Update(DataTypes obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
