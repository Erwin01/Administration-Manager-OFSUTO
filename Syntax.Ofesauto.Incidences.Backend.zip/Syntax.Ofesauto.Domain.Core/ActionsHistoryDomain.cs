﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class ActionsHistoryDomain : IActionsHistoryDomain
    {
        private readonly IRepository<ActionsHistory> _repository;
        public ActionsHistoryDomain(IRepository<ActionsHistory> repository)
        {
            _repository = repository;
        }
        public async Task<ActionsHistory> Add(ActionsHistory obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<ActionsHistory>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<ActionsHistory> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public async Task<List<ActionsHistory>> GetByParam(Func<ActionsHistory, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<ActionsHistory> GetByParamFirst(Func<ActionsHistory, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<ActionsHistory> Update(ActionsHistory obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
