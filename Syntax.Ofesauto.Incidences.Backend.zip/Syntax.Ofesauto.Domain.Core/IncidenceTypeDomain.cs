﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class IncidenceTypeDomain : IIncidenceTypeDomain
    {

        private readonly IRepository<IncidenceType> _repository;

        public IncidenceTypeDomain(IRepository<IncidenceType> repository)
        {
            _repository = repository;
        }

        public Task<IncidenceType> Add(IncidenceType obj)
        {
            return _repository.Add(obj);
        }

        public Task<bool> Delete(int id)
        {
            return _repository.Delete(id);
        }

        public Task<bool> DeleteLogicalByState(int id)
        {
            throw new NotImplementedException();
        }

        public Task<List<IncidenceType>> GetAll()
        {
            return _repository.GetAll();
        }

        public Task<IncidenceType> GetById(int id)
        {
            return _repository.GetById(id);
        }

        public Task<List<IncidenceType>> GetByParam(Func<IncidenceRecord, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<List<IncidenceType>> GetByParam(Func<IncidenceType, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<IncidenceType> GetByParamFirst(Func<IncidenceRecord, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<IncidenceType> GetByParamFirst(Func<IncidenceType, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<IncidenceType> Update(IncidenceType obj, int id)
        {
            return _repository.Update(obj, id);
        }

    }
}
