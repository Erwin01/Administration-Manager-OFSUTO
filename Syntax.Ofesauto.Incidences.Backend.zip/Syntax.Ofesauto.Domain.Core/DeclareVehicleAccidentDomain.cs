﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class DeclareVehicleAccidentDomain : IDeclareVehicleAccidentDomain
    {

        /// <summary>
        /// Object allows accessing the properties of different projects
        /// </summary>
        private readonly IDeclareVehicleAccidentRepository _declareVehicleAccidentRepository;


        public DeclareVehicleAccidentDomain(IDeclareVehicleAccidentRepository declareVehicleAccidentRepository)
        {
            _declareVehicleAccidentRepository = declareVehicleAccidentRepository;
        }


        #region [ ASYNCHRONOUS METHODS ]

        #region [ VEHICLE METHODS ]
        public async Task<IEnumerable<VehicleCategory>> GetAllVehicleCategoryAsync()
        {
            return await _declareVehicleAccidentRepository.GetAllVehicleCategoryAsync();
        }

        public async Task<IEnumerable<VehicleBrand>> GetAllVehicleBrandAsync()
        {
            return await _declareVehicleAccidentRepository.GetAllVehicleBrandAsync();
        }

        public async Task<IEnumerable<VehicleModelByVehicleBrand>> GetVehicleModelByVehicleBrandAsync(string vehicleModelByVehicleBrand)
        {
            return await _declareVehicleAccidentRepository.GetVehicleModelByVehicleBrandAsync(vehicleModelByVehicleBrand);
        }
        #endregion


        #region [ DECLARE VEHICLE ACCIDENT METHODS ]
        public async Task<bool> InsertDeclareVehicleAccidentAsync(DeclareVehicleAccident declareVehicleAccident)
        {
            return await _declareVehicleAccidentRepository.InsertDeclareVehicleAccidentAsync(declareVehicleAccident);
        }

        public async Task<bool> InsertDeclareVehicleAccidentAttachmentsAsync(CommunicationAttachments declareVehicleAccidentAttachments)
        {
            return await _declareVehicleAccidentRepository.InsertDeclareVehicleAccidentAttachmentsAsync(declareVehicleAccidentAttachments);
        }

        public async Task<bool> InsertDeclareVehicleAccidentActionsAsync(DeclareVehicleAccidentActions declareVehicleAccidentActions)
        {
            return await _declareVehicleAccidentRepository.InsertDeclareVehicleAccidentActionsAsync(declareVehicleAccidentActions);
        }

        public async Task<IEnumerable<StateAccident>> GetAllStateAccidentAsync()
        {
            return await _declareVehicleAccidentRepository.GetAllStateAccidentAsync();
        }

        public async Task<ViewClaim> GetViewClaimByIdAsync(string viewClaimById)
        {
            return await _declareVehicleAccidentRepository.GetViewClaimByIdAsync(viewClaimById);
        }
        #endregion


        #region [ INVESTIGATION RECORD METHODS ]
        public async Task<bool> InsertInvestigationRecordAsync(InvestigationRecord investigationRecord)
        {
            return await _declareVehicleAccidentRepository.InsertInvestigationRecordAsync(investigationRecord);
        }
        #endregion


        #region [ COMMUNICATIONS HISTORY METHODS ]
        public async Task<bool> InsertCommunicationsHistoryAsync(CommunicationsHistory communicationsHistory)
        {
            return await _declareVehicleAccidentRepository.InsertCommunicationsHistoryAsync(communicationsHistory);
        }
        #endregion


        #region [ ORGANISM METHODS ]
        public async Task<bool> InsertOrganismAsync(Organism organism)
        {
            return await _declareVehicleAccidentRepository.InsertOrganismAsync(organism);
        }
        #endregion


        #region [ INSURER METHODS ]
        public async Task<IEnumerable<InsurerByCountry>> GetInsurerByCountryIdAsync(string insurerByCountryId)
        {
            return await _declareVehicleAccidentRepository.GetInsurerByCountryIdAsync(insurerByCountryId);
        }
        #endregion


        #region [ CLAIMS MANAGER ]
        public async Task<IEnumerable<GetAllIncidence>> GetAllIncidenceAsync()
        {
            return await _declareVehicleAccidentRepository.GetAllIncidenceAsync();
        }



        #endregion

        #endregion
    }
}
