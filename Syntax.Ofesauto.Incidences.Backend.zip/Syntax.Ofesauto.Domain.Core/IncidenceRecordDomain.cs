﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.Incidence.Application.Main;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
//using System.Data.Entity;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class IncidenceRecordDomain : IIncidenceRecordDomain
    {


        private readonly IRepository<IncidenceRecord> _repository;
        private readonly CustomDataContext _customDataContext;

        public IncidenceRecordDomain(IRepository<IncidenceRecord> repository, CustomDataContext customDataContext)
        {
            _repository = repository;
            _customDataContext = customDataContext;
        }

        public Task<IncidenceRecord> Add(IncidenceRecord obj)
        {
            return _repository.Add(obj);
        }

        public Task<bool> Delete(int id)
        {
            return _repository.Delete(id);
        }

        public Task<bool> DeleteLogicalByState(int id)
        {
            return _repository.DeleteLogicalByState(id);
        }

        public Task<List<IncidenceRecord>> GetAll()
        {
            return _repository.GetAll();
        }

        public Task<List<IncidenceRecord>> GetAllIncidences()
        {
            
            return _customDataContext.IncidenceRecord.Include(m => m.IncidenceRecordType).ToListAsync();
            
        }

        public Task<IncidenceRecord> GetById(int id)
        {
            return _repository.GetById(id);
        }

        public Task<List<IncidenceRecord>> GetByParam(Func<IncidenceRecord, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<IncidenceRecord> GetByParamFirst(Func<IncidenceRecord, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<IncidenceRecord> GetIncidenceById(int id)
        {
            //return _repository.GetById(id);
            return _customDataContext.IncidenceRecord.Include(i => i.IncidenceRecordType).FirstOrDefaultAsync(d => d.IncidenceRecordId == id);

        }

        //public Task<List<IncidenceRecord>> GetIncidenceById(int id)
        //{
        //    return _customDataContext.FindAsync();
        //}

        public Task<List<HistoryIncident>> GetTrazabilityIncidenceById(int incidenceId)
        {
            return null;
        }

        public Task<IncidenceRecord> Update(IncidenceRecord obj, int id)
        {
            return _repository.Update(obj, id);
        }
    }
}
