﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class CommunicationAttachmentsDomain : ICommunicationAttachmentsDomain
    {
        private readonly IRepository<CommunicationAttachments> _repository;
        public CommunicationAttachmentsDomain(IRepository<CommunicationAttachments> repository)
        {
            _repository = repository;
        }
        public async Task<CommunicationAttachments> Add(CommunicationAttachments obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<List<CommunicationAttachments>> AddList(List<CommunicationAttachments> obj)
        {
            return await _repository.AddList(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<CommunicationAttachments>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<CommunicationAttachments> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public async Task<List<CommunicationAttachments>> GetByParam(Func<CommunicationAttachments, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<CommunicationAttachments> GetByParamFirst(Func<CommunicationAttachments, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<CommunicationAttachments> Update(CommunicationAttachments obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
