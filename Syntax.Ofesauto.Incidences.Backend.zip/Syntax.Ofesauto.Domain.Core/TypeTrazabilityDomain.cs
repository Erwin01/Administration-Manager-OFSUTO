﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Domain.Interface;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Core
{
    public class TypeTrazabilityDomain : ITypeTrazabilityDomain
    {
        private readonly IRepository<TypeTrazability> _repository;
        public TypeTrazabilityDomain(IRepository<TypeTrazability> repository)
        {
            _repository = repository;
        }
        public async Task<TypeTrazability> Add(TypeTrazability obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<TypeTrazability>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<TypeTrazability> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public async Task<List<TypeTrazability>> GetByParam(Func<TypeTrazability, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<TypeTrazability> GetByParamFirst(Func<TypeTrazability, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<TypeTrazability> Update(TypeTrazability obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
