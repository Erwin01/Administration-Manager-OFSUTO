﻿using AutoMapper;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Domain.Entity;

namespace Syntax.Ofesauto.Incidence.Transversal.Mapper
{

    /// <summary>
    /// Method that allows mapping automatically between data objects and business entities.
    /// </summary>
    /// 
    public class MappingProfile : Profile
    {

        #region [ CONSTRUCTOR ]
        public MappingProfile()
        {

            //CreateMap<VehicleModel, VehicleModelDTO>().ReverseMap();
            //CreateMap<VehicleCategory, VehicleCategoryDTO>().ReverseMap();
            //CreateMap<VehicleModelByVehicleBrand, VehicleModelByVehicleBrandDTO>().ReverseMap();
            //CreateMap<VehicleBrand, VehicleBrandDTO>().ReverseMap();
            //CreateMap<StateAccident, StateAccidentDTO>().ReverseMap();
            //CreateMap<DeclareVehicleAccident, DeclareVehicleAccidentDTO>().ReverseMap();
            //CreateMap<CommunicationAttachments, CommunicationAttachmentsDTO>().ReverseMap();
            //CreateMap<Insurer, InsurerDTO>().ReverseMap();
            //CreateMap<Country, CountryDTO>().ReverseMap();
            //CreateMap<InsurerByCountry, InsurerByCountryDTO>().ReverseMap();
            //CreateMap<Organism, OrganismDTO>().ReverseMap();
            //CreateMap<DeclareVehicleAccidentActions, DeclareVehicleAccidentActionsDTO>().ReverseMap();
            //CreateMap<InvestigationRecord, InvestigationRecordDTO>().ReverseMap();
            //CreateMap<CommunicationsHistory, CommunicationsHistoryDTO>().ReverseMap();
            //CreateMap<GetAllIncidence, GetAllIncidenceDTO>().ReverseMap();
            //CreateMap<ViewClaim, ViewClaimDTO>().ReverseMap();
            CreateMap<IncidenceRecord, IncidenceRecordDTO>().ReverseMap();


            //CreateMap<VehicleModel, VehicleModelDTO>().ReverseMap()
            //    .ForMember(destination => destination.VehicleModelId, source => source.MapFrom(src => src.VehicleModelId))
            //    .ForMember(destination => destination.ModelName, source => source.MapFrom(src => src.ModelName))
            //    .ForMember(destination => destination.ModelNamEnglish, source => source.MapFrom(src => src.ModelNamEnglish));


            //CreateMap<VehicleCategory, VehicleCategoryDTO>().ReverseMap()
            //    .ForMember(destination => destination.VehicleCategoryId, source => source.MapFrom(src => src.VehicleCategoryId))
            //    .ForMember(destination => destination.CategoryName, source => source.MapFrom(src => src.CategoryName))
            //    .ForMember(destination => destination.CategoryNamEnglish, source => source.MapFrom(src => src.CategoryNamEnglish));


            //CreateMap<VehicleBrand, VehicleBrandDTO>().ReverseMap()
            //    .ForMember(destination => destination.VehicleBrandId, source => source.MapFrom(src => src.VehicleBrandId))
            //    .ForMember(destination => destination.BrandName, source => source.MapFrom(src => src.BrandName))
            //    .ForMember(destination => destination.BrandNamEnglish, source => source.MapFrom(src => src.BrandNamEnglish));


            //CreateMap<StateAccident, StateAccidentDTO>().ReverseMap()
            //    .ForMember(destination => destination.StateId, source => source.MapFrom(src => src.StateId))
            //    .ForMember(destination => destination.StateName, source => source.MapFrom(src => src.StateName))
            //    .ForMember(destination => destination.StateNamEnglish, source => source.MapFrom(src => src.StateNamEnglish));


            //CreateMap<DeclareVehicleAccident, DeclareVehicleAccidentDTO>().ReverseMap()
            //    .ForMember(destination => destination.ClaimantReference, source => source.MapFrom(src => src.ClaimantReference))
            //    .ForMember(destination => destination.DocumentTypeId, source => source.MapFrom(src => src.DocumentTypeId))
            //    .ForMember(destination => destination.ApplicationType, source => source.MapFrom(src => src.ApplicationType))
            //    .ForMember(destination => destination.AccidentDate, source => source.MapFrom(src => src.AccidentDate))
            //    .ForMember(destination => destination.AccidentCountryId, source => source.MapFrom(src => src.AccidentCountryId))
            //    .ForMember(destination => destination.AccidentRegionId, source => source.MapFrom(src => src.AccidentRegionId))
            //    .ForMember(destination => destination.AccidentVersion, source => source.MapFrom(src => src.AccidentVersion))
            //    .ForMember(destination => destination.ReasonForOpeningId, source => source.MapFrom(src => src.ReasonForOpeningId))
            //    .ForMember(destination => destination.CauseVehicleCategoryId, source => source.MapFrom(src => src.CauseVehicleCategoryId))
            //    .ForMember(destination => destination.CauseVehicleBrandId, source => source.MapFrom(src => src.CauseVehicleBrandId))
            //    .ForMember(destination => destination.CauseVehicleModelId, source => source.MapFrom(src => src.CauseVehicleModelId))
            //    .ForMember(destination => destination.CauseVehicleRegistration, source => source.MapFrom(src => src.CauseVehicleRegistration))
            //    .ForMember(destination => destination.CauseCountryRegistrationId, source => source.MapFrom(src => src.CauseCountryRegistrationId))
            //    .ForMember(destination => destination.CauseInsuranceCompanyId, source => source.MapFrom(src => src.CauseInsuranceCompanyId))
            //    .ForMember(destination => destination.CauseNumberPolicy, source => source.MapFrom(src => src.CauseNumberPolicy))
            //    .ForMember(destination => destination.CauseAddress, source => source.MapFrom(src => src.CauseAddress))
            //    .ForMember(destination => destination.Comments, source => source.MapFrom(src => src.Comments))
            //    .ForMember(destination => destination.StateId, source => source.MapFrom(src => src.StateId))
            //    .ForMember(destination => destination.AffectedVehicleBrandId, source => source.MapFrom(src => src.AffectedVehicleBrandId))
            //    .ForMember(destination => destination.AffectedVehicleCategoryId, source => source.MapFrom(src => src.AffectedVehicleCategoryId))
            //    .ForMember(destination => destination.AffectedVehicleModelId, source => source.MapFrom(src => src.AffectedVehicleModelId))
            //    .ForMember(destination => destination.AffectedVehicleRegistration, source => source.MapFrom(src => src.AffectedVehicleRegistration))
            //    .ForMember(destination => destination.AffectedCountryRegistrationId, source => source.MapFrom(src => src.AffectedCountryRegistrationId))
            //    .ForMember(destination => destination.AffectedInsuranceCompanyId, source => source.MapFrom(src => src.AffectedInsuranceCompanyId))
            //    .ForMember(destination => destination.AffectedNumberPolicy, source => source.MapFrom(src => src.AffectedNumberPolicy))
            //    .ForMember(destination => destination.AffectedName, source => source.MapFrom(src => src.AffectedName))
            //    .ForMember(destination => destination.AffectedSurname, source => source.MapFrom(src => src.AffectedSurname))
            //    .ForMember(destination => destination.AffectedAddress, source => source.MapFrom(src => src.AffectedAddress))
            //    .ForMember(destination => destination.AffectedCityId, source => source.MapFrom(src => src.AffectedCityId))
            //    .ForMember(destination => destination.AffectedRegionId, source => source.MapFrom(src => src.AffectedRegionId))
            //    .ForMember(destination => destination.AffectedEmail, source => source.MapFrom(src => src.AffectedEmail))
            //    .ForMember(destination => destination.AffectedPhoneNumber, source => source.MapFrom(src => src.AffectedPhoneNumber))
            //    .ForMember(destination => destination.AffectedDamageMaterials, source => source.MapFrom(src => src.AffectedDamageMaterials))
            //    .ForMember(destination => destination.AffectedDamagePersonals, source => source.MapFrom(src => src.AffectedDamagePersonals))
            //    .ForMember(destination => destination.AcceptRgpd, source => source.MapFrom(src => src.AcceptRgpd));


            //CreateMap<CommunicationAttachments, CommunicationAttachmentsDTO>().ReverseMap()
            //    .ForMember(destination => destination.AttachmentId, source => source.MapFrom(src => src.AttachmentId))
            //    .ForMember(destination => destination.CommunicationsHistoryId, source => source.MapFrom(src => src.CommunicationsHistoryId))
            //    .ForMember(destination => destination.AttachmentDate, source => source.MapFrom(src => src.AttachmentDate))
            //    .ForMember(destination => destination.AttachmentFileName, source => source.MapFrom(src => src.AttachmentFileName))
            //    .ForMember(destination => destination.AttachmentPath, source => source.MapFrom(src => src.AttachmentPath))
            //    .ForMember(destination => destination.AttachmentDescription, source => source.MapFrom(src => src.AttachmentDescription))
            //    .ForMember(destination => destination.CreateDate, source => source.MapFrom(src => src.CreateDate))
            //    .ForMember(destination => destination.UpdateDate, source => source.MapFrom(src => src.UpdateDate));


            //CreateMap<Insurer, InsurerDTO>().ReverseMap()
            //    //.ForMember(destination => destination.InsurerId, source => source.MapFrom(src => src.InsurerId))
            //    .ForMember(destination => destination.InsurerCode, source => source.MapFrom(src => src.InsurerCode))
            //    .ForMember(destination => destination.InsurerAddress, source => source.MapFrom(src => src.InsurerAddress))
            //    .ForMember(destination => destination.InsurerPostalCode, source => source.MapFrom(src => src.InsurerPostalCode))
            //    .ForMember(destination => destination.InsurerCountryId, source => source.MapFrom(src => src.InsurerCountryId))
            //    .ForMember(destination => destination.InsurerPhone, source => source.MapFrom(src => src.InsurerPhone))
            //    .ForMember(destination => destination.InsurerEmail, source => source.MapFrom(src => src.InsurerEmail))
            //    .ForMember(destination => destination.InsurerFax, source => source.MapFrom(src => src.InsurerFax))
            //    .ForMember(destination => destination.InsurerNif, source => source.MapFrom(src => src.InsurerNif))
            //    .ForMember(destination => destination.CreatedDate, source => source.MapFrom(src => src.CreatedDate))
            //    .ForMember(destination => destination.UpdatedDate, source => source.MapFrom(src => src.UpdatedDate));


            //CreateMap<Country, CountryDTO>().ReverseMap()
            //    .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
            //    .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
            //    .ForMember(destination => destination.PhoneCodeId, source => source.MapFrom(src => src.PhoneCodeId))
            //    .ForMember(destination => destination.CreatedDate, source => source.MapFrom(src => src.CreatedDate))
            //    .ForMember(destination => destination.UpdatedDate, source => source.MapFrom(src => src.UpdatedDate));


            //CreateMap<InsurerByCountry, InsurerByCountryDTO>().ReverseMap()
            //    .ForMember(destination => destination.InsurerId, source => source.MapFrom(src => src.InsurerId))
            //    .ForMember(destination => destination.InsurerCode, source => source.MapFrom(src => src.InsurerCode))
            //    .ForMember(destination => destination.InsurerName, source => source.MapFrom(src => src.InsurerName));


            //CreateMap<Organism, OrganismDTO>().ReverseMap()
            //   .ForMember(destination => destination.OrganismTypeId, source => source.MapFrom(src => src.OrganismTypeId))
            //   .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
            //   .ForMember(destination => destination.RegionId, source => source.MapFrom(src => src.RegionId))
            //   .ForMember(destination => destination.CityId, source => source.MapFrom(src => src.CityId))
            //   .ForMember(destination => destination.OrganismName, source => source.MapFrom(src => src.OrganismName))
            //   .ForMember(destination => destination.OrganismLastName, source => source.MapFrom(src => src.OrganismLastName))
            //   .ForMember(destination => destination.OrganismAddress, source => source.MapFrom(src => src.OrganismAddress))
            //   .ForMember(destination => destination.OrganismPostalCode, source => source.MapFrom(src => src.OrganismPostalCode))
            //   .ForMember(destination => destination.OrganismCIF, source => source.MapFrom(src => src.OrganismCIF))
            //   .ForMember(destination => destination.OrganismWebSite, source => source.MapFrom(src => src.OrganismWebSite))
            //   .ForMember(destination => destination.OrganismCode, source => source.MapFrom(src => src.OrganismCode))
            //   .ForMember(destination => destination.OrganismSubTypeId, source => source.MapFrom(src => src.OrganismSubTypeId));


            //CreateMap<InvestigationRecord, InvestigationRecordDTO>().ReverseMap()
            //    .ForMember(destination => destination.InvestigationRecordNumber, source => source.MapFrom(src => src.InvestigationRecordNumber))
            //    .ForMember(destination => destination.DeclareVehicleAccidentId, source => source.MapFrom(src => src.DeclareVehicleAccidentId))
            //    .ForMember(destination => destination.StateId, source => source.MapFrom(src => src.StateId));


            //CreateMap<CommunicationsHistory, CommunicationsHistoryDTO>().ReverseMap()
            //    .ForMember(destination => destination.CommunicationId, source => source.MapFrom(src => src.CommunicationId))
            //    .ForMember(destination => destination.CommunicationTo, source => source.MapFrom(src => src.CommunicationTo))
            //    .ForMember(destination => destination.CommunicationSubject, source => source.MapFrom(src => src.CommunicationSubject))
            //    .ForMember(destination => destination.CommunicationText, source => source.MapFrom(src => src.CommunicationText))
            //    .ForMember(destination => destination.CommunicationFileNameHtml, source => source.MapFrom(src => src.CommunicationFileNameHtml))
            //    .ForMember(destination => destination.CommunicationFrom, source => source.MapFrom(src => src.CommunicationFrom));


            //CreateMap<GetAllIncidence, GetAllIncidenceDTO>().ReverseMap()
            //   .ForMember(destination => destination.AccidentDate, source => source.MapFrom(src => src.AccidentDate))
            //   .ForMember(destination => destination.CreatedDate, source => source.MapFrom(src => src.CreatedDate))
            //   .ForMember(destination => destination.ClaimantReference, source => source.MapFrom(src => src.ClaimantReference))
            //   .ForMember(destination => destination.CauseVehicleRegistration, source => source.MapFrom(src => src.CauseVehicleRegistration))
            //   .ForMember(destination => destination.StateName, source => source.MapFrom(src => src.StateName))
            //   .ForMember(destination => destination.CommunicationDate, source => source.MapFrom(src => src.CommunicationDate))
            //   .ForMember(destination => destination.CommunicationSubject, source => source.MapFrom(src => src.CommunicationSubject))
            //   .ForMember(destination => destination.CommunicationFileNameHtml, source => source.MapFrom(src => src.CommunicationFileNameHtml))
            //   .ForMember(destination => destination.CommunicationFrom, source => source.MapFrom(src => src.CommunicationFrom));


        }
        #endregion
    }

}
