﻿using Syntax.Ofesauto.Incidence.Application.DTO;

namespace Syntax.Ofesauto.Incidence.Application.Interface
{
    public interface IUserApplication : IGenericApplication<UserDTO>
    {
    }
}
