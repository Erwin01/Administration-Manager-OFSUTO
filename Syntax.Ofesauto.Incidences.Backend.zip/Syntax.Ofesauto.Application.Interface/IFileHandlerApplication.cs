﻿using Microsoft.AspNetCore.Http;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Interface
{
    public interface IFileHandlerApplication
    {
        Task<Response<List<FileUploadDto>>> SaveAllFiles(List<IFormFile> List);
    }
}
