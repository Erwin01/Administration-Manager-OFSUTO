﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Interface
{

    #region [ IDECLAREVEHICLEACCIDENT APPLICATION ]
    public interface IDeclareVehicleAccidentApplication
    {

        #region [ ASYNCHRONOUS METHODS ]

        #region [ VEHICLE METHODS ]
        Task<Response<IEnumerable<VehicleCategoryDTO>>> GetAllVehicleCategoryAsync();
        Task<Response<IEnumerable<VehicleBrandDTO>>> GetAllVehicleBrandAsync();
        Task<Response<IEnumerable<VehicleModelByVehicleBrandDTO>>> GetVehicleModelByVehicleBrandAsync(string vehicleModelByVehicleBrand);
        #endregion


        #region [ DECLARE VEHICLE ACCIDENT METHODS ]
        Task<Response<bool>> InsertDeclareVehicleAccidentAsync(GetIncidenceTrazabilityDTO declareVehicleAccidentDTO);
        Task<Response<bool>> InsertDeclareVehicleAccidentAttachmentsAsync(CommunicationAttachmentsDTO declareVehicleAccidentAttachmentsDTO);
        Task<Response<bool>> InsertDeclareVehicleAccidentActionsAsync(DeclareVehicleAccidentActionsDTO declareVehicleAccidentActionsDTO);
        Task<Response<ViewClaimDTO>> GetViewClaimByIdAsync(string viewClaimById);

        #endregion


        #region [ COMMUNICATIONS HISTORY METHODS]
        Task<Response<bool>> InsertCommunicationsHistoryAsync(CommunicationsHistoryDTO communicationsHistoryDTO);
        #endregion


        #region [ INVESTIGATION RECORD METHODS ]
        Task<Response<bool>> InsertInvestigationRecordAsync(InvestigationRecordDTO investigationRecordDTO);
        #endregion


        #region [ STATE ACCIDENT METHODS ]
        Task<Response<IEnumerable<StateAccidentDTO>>> GetAllStateAccidentAsync();
        #endregion


        #region [ ORGANISM METHODS ]
        Task<Response<bool>> InsertOrganismAsync(OrganismDTO organismDTO);
        #endregion


        #region [ INSURER METHODS]
        Task<Response<IEnumerable<InsurerByCountryDTO>>> GetInsurerByCountryIdAsync(string insurerByCountryId);
        #endregion


        #region [ CLAIMS MAMAGER METHODS ]
        Task<Response<IEnumerable<GetAllIncidenceDTO>>> GetAllIncidenceAsync();
        #endregion


        #endregion
    }
}
#endregion
