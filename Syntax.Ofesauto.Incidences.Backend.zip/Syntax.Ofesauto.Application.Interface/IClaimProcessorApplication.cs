﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Interface
{
    public interface IClaimProcessorApplication : IGenericApplication<ClaimProcessorDTO>
    {
        Task<Response<List<ResponseTrazabilityDTO>>> GetTrazabilityByProccess(int proccessId);
    }
}
