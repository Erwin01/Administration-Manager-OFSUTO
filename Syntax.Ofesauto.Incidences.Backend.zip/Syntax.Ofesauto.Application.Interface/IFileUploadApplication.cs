﻿using Microsoft.AspNetCore.Http;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Interface
{
    public interface IFileUploadApplication
    {
        Task<Response<string>> Upload(IFormFile file, string path);
    }
}
