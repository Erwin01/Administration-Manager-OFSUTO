﻿using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Application.Interface
{
    public interface ISettingsApplication : IGenericApplication<SettingsDTO>
    {
        Task<Response<SettingsDTO>> GetByNameSetting(string name);
    }
}
