﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.Incidence.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class VehicleController : ControllerBase
    {

        private readonly ILogger<VehicleController> _logger;
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;
        public VehicleController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication, ILogger<VehicleController> logger)
        {
            _logger = logger;
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;
        }

        //#region [ VEHICLE METHODS ]
        //[HttpGet]
        //public async Task<IActionResult> GetAllVehicleCategoryAsync()
        //{

        //    var response = await _declareVehicleAccidentApplication.GetAllVehicleCategoryAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllVehicleBrandAsync()
        //{

        //    var response = await _declareVehicleAccidentApplication.GetAllVehicleBrandAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}


        //[HttpGet]
        //public async Task<IActionResult> GetVehicleModelByVehicleBrandAsync(string vehicleBrandId)
        //{

        //    if (string.IsNullOrEmpty(vehicleBrandId))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _declareVehicleAccidentApplication.GetVehicleModelByVehicleBrandAsync(vehicleBrandId);


        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}

        //#endregion
    }
}
