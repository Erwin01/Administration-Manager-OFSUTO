﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.Incidence.Application.DTO;
using Syntax.Ofesauto.Incidence.Application.Interface;
using Syntax.Ofesauto.Incidence.Transversal.Common;
using Syntax.Ofesauto.Security.Services.Api.Helpers;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Api.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("[controller]/[action]")]
    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class DeclareVehicleAccidentController : CustomControllerBase
    {

        private readonly ILogger<DeclareVehicleAccidentController> _logger;
        private readonly IDeclareVehicleAccident_Application _declareVehicleAccidentService;
        private readonly ISettingsApplication _setting;
        public DeclareVehicleAccidentController(
            IDeclareVehicleAccident_Application declareVehicleAccidentService,
            ISettingsApplication setting,
        ILogger<DeclareVehicleAccidentController> logger)
        {
            _logger = logger;
            //GetDataUser();
            _setting = setting;
            _declareVehicleAccidentService = declareVehicleAccidentService;
        }

        //[HttpGet]
        //public async Task<IActionResult> GetAll()
        //{
        //    GetDataUser();
        //    var response = new Response<List<DeclareVehicleAccidentDTO>>();
        //    if (user.UserTypeId > 2)
        //    {
        //        response = await _declareVehicleAccidentService.GetAllWithTrazabilityByUserId(user.Id);
        //    }
        //    else
        //    {
        //        response = await _declareVehicleAccidentService.GetAllWithTrazability();
        //    }

        //    if (response.IsSuccess)
        //    {
        //        var mapp = AutoMapp<DeclareVehicleAccidentDTO, ResponseActionsHistoryDTO>.ConvertList2(response.Data);
        //        var responseData = new Response<List<ResponseActionsHistoryDTO>> { Data = mapp, IsSuccess = true, Message = "Success" };

        //        return Ok(responseData);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}

        //[HttpGet]
        //public async Task<IActionResult> GetRecordsToBeClassified()
        //{

        //    var response = await _declareVehicleAccidentService.GetRecordsToBeClassified();
        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}
        //[HttpGet]
        //public async Task<IActionResult> GetRecordsHistory()
        //{

        //    var response = await _declareVehicleAccidentService.GetRecordsHistory();
        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}

        //[HttpGet]
        //public async Task<IActionResult> GetById(int id)
        //{

        //    var response = await _declareVehicleAccidentService.GetById(id);
        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}

        //[HttpPost]
        //public async Task<IActionResult> RejectClaim([FromBody] RejectClaimDTO claim)
        //{
        //    GetDataUser();
        //    claim.UserId = user.Id;
        //    claim.Email = user.Email;
        //    var response = await _declareVehicleAccidentService.RejectClaim(claim);
        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpPost]
        //public async Task<IActionResult> AssignClaim([FromBody] AssignClaimDTO claim)
        //{
        //    GetDataUser();
        //    claim.UserId = user.Id;
        //    claim.Email = user.Email;

        //    var response = await _declareVehicleAccidentService.AssignClaim(claim);
        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}
        //[HttpPost]
        //public async Task<IActionResult> InsertDeclareVehicleAccidentAsync([FromForm] CreateDeclareVehicleAccidentDTO declareVehicleAccidentDTO)
        //{

        //    if (declareVehicleAccidentDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");
        //    }
        //    if (declareVehicleAccidentDTO.AccidentDate.Date > DateTime.Now.Date)
        //    {
        //        return BadRequest("Fecha del accidente no puede ser mayor a la fecha del sistema");
        //    }
        //    GetDataUser();
        //    declareVehicleAccidentDTO.UserId = user.Id;
        //    declareVehicleAccidentDTO.EmailSender = user.Email;
        //    //foreach (var item in files)
        //    //{
        //    //    declareVehicleAccidentDTO.Files.Add(new IFormFile {  = item.FielName});
        //    //}
        //    if (!declareVehicleAccidentDTO.AcceptRgpd)
        //    {
        //        return Forbid("Aceptar tratamiento de datos personales es requerido");
        //    }
        //    //declareVehicleAccidentDTO.Files = File;
        //    var mapp = AutoMapp<CreateDeclareVehicleAccidentDTO, DeclareVehicleAccidentDTO>.Convert(declareVehicleAccidentDTO);
        //    var response = await _declareVehicleAccidentService.Add(mapp);
        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.LogError);
        //    }
        //}

        /*[HttpDelete]
        public async Task<IActionResult> RemoveDeclarevehicleAccident(int id)
        {
            var response = await _declareVehicleAccidentService.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }*/
    }
}
