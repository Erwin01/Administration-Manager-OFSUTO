﻿using Syntax.Ofesauto.Incidence.Domain.Entity;

namespace Syntax.Ofesauto.Incidence.Domain.Interface
{
    public interface IActionTypeDomain : IGenericDomain<ActionType>
    {
    }
}
