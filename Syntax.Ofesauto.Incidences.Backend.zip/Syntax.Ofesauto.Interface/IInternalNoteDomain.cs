﻿using Syntax.Ofesauto.Incidence.Domain.Entity;

namespace Syntax.Ofesauto.Incidence.Domain.Interface
{
    public interface IInternalNoteDomain : IGenericDomain<InternalNote>
    {
    }
}
