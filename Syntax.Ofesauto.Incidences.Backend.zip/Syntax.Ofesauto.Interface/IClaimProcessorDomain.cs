﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Interface
{
    public interface IClaimProcessorDomain : IGenericDomain<ClaimProcessor>
    {
        Task<List<ResponseTrazability>> GetTrazabilityByProccess(int proccessId);
        void Dispose();
    }
}
