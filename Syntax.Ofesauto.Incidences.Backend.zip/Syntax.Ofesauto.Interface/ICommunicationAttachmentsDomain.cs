﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Interface
{
    public interface ICommunicationAttachmentsDomain : IGenericDomain<CommunicationAttachments>
    {
        Task<List<CommunicationAttachments>> AddList(List<CommunicationAttachments> obj);
    }
}
