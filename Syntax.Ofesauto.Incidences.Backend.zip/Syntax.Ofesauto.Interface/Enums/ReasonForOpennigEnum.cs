﻿namespace Syntax.Ofesauto.Incidence.Domain.Interface.Enums
{
    public enum ReasonForOpennig : int
    {
        SolicitudDeInformacion = 1,
        SolicitudIndemnizacion = 2
    }
}
