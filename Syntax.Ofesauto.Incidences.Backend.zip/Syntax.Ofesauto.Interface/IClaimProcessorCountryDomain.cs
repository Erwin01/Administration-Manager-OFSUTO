﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Interface
{
    public interface IClaimProcessorCountryDomain : IGenericDomain<ClaimProcessorCountry>
    {
        Task<List<ResponseClaimsByCountry>> GetListClaimsByCountry();
    }
}
