﻿using Syntax.Ofesauto.Incidence.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Domain.Interface
{
    public interface IIncidenceRecordDomain : IGenericDomain<IncidenceRecord>
    {
        Task<List<IncidenceRecord>> GetAllIncidences();
        Task<IncidenceRecord> GetIncidenceById(int id);
    }
}
