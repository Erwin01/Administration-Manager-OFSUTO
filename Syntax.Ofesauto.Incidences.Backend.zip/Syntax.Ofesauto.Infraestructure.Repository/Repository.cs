﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.Incidence.Application.Main;
using Syntax.Ofesauto.Incidence.Domain.Entity;
using Syntax.Ofesauto.Incidence.Infraestructure.Interface;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Incidence.Infraestructure.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly CustomDataContext _context;

        enum IsDeleted
        {
            IncidenceClassify,
            IncidenceType
        }

        public Repository(CustomDataContext context)
        {
            this._context = context;
        }


        public async Task<T> Add(T obj)
        {
            _context.Set<T>().Add(obj);
            await _context.SaveChangesAsync();
            //_context.Dispose();
            return obj;
        }


        public async Task<List<T>> AddList(List<T> obj)
        {
            await _context.Set<T>().AddRangeAsync(obj);
            await _context.SaveChangesAsync();
            return obj;
        }


        public async Task<bool> Delete(int id)
        {
            var result = false;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            var item = _context.Set<T>().Find(id);

            if (item != null)
            {
                
                _context.Set<T>().Remove(item);
                //TODO: crear uno propio
                //await IsDeletedIncidenceStates(id);
                //await IsDeletedIncidenceClassify(id);
                await _context.SaveChangesAsync();
                result = true;
            }

            return result;
        }


        public async Task<List<T>> GetAll()
        {
            var item = _context.Set<T>();
            return await item.ToListAsync();
        }


        public async Task<T> GetById(int id)
        {

            return await _context.Set<T>().FindAsync(id);

        }


        //TODO: Cuando hacer un Where con tu arquitectura, con un campo que no sea id. La idea es no dañar lo que se tiene(GetById) o validar token con los datos usuario.
        public async Task<List<IncidenceRecord>> GetIncedentsByUserId(int id)
        {
            //Obtener todas las incidencias de un tramitador
            return await _context.Set<IncidenceRecord>().Where(i => i.UserId == id).ToListAsync();

        }


        //public async Task<T> GetByParamFirst(Func<T, bool> pre)
        //{
        //    _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        //    var item = _context.Set<T>().Where(pre);
        //    return item.FirstOrDefault();

        //}


        //public async Task<List<T>> GetByParam(Func<T, bool> pre)
        //{
        //    _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        //    var item = _context.Set<T>().Where(pre);
        //    return item.ToList();

        //}


        //public async Task<T> GetByParamLast(Func<T, bool> pre)
        //{
        //    _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        //    var item = _context.Set<T>().Where(pre);
        //    return item.LastOrDefault();

        //}


        public void Save(T obj, int id)
        {
            _context.SaveChanges();
        }

        public async Task<T> Update(T obj, int id)
        {
            var x = _context.Entry(obj);
            _context.Set<T>().Attach(obj);
            x.State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return obj;

        }

        /// <summary>
        /// Logical Erase / Unchanged Database
        /// </summary>
        /// <param name="id"></param>
        /// <returns> True </returns>
        //public async Task IsDeletedIncidenceClassify(int id)
        //{
        //    var item = _context.Set<T>().Find(id);

        //    _context.Set<T>().Attach(item);

        //    var x = _context.Entry(item);
        //    var isDeleted = _context.IncidenceClassify.First(d => d.IncidenceClassifyId == id);
        //    isDeleted.IsDeleted = true;
        //    x.State = EntityState.Unchanged;
        //    x.CurrentValues["IsDeleted"] = true;
        //    await _context.SaveChangesAsync();

        //}

        /// <summary>
        /// Logical Erase / Unchanged Database
        /// </summary>
        /// <param name="id"></param>
        /// <returns> True </returns>
        public async Task IsDeletedIncidenceStates(int id)
        {
            var stateDelete = await  _context.OfesautoStates.FirstOrDefaultAsync(s => s.OfesautoStatesName == "Eliminado");

            var incidence = await _context.IncidenceRecord.FirstAsync(i => i.IncidenceRecordId == id);

            incidence.OfesautoStatesId = stateDelete.OfesautoStatesId;

            _context.Update(incidence);
            await _context.SaveChangesAsync();
            
            //var item = _context.Set<T>().Find(id);

            //_context.Set<T>().Attach(item);

            //var x = _context.Entry(item);
            //var isDeleted = _context.IncidenceRecord.First(d => d.);
            //isDeleted.OfesautoStatesId = id;
            //x.State = EntityState.Unchanged;
            //x.CurrentValues["IsDeleted"] = true;
            //await _context.SaveChangesAsync();

        }

        /// <summary>
        /// Logical Erase With States
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> DeleteLogicalByState(int id)
        {
            var result = false;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            var item = _context.Set<T>().Find(id);

            if (item != null)
            {
                var stateDelete = await _context.OfesautoStates.FirstOrDefaultAsync(s => s.OfesautoStatesName == "Eliminado");
                var incidence = await _context.IncidenceRecord.FirstAsync(i => i.IncidenceRecordId == id);

                incidence.OfesautoStatesId = stateDelete.OfesautoStatesId;

                _context.Update(incidence);
                await _context.SaveChangesAsync();
                result = true;
            }

            return result;
        }
    }
}
