﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.Incidence.Infraestructure.Data.Migrations
{
    public partial class MigrationAddFieldIncedenceRecordIsDeleted : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "IncidenceRecord",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "IncidenceRecord");
        }
    }
}
