﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.Incidence.Infraestructure.Data.Migrations
{
    public partial class MigrationIncidenceTypeDataTypeNote : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AffectedVehicleRegistration",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CauseVehicleRegistration",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ClaimManagerId",
                table: "IncidenceRecord",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ClaimProcessorId",
                table: "IncidenceRecord",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "IncidenceRecordLastName",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "IncidenceRecordName",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "OrganismId",
                table: "IncidenceRecord",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "InternalNote",
                columns: table => new
                {
                    InternalNoteId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OfesautoProcessId = table.Column<int>(type: "int", nullable: false),
                    IdentificationRegister = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InternalNote", x => x.InternalNoteId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "InternalNote");

            migrationBuilder.DropColumn(
                name: "AffectedVehicleRegistration",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "CauseVehicleRegistration",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "ClaimManagerId",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "ClaimProcessorId",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "IncidenceRecordLastName",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "IncidenceRecordName",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "OrganismId",
                table: "IncidenceRecord");
        }
    }
}
