﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.Incidence.Infraestructure.Data.Migrations
{
    public partial class AddFieldOfesautoStatesIdAndTablesOfesautoStatesOfesautoStatesProcess : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "IncidenceRecord");

            migrationBuilder.AddColumn<int>(
                name: "OfesautoStateId",
                table: "IncidenceRecord",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "OfesautoStatesId",
                table: "IncidenceRecord",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "OfesautoProcess",
                columns: table => new
                {
                    OfesautoProcessId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OfesautoProcessName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OfesautoProcessNamEnglish = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OfesautoProcessDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OfesautoProcess", x => x.OfesautoProcessId);
                });

            migrationBuilder.CreateTable(
                name: "OfesautoStates",
                columns: table => new
                {
                    OfesautoStatesId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OfesautoStatesName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    OfesautoStatesNamEnglish = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    OfesautoStatesDescription = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OfesautoStates", x => x.OfesautoStatesId);
                });

            migrationBuilder.CreateTable(
                name: "OfesautoStatesProcess",
                columns: table => new
                {
                    OfesautoStatesProcessId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OfesautoProcessId = table.Column<int>(type: "int", nullable: false),
                    OfesautoStateId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OfesautoStatesProcess", x => x.OfesautoStatesProcessId);
                    table.ForeignKey(
                        name: "FK_OfesautoStatesProcess_OfesautoProcess_OfesautoProcessId",
                        column: x => x.OfesautoProcessId,
                        principalTable: "OfesautoProcess",
                        principalColumn: "OfesautoProcessId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OfesautoStatesProcess_OfesautoStates_OfesautoStateId",
                        column: x => x.OfesautoStateId,
                        principalTable: "OfesautoStates",
                        principalColumn: "OfesautoStatesId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_IncidenceRecord_OfesautoStateId",
                table: "IncidenceRecord",
                column: "OfesautoStateId");

            migrationBuilder.CreateIndex(
                name: "IX_OfesautoStatesProcess_OfesautoProcessId",
                table: "OfesautoStatesProcess",
                column: "OfesautoProcessId");

            migrationBuilder.CreateIndex(
                name: "IX_OfesautoStatesProcess_OfesautoStateId",
                table: "OfesautoStatesProcess",
                column: "OfesautoStateId");

            migrationBuilder.AddForeignKey(
                name: "FK_IncidenceRecord_OfesautoStates_OfesautoStateId",
                table: "IncidenceRecord",
                column: "OfesautoStateId",
                principalTable: "OfesautoStates",
                principalColumn: "OfesautoStatesId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_IncidenceRecord_OfesautoStates_OfesautoStateId",
                table: "IncidenceRecord");

            migrationBuilder.DropTable(
                name: "OfesautoStatesProcess");

            migrationBuilder.DropTable(
                name: "OfesautoProcess");

            migrationBuilder.DropTable(
                name: "OfesautoStates");

            migrationBuilder.DropIndex(
                name: "IX_IncidenceRecord_OfesautoStateId",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "OfesautoStateId",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "OfesautoStatesId",
                table: "IncidenceRecord");

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "IncidenceRecord",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }
    }
}
