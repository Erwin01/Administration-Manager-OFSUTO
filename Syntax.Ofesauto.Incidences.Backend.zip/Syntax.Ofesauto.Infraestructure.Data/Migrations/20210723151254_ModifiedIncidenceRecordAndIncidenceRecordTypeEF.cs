﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.Incidence.Infraestructure.Data.Migrations
{
    public partial class ModifiedIncidenceRecordAndIncidenceRecordTypeEF : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_IncidenceType_IncidenceClassify_IncidenceClassifyId",
                table: "IncidenceType");

            migrationBuilder.DropIndex(
                name: "IX_IncidenceType_IncidenceClassifyId",
                table: "IncidenceType");

            migrationBuilder.DropColumn(
                name: "AffectedVehicleRegistration",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "CauseVehicleRegistration",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "ClaimManagerId",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "ClaimProcessorId",
                table: "IncidenceRecord");

            migrationBuilder.RenameColumn(
                name: "OrganismId",
                table: "IncidenceRecord",
                newName: "IncidenceOrganismId");

            migrationBuilder.RenameColumn(
                name: "OfesautoStateId",
                table: "IncidenceRecord",
                newName: "IncidenceOfesautoStateId");

            migrationBuilder.RenameColumn(
                name: "IncidenceTypeId",
                table: "IncidenceRecord",
                newName: "IncidenceClaimProcessorId");

            migrationBuilder.RenameColumn(
                name: "IncidenceRecordDateHigh",
                table: "IncidenceRecord",
                newName: "IncidenceDateHigh");

            migrationBuilder.RenameColumn(
                name: "DeclareVehicleAccidentId",
                table: "IncidenceRecord",
                newName: "IncidenceClaimManagerId");

            migrationBuilder.AlterColumn<string>(
                name: "IncidenceRecordName",
                table: "IncidenceRecord",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IncidenceRecordLastName",
                table: "IncidenceRecord",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "IncidenceAccidentDate",
                table: "IncidenceRecord",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "IncidenceAffectedVehicleRegistration",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "IncidenceCauseVehicleRegistration",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "IncidenceRecordType",
                columns: table => new
                {
                    IncidenceRecordTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IncidenceTypeId = table.Column<int>(type: "int", nullable: false),
                    IncidenceTypeStateId = table.Column<int>(type: "int", nullable: false),
                    IncidenceRecordId = table.Column<int>(type: "int", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IncidenceRecordType", x => x.IncidenceRecordTypeId);
                    table.ForeignKey(
                        name: "FK_IncidenceRecordType_IncidenceRecord_IncidenceRecordId",
                        column: x => x.IncidenceRecordId,
                        principalTable: "IncidenceRecord",
                        principalColumn: "IncidenceRecordId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_IncidenceRecordType_IncidenceRecordId",
                table: "IncidenceRecordType",
                column: "IncidenceRecordId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "IncidenceRecordType");

            migrationBuilder.DropColumn(
                name: "IncidenceAccidentDate",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "IncidenceAffectedVehicleRegistration",
                table: "IncidenceRecord");

            migrationBuilder.DropColumn(
                name: "IncidenceCauseVehicleRegistration",
                table: "IncidenceRecord");

            migrationBuilder.RenameColumn(
                name: "IncidenceOrganismId",
                table: "IncidenceRecord",
                newName: "OrganismId");

            migrationBuilder.RenameColumn(
                name: "IncidenceOfesautoStateId",
                table: "IncidenceRecord",
                newName: "OfesautoStateId");

            migrationBuilder.RenameColumn(
                name: "IncidenceDateHigh",
                table: "IncidenceRecord",
                newName: "IncidenceRecordDateHigh");

            migrationBuilder.RenameColumn(
                name: "IncidenceClaimProcessorId",
                table: "IncidenceRecord",
                newName: "IncidenceTypeId");

            migrationBuilder.RenameColumn(
                name: "IncidenceClaimManagerId",
                table: "IncidenceRecord",
                newName: "DeclareVehicleAccidentId");

            migrationBuilder.AlterColumn<string>(
                name: "IncidenceRecordName",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)",
                oldMaxLength: 30);

            migrationBuilder.AlterColumn<string>(
                name: "IncidenceRecordLastName",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)",
                oldMaxLength: 30);

            migrationBuilder.AddColumn<string>(
                name: "AffectedVehicleRegistration",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CauseVehicleRegistration",
                table: "IncidenceRecord",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ClaimManagerId",
                table: "IncidenceRecord",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ClaimProcessorId",
                table: "IncidenceRecord",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_IncidenceType_IncidenceClassifyId",
                table: "IncidenceType",
                column: "IncidenceClassifyId");

            migrationBuilder.AddForeignKey(
                name: "FK_IncidenceType_IncidenceClassify_IncidenceClassifyId",
                table: "IncidenceType",
                column: "IncidenceClassifyId",
                principalTable: "IncidenceClassify",
                principalColumn: "IncidenceClassifyId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
