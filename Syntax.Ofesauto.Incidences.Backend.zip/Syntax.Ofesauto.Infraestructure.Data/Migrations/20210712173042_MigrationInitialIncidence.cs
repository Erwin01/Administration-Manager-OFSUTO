﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace Syntax.Ofesauto.Incidence.Infraestructure.Data.Migrations
{
    public partial class MigrationInitialIncidence : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DataTypes",
                columns: table => new
                {
                    DataTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DataTypeName = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DataTypes", x => x.DataTypeId);
                });

            migrationBuilder.CreateTable(
                name: "IncidenceClassify",
                columns: table => new
                {
                    IncidenceClassifyId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IncidenceClassifyName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IncidenceClassifyNamEnglish = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    IncidenceClassifyDescription = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IncidenceClassify", x => x.IncidenceClassifyId);
                });

            migrationBuilder.CreateTable(
                name: "IncidenceRecord",
                columns: table => new
                {
                    IncidenceRecordId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IncidenceRecordNumber = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    DeclareVehicleAccidentId = table.Column<int>(type: "int", nullable: false),
                    IncidenceTypeId = table.Column<int>(type: "int", nullable: false),
                    OfesautoStateId = table.Column<int>(type: "int", nullable: false),
                    IncidenceRecordStateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IncidenceRecordDateHigh = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IncidenceRecord", x => x.IncidenceRecordId);
                });

            migrationBuilder.CreateTable(
                name: "IncidenceType",
                columns: table => new
                {
                    IncidenceTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IncidenceTypeName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IncidenceTypeNamEnglish = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    IncidenceClassifyId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IncidenceType", x => x.IncidenceTypeId);
                    table.ForeignKey(
                        name: "FK_IncidenceType_IncidenceClassify_IncidenceClassifyId",
                        column: x => x.IncidenceClassifyId,
                        principalTable: "IncidenceClassify",
                        principalColumn: "IncidenceClassifyId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_IncidenceType_IncidenceClassifyId",
                table: "IncidenceType",
                column: "IncidenceClassifyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DataTypes");

            migrationBuilder.DropTable(
                name: "IncidenceRecord");

            migrationBuilder.DropTable(
                name: "IncidenceType");

            migrationBuilder.DropTable(
                name: "IncidenceClassify");
        }
    }
}
