﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.Incidence.Domain.Entity;

namespace Syntax.Ofesauto.Incidence.Application.Main
{
    public class CustomDataContext : DbContext
    {
        public CustomDataContext(DbContextOptions options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IncidenceRecord>().ToTable("IncidenceRecord");
            modelBuilder.Entity<IncidenceType>().ToTable("IncidenceType");
            modelBuilder.Entity<DataTypes>().ToTable("DataTypes");
            modelBuilder.Entity<IncidenceClassify>().ToTable("IncidenceClassify");
            modelBuilder.Entity<InternalNote>().ToTable("InternalNote");

        }


        public virtual DbSet<IncidenceRecord> IncidenceRecord { get; set; }
        public virtual DbSet<IncidenceType> IncidenceType { get; set; }
        public virtual DbSet<DataTypes> DataType { get; set; }
        public virtual DbSet<IncidenceClassify> IncidenceClassify { get; set; }
        public virtual DbSet<InternalNote> InternalNote { get; set; }
        public virtual DbSet<OfesautoStates> OfesautoStates { get; set; }
    }
}
