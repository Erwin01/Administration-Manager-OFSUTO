﻿namespace Syntax.Ofesauto.Incidence.Application.Main
{
    interface ICustomDataContext
    {
    }
}
