﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using Syntax.Ofesauto.Security.Application.DTO;
using Syntax.Ofesauto.Security.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Core
{

    public class OrganismDomain : IOrganismDomain
    {
        /// <summary>
        /// Object allows accessing the properties of different projects
        /// </summary>
        private readonly IOrganismRepository _organismRepository;


        //No esta usando logica de negocio
        public OrganismDomain(IOrganismRepository customerRepository)
        {
            _organismRepository = customerRepository;
        }


        #region [ ASYNCHRONOUS METHODS ]

        #region [ ORGANISM METHODS ]
        public async Task<int> InsertOrganismAsync(Organism organism)
        {
            return await _organismRepository.InsertOrganismAsync(organism);
        }

        public async Task<IEnumerable<GetAllOrganism>> GetAllOrganismAsync()
        {
            return await _organismRepository.GetAllOrganismAsync();
        }  public async Task<IEnumerable<GetAllOrganism>> GetAllOrganismsCompanyAsync()
        {
            return await _organismRepository.GetAllOrganismsCompanyAsync();
        }

        public async Task<bool> UpdateOrganismAsync(Organism organism)
        {
            return await _organismRepository.UpdateOrganismAsync(organism);
        }

        public async Task<ViewOrganism> GetOrganismByIdAsync(string organismId)
        {
            return await _organismRepository.GetOrganismByIdAsync(organismId);
        }

        public async Task<bool> DeleteReasonLowByIdAsync(ReasonLowOrganism reasonLowOrganism)
        {
            return await _organismRepository.DeleteReasonLowByIdAsync(reasonLowOrganism);
        }

        public async Task<bool> DeleteReasonLowPassToByIdAsync(ReasonLowOrganismPassTo reasonLowOrganismPassTo)
        {
            return await _organismRepository.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassTo);
        }

        public async Task<IEnumerable<OrganismType>> GetAllOrganismTypeAsync()
        {
            return await _organismRepository.GetAllOrganismTypeAsync();
        }

        public async Task<IEnumerable<OrganismSubType>> GetAllOrganismSubTypeAsync()
        {
            return await _organismRepository.GetAllOrganismSubTypeAsync();
        }

        public async Task<IEnumerable<OrganismReasonLow>> GetAllOrganismReasonLowAsync()
        {
            return await _organismRepository.GetAllOrganismReasonLowAsync();
        }

        public async Task<bool> DeleteOrganismReasonLowPassToByIdAsync(DeleteOrganismReasonLow deleteOrganismReasonLow)
        {
            return await _organismRepository.DeleteOrganismReasonLowPassToByIdAsync(deleteOrganismReasonLow);
        }
        #endregion


        #region [ ORGANISM CONTACTS METHODS ]
        public async Task<int> InsertOrganismContactAsync(OrganismContact organismContact)
        {
            return await _organismRepository.InsertOrganismContactAsync(organismContact);
        }

        public async Task<bool> UpdateOrganismContactAsync(OrganismContact organismContact)
        {
            return await _organismRepository.UpdateOrganismContactAsync(organismContact);
        }

        public async Task<IEnumerable<GetAllOrganismContact>> GetAllOrganismContactAsync()
        {
            return await _organismRepository.GetAllOrganismContactAsync();
        }

        public async Task<GetOrganismContact> GetOrganismContactByIdAsync(string organismContactId)
        {
            return await _organismRepository.GetOrganismContactByIdAsync(organismContactId);
        }

        public async Task<IEnumerable<GetOrganismContact>> GetAllOrganismContactByIdAsync(string organismContactId)
        {
            return await _organismRepository.GetAllOrganismContactByIdAsync(organismContactId);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismContactAsync(SelectPrincipalOrganismContac selectPrincipalOrganismContac)
        {
            return await _organismRepository.UpdateSelectPrincipalOrganismContactAsync(selectPrincipalOrganismContac);
        }

        public async Task<bool> DeleteOrganismContactAsync(string organismContactId)
        {
            return await _organismRepository.DeleteOrganismContactAsync(organismContactId);
        }

        public async Task<IEnumerable<GetAllContactType>> GetAllOrganismContactTypeAsync()
        {
            return await _organismRepository.GetAllOrganismContactTypeAsync();
        }
        #endregion


        #region [ ORGANISM BANK ACCOUNT METHODS ]
        public async Task<int> InsertOrganismBankAccountAsync(OrganismBankAccount organismBankAccount)
        {
            return await _organismRepository.InsertOrganismBankAccountAsync(organismBankAccount);
        }

        public async Task<bool> UpdateOrganismBankAccountAsync(OrganismBankAccount organismBankAccount)
        {
            return await _organismRepository.UpdateOrganismBankAccountAsync(organismBankAccount);
        }

        public async Task<IEnumerable<GetAllBankAccountType>> GetAllOrganismBankAccountTypeAsync()
        {
            return await _organismRepository.GetAllOrganismBankAccountTypeAsync();
        }

        public async Task<IEnumerable<GetAllOrganismBankAccount>> GetAllOrganismBankAccountAsync()
        {
            return await _organismRepository.GetAllOrganismBankAccountAsync();
        }

        public async Task<GetOrganismBankAccount> GetOrganismBankAccountByIdAsync(string organismBankAccountId)
        {
            return await _organismRepository.GetOrganismBankAccountByIdAsync(organismBankAccountId);
        }

        public async Task<IEnumerable<GetOrganismBankAccount>> GetAllOrganismBankAccountByIdAsync(string organismBankAccountId)
        {
            return await _organismRepository.GetAllOrganismBankAccountByIdAsync(organismBankAccountId);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismBankAccountAsync(SelectPrincipalOrganismBankAccount selectPrincipalOrganismBankAccount)
        {
            return await _organismRepository.UpdateSelectPrincipalOrganismBankAccountAsync(selectPrincipalOrganismBankAccount);
        }

        public async Task<bool> DeleteOrganismBankAccountAsync(int organismBankAccountId)
        {
            return await _organismRepository.DeleteOrganismBankAccountAsync(organismBankAccountId);
        }
        #endregion


        #region [ ORGANISM OFFICE METHODS ]
        public async Task<int> InsertOrganismOfficeAsync(OrganismOffice organismOffice)
        {
            return await _organismRepository.InsertOrganismOfficeAsync(organismOffice);
        }

        public async Task<IEnumerable<GetAllOrganismOffice>> GetAllOrganismOfficeAsync()
        {
            return await _organismRepository.GetAllOrganismOfficeAsync();
        }

        public async Task<bool> UpdateOrganismOfficeGeneralDataAsync(OrganismOffice organismOffice)
        {
            return await _organismRepository.UpdateOrganismOfficeGeneralDataAsync(organismOffice);
        }

        public async Task<IEnumerable<GetOrganismOffice>> GetOrganismOfficeByIdAsync(string officeId)
        {
            return await _organismRepository.GetOrganismOfficeByIdAsync(officeId);
        }

        public async Task<IEnumerable<GetOrganismOffice>> GetAllOrganismOfficeByIdAsync(string organismOfficeId)
        {
            return await _organismRepository.GetAllOrganismOfficeByIdAsync(organismOfficeId);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismOfficeAsync(SelectPrincipalOrganismOffice selectPrincipalOrganismOffice)
        {
            return await _organismRepository.UpdateSelectPrincipalOrganismOfficeAsync(selectPrincipalOrganismOffice);
        }


        public async Task<int> DeleteOrganismOfficeAsync(int organismOfficeId)
        {
            return await _organismRepository.DeleteOrganismOfficeAsync(organismOfficeId);
        }
        #endregion


        #region [ ORGANISM OFFICE CONTACT METHODS ]
        public async Task<int> InsertOrganismOfficeContactAsync(OrganismOfficeContact organismOfficeContact)
        {
            return await _organismRepository.InsertOrganismOfficeContactAsync(organismOfficeContact);
        }

        public async Task<IEnumerable<GetAllOrganismOfficeContacts>> GetAllOrganismOfficeContactAsync()
        {
            return await _organismRepository.GetAllOrganismOfficeContactAsync();
        }

        public async Task<bool> UpdateOrganismOfficeContactAsync(OrganismOfficeContact organismOfficeContact)
        {
            return await _organismRepository.UpdateOrganismOfficeContactAsync(organismOfficeContact);
        }

        public async Task<IEnumerable<GetOrganismOfficeContactById>> GetOrganismOfficeContactByIdAsync(string contactId)
        {
            return await _organismRepository.GetOrganismOfficeContactByIdAsync(contactId);
        }

        public async Task<IEnumerable<GetAllOrganismOfficeContact>> GetAllOrganismOfficeContactByIdAsync(string organismOfficeContactId)
        {
            return await _organismRepository.GetAllOrganismOfficeContactByIdAsync(organismOfficeContactId);
        }

        public async Task<IEnumerable<GetOrganismOfficeContactById>> GetAllOrganismOfficeContactOfficeByIdAsync(string organismOfficeContactOfficeById)
        {
            return await _organismRepository.GetAllOrganismOfficeContactOfficeByIdAsync(organismOfficeContactOfficeById);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismOfficeContactAsync(SelectPrincipalOrganismOfficeContact selectPrincipalOrganismOfficeContact)
        {
            return await _organismRepository.UpdateSelectPrincipalOrganismOfficeContactAsync(selectPrincipalOrganismOfficeContact);
        }

        public async Task<bool> DeleteOrganismOfficeContactAsync(string organismOfficeContactId)
        {
            return await _organismRepository.DeleteOrganismOfficeContactAsync(organismOfficeContactId);
        }
        #endregion


        #region [ ORGANISM OFFICE BANK ACCOUNT ]
        public async Task<int> InsertOrganismOfficeBankAccountAsync(OrganismOfficeBankAccount organismOfficeBankAccount)
        {
            return await _organismRepository.InsertOrganismOfficeBankAccountAsync(organismOfficeBankAccount);
        }

        public async Task<IEnumerable<GetAllOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountAsync()
        {
            return await _organismRepository.GetAllOrganismOfficeBankAccountAsync();
        }

        public async Task<GetOrganismOfficeBankAccount> GetOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById)
        {
            return await _organismRepository.GetOrganismOfficeBankAccountByIdAsync(organismOfficeBankAccountById);
        }

        public async Task<IEnumerable<GetOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById)
        {
            return await _organismRepository.GetAllOrganismOfficeBankAccountByIdAsync(organismOfficeBankAccountById);
        }

        public async Task<IEnumerable<GetOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountOfficeByIdAsync(string organismOfficeBankAccountOfficeById)
        {
            return await _organismRepository.GetAllOrganismOfficeBankAccountOfficeByIdAsync(organismOfficeBankAccountOfficeById);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismOfficeBankAccount(SelectPrincipalOrganismOfficeBankAccount selectPrincipalOrganismOfficeBankAccount)
        {
            return await _organismRepository.UpdateSelectPrincipalOrganismOfficeBankAccount(selectPrincipalOrganismOfficeBankAccount);
        }

        public async Task<bool> UpdateOrganismOfficeBankAccountAsync(OrganismOfficeBankAccount organismOfficeBankAccount)
        {
            return await _organismRepository.UpdateOrganismOfficeBankAccountAsync(organismOfficeBankAccount);
        }

        public async Task<bool> DeleteOrganismOfficeBankAccountAsync(int organismBankAccountId)
        {
            return await _organismRepository.DeleteOrganismOfficeBankAccountAsync(organismBankAccountId);
        }
        #endregion


        #region [ ORGANISM OFFICE PROCESSOR METHODS ]
        public async Task<int> InsertOrganismOfficeProcessorAsync(OrganismOfficeProcessor organismOfficeProcessor)
        {
            return await _organismRepository.InsertOrganismOfficeProcessorAsync(organismOfficeProcessor);
        }

        public async Task<IEnumerable<GetAllOrganismOfficeProcessor>> GetAllOrganismOfficeProcessorAsync()
        {
            return await _organismRepository.GetAllOrganismOfficeProcessorAsync();
        }

        public async Task<GetOrganismOfficeProcessor> GetOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId)
        {
            return await _organismRepository.GetOrganismOfficeProcessorByIdAsync(organismOfficeProcessorId);
        }

        public async Task<IEnumerable<GetAllOrganismOfficeProcessorId>> GetAllOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId)
        {
            return await _organismRepository.GetAllOrganismOfficeProcessorByIdAsync(organismOfficeProcessorId);
        }

        public async Task<IEnumerable<GetAllOrganismOfficeProcessorId>> GetAllOrganismOfficeProcessorOfficeByIdAsync(string organismOfficeProcessorOfficeById)
        {
            return await _organismRepository.GetAllOrganismOfficeProcessorOfficeByIdAsync(organismOfficeProcessorOfficeById);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismOfficeProcessorAsync(SelectPrincipalOrganismOfficeProcessor selectPrincipalOrganismOfficeProcessor)
        {
            return await _organismRepository.UpdateSelectPrincipalOrganismOfficeProcessorAsync(selectPrincipalOrganismOfficeProcessor);
        }

        public async Task<bool> UpdateOrganismOfficeProcessorAsync(OrganismOfficeProcessor organismOfficeProcessor)
        {
            return await _organismRepository.UpdateOrganismOfficeProcessorAsync(organismOfficeProcessor);
        }

        public async Task<bool> DeleteOrganismOfficeProcessorAsync(string organismOfficeProcessorId)
        {
            return await _organismRepository.DeleteOrganismOfficeProcessorAsync(organismOfficeProcessorId);
        }
        #endregion


        #region [ ORGANISM REPRESENTATIVE METHODS ]
        public async Task<IEnumerable<GetAllOrganismRepresentative>> GetOrganismRepresentativeByIdAsync(string organismId)
        {
            return await _organismRepository.GetOrganismRepresentativeByIdAsync(organismId);
        }

        public async Task<int> InsertOrganismRepresentativeAsync(OrganismRepresentative organismRepresentative)
        {
            return await _organismRepository.InsertOrganismRepresentativeAsync(organismRepresentative);
        }

        public async Task<bool> DeleteOrganismRepresentativeAsync(string organismRepresentativeId)
        {
            return await _organismRepository.DeleteOrganismRepresentativeAsync(organismRepresentativeId);
        }

        public async Task<bool> UpdateOrganismRepresentativeAsync(OrganismRepresentative organismRepresentative)
        {
            return await _organismRepository.UpdateOrganismRepresentativeAsync(organismRepresentative);
        }

        public async Task<GetOrganismGeneralsData> GetOrganismGeneralsDataByIdAsync(string organismId)
        {
            return await _organismRepository.GetOrganismGeneralsDataByIdAsync(organismId);
        }
        #endregion


        #region [ ORGANISM REPRESENTED METHODS ]
        public async Task<int> InsertOrganismRepresentedAsync(OrganismRepresented organismRepresented)
        {
            return await _organismRepository.InsertOrganismRepresentedAsync(organismRepresented);
        }

        public async Task<IEnumerable<GetAllOrganismRepresented>> GetOrganismRepresentedByIdAsync(string organismId)
        {
            return await _organismRepository.GetOrganismRepresentedByIdAsync(organismId);
        }

        public async Task<bool> DeleteOrganismRepresentedAsync(string organismRepresentedId)
        {
            return await _organismRepository.DeleteOrganismRepresentedAsync(organismRepresentedId);
        }
        #endregion


        #region [ DOCUMENT TYPE METHODS ]
        public async Task<IEnumerable<DocumentType>> GetAllDocumentTypeAsync()
        {
            return await _organismRepository.GetAllDocumentTypeAsync();
        }
        #endregion


        #region [ COUNTRY METHODS ]
        public async Task<IEnumerable<Country>> GetAllCountryAsync()
        {
            return await _organismRepository.GetAllCountryAsync();
        }

        public async Task<IEnumerable<CountryByRegion>> GetCountryByRegionIdAsync(string countryByRegionId)
        {
            return await _organismRepository.GetCountryByRegionIdAsync(countryByRegionId);
        }

        public async Task<IEnumerable<PhoneCodeByCountry>> GetAllPhoneCodeByCountryIdAsync()
        {
            return await _organismRepository.GetAllPhoneCodeByCountryIdAsync();
        }
        #endregion


        #region [ REGION METHODS ]
        public async Task<IEnumerable<Region>> GetAllRegionAsync()
        {
            return await _organismRepository.GetAllRegionAsync();
        }

        public async Task<Region> GetRegionByIdAsync(string regionId)
        {
            return await _organismRepository.GetRegionByIdAsync(regionId);
        }
        #endregion


        #region [ AUTONOMOUS COMMUNITY ]
        public async Task<IEnumerable<AutonomousCommunity>> GetAllAutonomousCommunityAsync()
        {
            return await _organismRepository.GetAllAutonomousCommunityAsync();
        }
        #endregion


        #region [ PROVINCE SPAIN ]
        public async Task<IEnumerable<ProvinceSpain>> GetAllProvinceSpainAsync()
        {
            return await _organismRepository.GetAllProvinceSpainAsync();
        }
        #endregion


        #region [ CITY METHODS ]
        public async Task<IEnumerable<City>> GetAllCityAsync()
        {
            return await _organismRepository.GetAllCityAsync();
        }

        public async Task<City> GetCityByIdAsync(string cityId)
        {
            return await _organismRepository.GetCityByIdAsync(cityId);
        }

        public async Task<IEnumerable<CityByRegionByCountry>> GetCityByRegionByCountryAsync(string countryId, string regionId)
        {
            return await _organismRepository.GetCityByRegionByCountryAsync(countryId, regionId);
        }
        #endregion


        #region [ AUTHENTICATE METHODS ]
        public LoginDTO Authenticate(LoginDTO loginDTO)
        {
            return _organismRepository.Authenticate(loginDTO);
        }
        #endregion


        #region [ FORGET PASSWORD METHOD ]
        public ValidateEmailUserDTO ForgetPassword(ValidateEmailUserDTO validateEmailDTO)
        {
            return _organismRepository.ForgetPassword(validateEmailDTO);
        }

        public async Task<ValidateEmail> GetEmailAsync(string email)
        {
            return await _organismRepository.GetEmailAsync(email);
        }

        public ValidateVerificationCodeDTO ForgetPasswordVerificationCode(ValidateVerificationCodeDTO validateCodeVerificationDTO)
        {
            return _organismRepository.ForgetPasswordVerificationCode(validateCodeVerificationDTO);
        }

        public async Task<bool> UpdateUserPasswordAsync(ChangeUserPassword changeUserPassword)
        {
            return await _organismRepository.UpdateUserPasswordAsync(changeUserPassword);
        }
        #endregion

        #endregion

    }

}
