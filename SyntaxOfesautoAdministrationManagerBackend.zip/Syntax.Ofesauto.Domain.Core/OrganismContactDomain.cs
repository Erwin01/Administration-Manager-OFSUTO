﻿using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Core
{
    public class OrganismContactDomain : IOrganismContactDomain
    {

        private readonly IRepository<OrganismContact> _repository;
        public OrganismContactDomain(IRepository<OrganismContact> repository)
        {
            _repository = repository;
        }
        public async Task<OrganismContact> Add(OrganismContact obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<OrganismContact>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<OrganismContact> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public async Task<List<OrganismContact>> GetByParam(Func<OrganismContact, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<OrganismContact> GetByParamFirst(Func<OrganismContact, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<OrganismContact> Update(OrganismContact obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
