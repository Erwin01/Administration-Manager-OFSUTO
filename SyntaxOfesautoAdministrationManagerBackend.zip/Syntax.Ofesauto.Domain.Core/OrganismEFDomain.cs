﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Core
{
    public class OrganismEFDomain : IOrganismEFDomain
    {

        private readonly IRepository<Organism> _repository;
        private readonly CustomDataContext _context;


        public OrganismEFDomain(IRepository<Organism> repository, CustomDataContext customDataContext)
        {
            _repository = repository;
            _context = customDataContext;
        }

        public Task<Organism> Add(Organism obj)
        {
            return _repository.Add(obj);
        }

        public Task<List<Organism>> AddListOrganism(List<Organism> OrganismDTOs)
        {
            return _repository.AddList(OrganismDTOs);
        }

        public Task<bool> Delete(int id)
        {
            return _repository.Delete(id);
        }

        public Task<List<Organism>> GetAll()
        {
            return _repository.GetAll();
        }

        public Task<Organism> GetById(int id)
        {
            return _repository.GetById(id);
        }

        public Task<List<Organism>> GetByParam(Func<Organism, bool> pre)
        {
            return _repository.GetByParam(pre);

        }

        public Task<Organism> GetByParamFirst(Func<Organism, bool> pre)
        {
            return _repository.GetByParamFirst(pre);

        }

        public async  Task<List<GetAllOrganism>> GetOrganismParam(string Countries, string OrgaismTypes, string status)
        {
            return await _context.GetAllOrganism.FromSqlInterpolated($"GetOrganismParam {Countries},{OrgaismTypes}, {status}").ToListAsync(); ;
        }

        public async Task<List<GetOrganismToRepresented>> GetOrganismToRepresented(int organismId)
        {
            return await _context.GetOrganismToRepresented.FromSqlInterpolated($"GetAllOrganismsCompanyByOrganismId {organismId}").ToListAsync();
        }

        public async Task<List<Organism>> ListOrganismCompany(int Countries, int organims)
        {
            return await _context.Organism.Where(c => c.OrganismId != organims && c.CountryId == Countries && c.OrganismType.IsCompany).ToListAsync();
        }

        public Task<Organism> Update(Organism obj, int id)
        {
            return _repository.Update(obj, id);
        }
    }
}
