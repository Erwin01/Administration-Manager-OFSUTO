﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Core
{
    public class OrganismRepresentativeDomain : IOrganismRepresentativeDomain
    {
        private readonly IRepository<OrganismRepresentative> _repository;
        private readonly CustomDataContext _context;
        public OrganismRepresentativeDomain(IRepository<OrganismRepresentative> repository, CustomDataContext customDataContext)
        {
            _repository = repository;
            _context = customDataContext;
        }

        public Task<OrganismRepresentative> Add(OrganismRepresentative obj)
        {
            return _repository.Add(obj);
        }

        public Task<List<OrganismRepresentative>> AddListOrganismRepresentative(List<OrganismRepresentative> organismRepresentativeDTOs)
        {
            return _repository.AddList(organismRepresentativeDTOs);
        }

        public Task<bool> Delete(int id)
        {
            return _repository.Delete(id);
        }

        public Task<List<OrganismRepresentative>> GetAll()
        {
            return _repository.GetAll();
        }

        public Task<OrganismRepresentative> GetById(int id)
        {
            return _repository.GetById(id);
        }

        public Task<List<OrganismRepresentative>> GetByParam(Func<OrganismRepresentative, bool> pre)
        {
            return _repository.GetByParam(pre);

        }

        public Task<OrganismRepresentative> GetByParamFirst(Func<OrganismRepresentative, bool> pre)
        {
            return _repository.GetByParamFirst(pre);

        }

        public async Task<List<GetOrganismToRepresented>> GetOrganismToRepresented(int organismId)
        {
            return await _context.GetOrganismToRepresented.FromSqlInterpolated($"GetAllOrganismsCompanyByOrganismId {organismId}").ToListAsync();
        }

        public Task<OrganismRepresentative> Update(OrganismRepresentative obj, int id)
        {
            return _repository.Update(obj, id);
        }
    }
}
