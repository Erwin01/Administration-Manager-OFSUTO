﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Core
{
    public class Organism_Applications : IOrganism_Domain
    {
        private readonly IRepository<OrganismRepresentativeDTO> _repository;

        public Organism_Applications(IRepository<OrganismRepresentative> repository)
        {
            _repository = repository;
        }

        public Task<OrganismRepresentative> Add(OrganismRepresentative obj)
        {
            return _repository.Add(obj);
        }

        public Task<bool> Delete(int id)
        {
            return _repository.Delete(id);
        }

        public Task<List<OrganismRepresentative>> GetAll()
        {
            return _repository.GetAll();
        }

        public Task<OrganismRepresentative> GetById(int id)
        {
            return _repository.GetById(id);
        }

        public Task<List<OrganismRepresentative>> GetByParam(Func<OrganismRepresentative, bool> pre)
        {
            return _repository.GetByParam(pre);

        }

        public Task<OrganismRepresentative> GetByParamFirst(Func<OrganismRepresentative, bool> pre)
        {
            return _repository.GetByParamFirst(pre);

        }

        public Task<OrganismRepresentative> Update(OrganismRepresentative obj, int id)
        {
            return _repository.Update(obj, id);
        }
    }
}
