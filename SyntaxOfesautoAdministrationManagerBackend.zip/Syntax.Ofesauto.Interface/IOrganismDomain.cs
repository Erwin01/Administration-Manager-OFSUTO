﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.Security.Application.DTO;
using Syntax.Ofesauto.Security.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace Syntax.Ofesauto.AdministrationManager.Domain.Interface
{

    #region [ IORGANISM DOMAIN ]
    /// <summary>
    /// Method that allows operations on domain identity
    /// </summary>
    public interface IOrganismDomain
    {


        #region [ ASYNCHRONOUS METHODS ]

        #region [ ORGANISM METHODS ]
        Task<int> InsertOrganismAsync(Organism organism);
        Task<IEnumerable<GetAllOrganism>> GetAllOrganismAsync();
        Task<IEnumerable<GetAllOrganism>> GetAllOrganismsCompanyAsync();
        Task<ViewOrganism> GetOrganismByIdAsync(string organismId);
        Task<bool> UpdateOrganismAsync(Organism organism);
        Task<bool> DeleteReasonLowByIdAsync(ReasonLowOrganism reasonLowOrganism);
        Task<bool> DeleteReasonLowPassToByIdAsync(ReasonLowOrganismPassTo reasonLowOrganismPassTo);
        Task<IEnumerable<OrganismType>> GetAllOrganismTypeAsync();
        Task<IEnumerable<OrganismSubType>> GetAllOrganismSubTypeAsync();
        Task<IEnumerable<OrganismReasonLow>> GetAllOrganismReasonLowAsync();
        Task<bool> DeleteOrganismReasonLowPassToByIdAsync(DeleteOrganismReasonLow deleteOrganismReasonLow);

        #endregion


        #region [ ORGANISM CONTACTS METHODS ]
        Task<int> InsertOrganismContactAsync(OrganismContact organismContact);
        Task<bool> UpdateOrganismContactAsync(OrganismContact organismContact);
        Task<IEnumerable<GetAllOrganismContact>> GetAllOrganismContactAsync();
        Task<bool> UpdateSelectPrincipalOrganismContactAsync(SelectPrincipalOrganismContac selectPrincipalOrganismContac);
        Task<bool> DeleteOrganismContactAsync(string organismContactId);
        Task<GetOrganismContact> GetOrganismContactByIdAsync(string organismContactId);
        Task<IEnumerable<GetOrganismContact>> GetAllOrganismContactByIdAsync(string organismContactId);
        Task<IEnumerable<GetAllContactType>> GetAllOrganismContactTypeAsync();
        #endregion


        #region [ ORGANISM BANK ACCOUNT METHODS ]
        Task<int> InsertOrganismBankAccountAsync(OrganismBankAccount organismBankAccount);
        Task<bool> UpdateOrganismBankAccountAsync(OrganismBankAccount organismBankAccount);
        Task<IEnumerable<GetAllBankAccountType>> GetAllOrganismBankAccountTypeAsync();
        Task<IEnumerable<GetAllOrganismBankAccount>> GetAllOrganismBankAccountAsync();
        Task<GetOrganismBankAccount> GetOrganismBankAccountByIdAsync(string organismBankAccountId);
        Task<IEnumerable<GetOrganismBankAccount>> GetAllOrganismBankAccountByIdAsync(string organismBankAccountId);
        Task<bool> UpdateSelectPrincipalOrganismBankAccountAsync(SelectPrincipalOrganismBankAccount selectPrincipalOrganismBankAccount);
        Task<bool> DeleteOrganismBankAccountAsync(int organismBankAccountId);
        #endregion


        #region [ ORGANISM OFFICE ]
        Task<int> InsertOrganismOfficeAsync(OrganismOffice organismOffice);
        Task<IEnumerable<GetAllOrganismOffice>> GetAllOrganismOfficeAsync();
        Task<bool> UpdateOrganismOfficeGeneralDataAsync(OrganismOffice organismOffice);
        Task<IEnumerable<GetOrganismOffice>> GetOrganismOfficeByIdAsync(string officeId);
        Task<IEnumerable<GetOrganismOffice>> GetAllOrganismOfficeByIdAsync(string organismOfficeId);
        Task<bool> UpdateSelectPrincipalOrganismOfficeAsync(SelectPrincipalOrganismOffice selectPrincipalOrganismOffice);
        Task<int> DeleteOrganismOfficeAsync(int organismOfficeId);
        #endregion


        #region [ ORGANISM OFFICE CONTACT ]
        Task<int> InsertOrganismOfficeContactAsync(OrganismOfficeContact organismOfficeContact);
        Task<IEnumerable<GetAllOrganismOfficeContacts>> GetAllOrganismOfficeContactAsync();
        Task<bool> UpdateOrganismOfficeContactAsync(OrganismOfficeContact organismOfficeContact);
        Task<IEnumerable<GetOrganismOfficeContactById>> GetOrganismOfficeContactByIdAsync(string contactId);
        Task<IEnumerable<GetAllOrganismOfficeContact>> GetAllOrganismOfficeContactByIdAsync(string organismOfficeContactId);
        Task<IEnumerable<GetOrganismOfficeContactById>> GetAllOrganismOfficeContactOfficeByIdAsync(string organismOfficeContactOfficeById);
        Task<bool> UpdateSelectPrincipalOrganismOfficeContactAsync(SelectPrincipalOrganismOfficeContact selectPrincipalOrganismOfficeContact);
        Task<bool> DeleteOrganismOfficeContactAsync(string organismOfficeContactId);
        #endregion


        #region [ ORGANISM OFFICE BANK ACCOUNT ]
        Task<int> InsertOrganismOfficeBankAccountAsync(OrganismOfficeBankAccount organismOfficeBankAccount);
        Task<IEnumerable<GetAllOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountAsync();
        Task<GetOrganismOfficeBankAccount> GetOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById);
        Task<IEnumerable<GetOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById);
        Task<IEnumerable<GetOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountOfficeByIdAsync(string organismOfficeBankAccountOfficeById);
        Task<bool> UpdateSelectPrincipalOrganismOfficeBankAccount(SelectPrincipalOrganismOfficeBankAccount selectPrincipalOrganismOfficeBankAccount);
        Task<bool> UpdateOrganismOfficeBankAccountAsync(OrganismOfficeBankAccount organismOfficeBankAccount);
        Task<bool> DeleteOrganismOfficeBankAccountAsync(int organismBankAccountId);

        #endregion


        #region [ ORGANISM OFFICE PROCESSOR METHODS ]
        Task<int> InsertOrganismOfficeProcessorAsync(OrganismOfficeProcessor organismOfficeProcessor);
        Task<IEnumerable<GetAllOrganismOfficeProcessor>> GetAllOrganismOfficeProcessorAsync();
        Task<GetOrganismOfficeProcessor> GetOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId);
        Task<IEnumerable<GetAllOrganismOfficeProcessorId>> GetAllOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId);
        Task<IEnumerable<GetAllOrganismOfficeProcessorId>> GetAllOrganismOfficeProcessorOfficeByIdAsync(string organismOfficeProcessorOfficeById);
        Task<bool> UpdateSelectPrincipalOrganismOfficeProcessorAsync(SelectPrincipalOrganismOfficeProcessor selectPrincipalOrganismOfficeProcessor);
        Task<bool> UpdateOrganismOfficeProcessorAsync(OrganismOfficeProcessor organismOfficeProcessor);
        Task<bool> DeleteOrganismOfficeProcessorAsync(string organismOfficeProcessorId);

        #endregion


        #region [ ORGANISM REPRESENTATIVE METHODS ]
        Task<IEnumerable<GetAllOrganismRepresentative>> GetOrganismRepresentativeByIdAsync(string organismId);
        Task<int> InsertOrganismRepresentativeAsync(OrganismRepresentative organismRepresentative);
        Task<bool> DeleteOrganismRepresentativeAsync(string organismRepresentativeId);
        Task<bool> UpdateOrganismRepresentativeAsync(OrganismRepresentative organismRepresentative);
        Task<GetOrganismGeneralsData> GetOrganismGeneralsDataByIdAsync(string organismId);

        #endregion


        #region [ ORGANISM REPRESENTED METHODS ]
        Task<int> InsertOrganismRepresentedAsync(OrganismRepresented organismRepresented);
        Task<IEnumerable<GetAllOrganismRepresented>> GetOrganismRepresentedByIdAsync(string organismId);
        Task<bool> DeleteOrganismRepresentedAsync(string organismRepresentedId);
        #endregion


        #region [ DOCUMENT TYPE ]
        Task<IEnumerable<DocumentType>> GetAllDocumentTypeAsync();
        #endregion


        #region [ COUNTRY METHODS ]
        Task<IEnumerable<Country>> GetAllCountryAsync();
        Task<IEnumerable<CountryByRegion>> GetCountryByRegionIdAsync(string countryByRegionId);
        Task<IEnumerable<PhoneCodeByCountry>> GetAllPhoneCodeByCountryIdAsync();
        #endregion


        #region [ REGION METHODS ]
        Task<IEnumerable<Region>> GetAllRegionAsync();
        Task<Region> GetRegionByIdAsync(string regionId);
        #endregion


        #region [AUTONOMOUS COMMUNITY]
        Task<IEnumerable<AutonomousCommunity>> GetAllAutonomousCommunityAsync();
        #endregion

        #region [ PROVINCE SPAIN ]
        Task<IEnumerable<ProvinceSpain>> GetAllProvinceSpainAsync();
        #endregion

        #region [ CITY METHODS ]
        Task<IEnumerable<City>> GetAllCityAsync();
        Task<City> GetCityByIdAsync(string cityId);
        Task<IEnumerable<CityByRegionByCountry>> GetCityByRegionByCountryAsync(string countryId, string regionId);
        #endregion


        #region [ AUTHENTICATE METHODS ]
        LoginDTO Authenticate(LoginDTO loginDTO);
        #endregion


        #region [ FORGET PASSWORD METHOD ]
        ValidateEmailUserDTO ForgetPassword(ValidateEmailUserDTO validateEmailDTO);
        Task<ValidateEmail> GetEmailAsync(string email);
        ValidateVerificationCodeDTO ForgetPasswordVerificationCode(ValidateVerificationCodeDTO validateCodeVerificationDTO);

        Task<bool> UpdateUserPasswordAsync(ChangeUserPassword changeUserPassword);
        #endregion

        #endregion

    }
    #endregion


}





