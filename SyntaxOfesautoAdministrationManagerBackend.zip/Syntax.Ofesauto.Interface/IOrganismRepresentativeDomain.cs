﻿using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Interface
{
    public interface IOrganismRepresentativeDomain : IGenericDomain<OrganismRepresentative>
    {
        Task<List<OrganismRepresentative>> AddListOrganismRepresentative(List<OrganismRepresentative> organismRepresentativeDTOs);
        Task<List<GetOrganismToRepresented>> GetOrganismToRepresented(int organismId);
    }
}
