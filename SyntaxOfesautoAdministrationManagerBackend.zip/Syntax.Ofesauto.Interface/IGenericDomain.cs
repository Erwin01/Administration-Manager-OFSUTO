﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Interface
{
    public interface IGenericDomain<T> where T : class
    {
        Task<T> Add(T obj);
        Task<T> Update(T obj, int id);
        Task<bool> Delete(int id);
        Task<List<T>> GetAll();
        Task<T> GetById(int id);
        Task<List<T>> GetByParam(Func<T, bool> pre);
        Task<T> GetByParamFirst(Func<T, bool> pre);
    }
}
