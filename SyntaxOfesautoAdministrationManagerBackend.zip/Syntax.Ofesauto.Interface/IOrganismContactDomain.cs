﻿using Syntax.Ofesauto.AdministrationManager.Domain.Entity;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Interface
{
    public interface IOrganismContactDomain : IGenericDomain<OrganismContact>
    {
    }
}
