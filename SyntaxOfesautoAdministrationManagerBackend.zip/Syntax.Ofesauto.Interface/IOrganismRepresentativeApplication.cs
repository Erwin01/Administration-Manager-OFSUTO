﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Interface
{
    public interface IOrganismRepresentativeApplication : IGenericApplication<OrganismRepresentativeDTO>
    {
    }
}
