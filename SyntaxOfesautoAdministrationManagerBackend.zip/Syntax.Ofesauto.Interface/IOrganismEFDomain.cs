﻿using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Interface
{
    public interface IOrganismEFDomain : IGenericDomain<Organism>
    {
        Task<List<GetAllOrganism>> GetOrganismParam(string Countries, string OrgaismTypes, string status);
        Task<List<Organism>> ListOrganismCompany(int Countries, int organims);
    }
}
