﻿using Dapper;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using Syntax.Ofesauto.Security.Application.DTO;
using Syntax.Ofesauto.Security.Domain.Entity;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Repository
{
    /// <summary>
    /// Method to access the database we use a Dapper micro ORM
    /// </summary>
    /// 
    #region [ ORGANISM REPOSITORY ]
    public class OrganismRepository : IOrganismRepository
    {

        /// <summary>
        /// Object allows accessing the properties of different projects and using the stored procedures
        /// </summary>
        private readonly IConnectionFactory _connectionFactory;
        public static string secretKey = "$%/&@D=<+ohr/fo%kdse/)!";


        #region [ CONSTRUCTOR ]
        public OrganismRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public OrganismRepository()
        {
        }
        #endregion


        #region [ OFESAUTO STATE ]
        enum OfesautoStateId
        {
            OfesautoIdActivo = 1,
            OfesautoIdNoActivo = 2

        }
        #endregion


        #region [ ASYNCHRONOUS METHODS ]

        #region [ ORGANISM METHODS ]
        public async Task<int> InsertOrganismAsync(Organism organism)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganism";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organism.OrganismId);
                parameters.Add("OrganismTypeId", organism.OrganismTypeId);
                parameters.Add("CountryId", organism.CountryId);
                parameters.Add("RegionId", organism.RegionId);
                parameters.Add("CityId", organism.CityId);
                parameters.Add("Poblation", organism.Poblation);
                parameters.Add("OrganismName", organism.OrganismName);
                parameters.Add("OrganismLastName", organism.OrganismLastName);
                parameters.Add("OrganismAddress", organism.OrganismAddress);
                parameters.Add("DocumentTypeId", organism.DocumentType);
                parameters.Add("OrganismPostalCode", organism.OrganismPostalCode);
                parameters.Add("OrganismCIF", organism.OrganismCIF);
                parameters.Add("OrganismWebSite", organism.OrganismWebSite);
                parameters.Add("OrganismCode", organism.OrganismCode);
                parameters.Add("OrganismReasonLowId", null);
                parameters.Add("OrganismLowDate", null);
                parameters.Add("OrganismHightDate", DateTime.UtcNow);
                parameters.Add("OrganismSubTypeId", organism.OrganismSubTypeId);
                parameters.Add("OfesautoStateId", OfesautoStateId.OfesautoIdActivo);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 OrganismId From Organism ORDER BY OrganismId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1});
                
                return id;

            }
        }


        public async Task<IEnumerable<GetAllOrganism>> GetAllOrganismAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganisms";

                var organisms = await connection.QueryAsync<GetAllOrganism>(query, commandType: CommandType.StoredProcedure);

                return organisms;

            }
        }
        
        public async Task<IEnumerable<GetAllOrganism>> GetAllOrganismsCompanyAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismsCompany";

                var organisms = await connection.QueryAsync<GetAllOrganism>(query, commandType: CommandType.StoredProcedure);

                return organisms;

            }
        }


        public async Task<bool> UpdateOrganismAsync(Organism organism)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganism";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organism.OrganismId);
                parameters.Add("OrganismTypeId", organism.OrganismTypeId);
                parameters.Add("CountryId", organism.CountryId);
                parameters.Add("RegionId", organism.RegionId);
                parameters.Add("CityId", organism.CityId);
                parameters.Add("Poblation", organism.Poblation);
                parameters.Add("OrganismName", organism.OrganismName);
                parameters.Add("OrganismLastName", organism.OrganismLastName);
                parameters.Add("OrganismAddress", organism.OrganismAddress);
                parameters.Add("DocumentTypeId", organism.DocumentType);
                parameters.Add("OrganismPostalCode", organism.OrganismPostalCode);
                parameters.Add("OrganismCIF", organism.OrganismCIF);
                parameters.Add("OrganismWebSite", organism.OrganismWebSite);
                parameters.Add("OrganismCode", organism.OrganismCode);
                parameters.Add("OrganismReasonLowId", organism.OrganismReasonLowId);
                parameters.Add("OrganismLowDate", organism.OrganismLowDate);
                parameters.Add("OrganismHightDate", DateTime.UtcNow);
                parameters.Add("OrganismSubTypeId", organism.OrganismSubTypeId);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<bool> DeleteReasonLowByIdAsync(ReasonLowOrganism reasonLowOrganism)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "ReasonLowOrganism";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", reasonLowOrganism.OrganismId);
                parameters.Add("OrganismReasonLowId", reasonLowOrganism.OrganisReasonLowId);
                parameters.Add("OfesautoStateId", OfesautoStateId.OfesautoIdNoActivo);
                parameters.Add("OrganismLowDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<bool> DeleteReasonLowPassToByIdAsync(ReasonLowOrganismPassTo reasonLowOrganismPassTo)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "ReasonLowOrganismPassTo";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", reasonLowOrganismPassTo.OrganismId);
                parameters.Add("OrganismIdPassTo", reasonLowOrganismPassTo.OrganismIdPassTo);
                parameters.Add("OrganismLowDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<ViewOrganism> GetOrganismByIdAsync(string organismId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismId);

                var organismById = await connection.QuerySingleAsync<ViewOrganism>(query, param: parameters, commandType: CommandType.StoredProcedure);


                return organismById;

            }
        }


        public async Task<IEnumerable<OrganismType>> GetAllOrganismTypeAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismType";

                var organismType = await connection.QueryAsync<OrganismType>(query, commandType: CommandType.StoredProcedure);

                return organismType;

            }
        }


        public async Task<IEnumerable<OrganismSubType>> GetAllOrganismSubTypeAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismSubType";

                var organismSubType = await connection.QueryAsync<OrganismSubType>(query, commandType: CommandType.StoredProcedure);

                return organismSubType;

            }
        }


        public async Task<IEnumerable<OrganismReasonLow>> GetAllOrganismReasonLowAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganimReasonLow";

                var organismReasonLow = await connection.QueryAsync<OrganismReasonLow>(query, commandType: CommandType.StoredProcedure);

                return organismReasonLow;

            }
        }


        public async Task<bool> DeleteOrganismReasonLowPassToByIdAsync(DeleteOrganismReasonLow deleteOrganismReasonLow)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismReasonLow";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", deleteOrganismReasonLow.OrganismId);
                parameters.Add("OrganismReasonLowId", deleteOrganismReasonLow.OrganismReasonLowId);
                parameters.Add("OrganismIdPassTo", deleteOrganismReasonLow.OrganismIdPassTo);
                parameters.Add("OfesautoStateId", OfesautoStateId.OfesautoIdNoActivo);
                parameters.Add("OrganismLowDate", DateTime.UtcNow);
                parameters.Add("ContactLowDate", DateTime.UtcNow);
                parameters.Add("BankAccountLowDate", DateTime.UtcNow);
                parameters.Add("OfficeLowDate", DateTime.UtcNow);
                parameters.Add("OfficeContactLowDate", DateTime.UtcNow);
                parameters.Add("OfficeBankAccountLowDate", DateTime.UtcNow);
                parameters.Add("OfficeProcessorLowDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }
        #endregion


        #region [ ORGANISM CONTACT METHODS ]

        public async Task<int> InsertOrganismContactAsync(OrganismContact organismContact)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismContact";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismContact.OrganismId);
                parameters.Add("ContactId", organismContact.ContactId);
                parameters.Add("ContactTypeId", organismContact.ContactTypeId);
                parameters.Add("ContactName", organismContact.ContactName);
                parameters.Add("ContactLastname", organismContact.ContactLastName);
                parameters.Add("ContactPhone", organismContact.ContactPhone);
                parameters.Add("ContactFax", organismContact.ContactFax);
                parameters.Add("ContactEmail", organismContact.ContactEmail);
                parameters.Add("ContactPrincipal", null);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 ContactId From OrganismContact ORDER BY ContactId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }


        public async Task<bool> UpdateOrganismContactAsync(OrganismContact organismContact)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganismContact";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismContact.OrganismId);
                parameters.Add("ContactId", organismContact.ContactId);
                parameters.Add("ContactTypeId", organismContact.ContactTypeId);
                parameters.Add("ContactName", organismContact.ContactName);
                parameters.Add("ContactLastname", organismContact.ContactLastName);
                parameters.Add("ContactPhone", organismContact.ContactPhone);
                parameters.Add("ContactFax", organismContact.ContactFax);
                parameters.Add("ContactEmail", organismContact.ContactEmail);
                //parameters.Add("ContactPrincipal", null);
                //parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<IEnumerable<GetAllOrganismContact>> GetAllOrganismContactAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismContact";

                var organismContact = await connection.QueryAsync<GetAllOrganismContact>(query, commandType: CommandType.StoredProcedure);

                return organismContact;

            }
        }


        public async Task<GetOrganismContact> GetOrganismContactByIdAsync(string organismContactId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismContactById";
                var parameters = new DynamicParameters();

                parameters.Add("ContactId", organismContactId);

                var organismContact = await connection.QuerySingleAsync<GetOrganismContact>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismContact;

            }
        }


        public async Task<IEnumerable<GetOrganismContact>> GetAllOrganismContactByIdAsync(string organismContactId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismContactById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismContactId);

                var organismContact = await connection.QueryAsync<GetOrganismContact>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismContact;

            }
        }


        public async Task<IEnumerable<GetOrganismOfficeContactById>> GetAllOrganismOfficeContactOfficeByIdAsync(string organismOfficeContactOfficeById)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeContactByOfficeId";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeId", organismOfficeContactOfficeById);

                var organismContactOfficeId = await connection.QueryAsync<GetOrganismOfficeContactById>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismContactOfficeId;

            }
        }

        public async Task IsOrganismContactPrincipal(int organismId)
        {

            var connection = _connectionFactory.GetConnection;

            string isPrincipal = $"Update OrganismContact SET ContactPrincipal = 0 WHERE OrganismId = {organismId} and ContactPrincipal = 1";
            await connection.ExecuteAsync(isPrincipal);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismContactAsync(SelectPrincipalOrganismContac selectPrincipalOrganismContac)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateSelectPrincipalOrganismContact";
                var parameters = new DynamicParameters();

                await IsOrganismContactPrincipal(selectPrincipalOrganismContac.OrganismId);

                parameters.Add("ContactId", selectPrincipalOrganismContac.ContactId);
                parameters.Add("ContactPrincipal", selectPrincipalOrganismContac.ContactPrincipal);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }


        public async Task<bool> DeleteOrganismContactAsync(string organismContactId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismContact";
                var parameters = new DynamicParameters();

                parameters.Add("ContactId", organismContactId);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<IEnumerable<GetAllContactType>> GetAllOrganismContactTypeAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismContactType";

                var contactType = await connection.QueryAsync<GetAllContactType>(query, commandType: CommandType.StoredProcedure);

                return contactType;

            }
        }
        #endregion


        #region [ ORGANISM BANK ACCOUNT METHODS ]
        public async Task<int> InsertOrganismBankAccountAsync(OrganismBankAccount organismBankAccount)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismBankAccount";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismBankAccount.OrganismId);
                parameters.Add("BankAccountId", organismBankAccount.BankAccountId);
                parameters.Add("BankAccountTypeId", organismBankAccount.BankAccountTypeId);
                parameters.Add("CountryId", organismBankAccount.CountryId);
                parameters.Add("BankAccountName", organismBankAccount.BankAccountName);
                parameters.Add("BankAccountNumber", organismBankAccount.BankAccountNumber);
                parameters.Add("BankAccountSwift", organismBankAccount.BankAccountSwift);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);
                parameters.Add("BankAccountPrincipal", null);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 BankAccountId From OrganismBankAccount ORDER BY BankAccountId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }

        public async Task<bool> UpdateOrganismBankAccountAsync(OrganismBankAccount organismBankAccount)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganismBankAccount";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismBankAccount.OrganismId);
                parameters.Add("BankAccountId", organismBankAccount.BankAccountId);
                parameters.Add("BankAccountName", organismBankAccount.BankAccountName);
                parameters.Add("BankAccountTypeId", organismBankAccount.BankAccountTypeId);
                parameters.Add("CountryId", organismBankAccount.CountryId);
                parameters.Add("BankAccountNumber", organismBankAccount.BankAccountNumber);
                parameters.Add("BankAccountSwift", organismBankAccount.BankAccountSwift);
                //parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }

        public async Task<IEnumerable<GetAllBankAccountType>> GetAllOrganismBankAccountTypeAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismBankAccountType";

                var organismBankAccountType = await connection.QueryAsync<GetAllBankAccountType>(query, commandType: CommandType.StoredProcedure);

                return organismBankAccountType;

            }
        }

        public async Task<IEnumerable<GetAllOrganismBankAccount>> GetAllOrganismBankAccountAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismBankAccount";

                var organismBankAccount = await connection.QueryAsync<GetAllOrganismBankAccount>(query, commandType: CommandType.StoredProcedure);

                return organismBankAccount;

            }
        }

        public async Task<GetOrganismBankAccount> GetOrganismBankAccountByIdAsync(string organismBankAccountId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismBankAccountById";
                var parameters = new DynamicParameters();

                parameters.Add("BankAccountId", organismBankAccountId);

                var organismBankAccount = await connection.QuerySingleAsync<GetOrganismBankAccount>(query, param: parameters, commandType: CommandType.StoredProcedure);


                return organismBankAccount;

            }
        }

        public async Task<IEnumerable<GetOrganismBankAccount>> GetAllOrganismBankAccountByIdAsync(string organismBankAccountId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismBankAccountById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismBankAccountId);

                var organismBankAccount = await connection.QueryAsync<GetOrganismBankAccount>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismBankAccount;

            }
        }

        public async Task IsOrganismBankAccountPrincipal(int organismId)
        {

            var connection = _connectionFactory.GetConnection;

            string isPrincipal = $"Update OrganismBankAccount SET BankAccountPrincipal = 0 WHERE OrganismId = {organismId} and BankAccountPrincipal = 1";
            await connection.ExecuteAsync(isPrincipal);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismBankAccountAsync(SelectPrincipalOrganismBankAccount selectPrincipalOrganismBankAccount)
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "UpdateSelectPrincipalOrganismBankAccount";
                var parameters = new DynamicParameters();

                await IsOrganismBankAccountPrincipal(selectPrincipalOrganismBankAccount.OrganismId);

                parameters.Add("BankAccountId", selectPrincipalOrganismBankAccount.BankAccountId);
                parameters.Add("BankAccountPrincipal", selectPrincipalOrganismBankAccount.BankAccountPrincipal);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }


        public async Task<bool> DeleteOrganismBankAccountAsync(int organismBankAccountId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismBankAccount";
                var parameters = new DynamicParameters();

                parameters.Add("BankAccountId", organismBankAccountId);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }

        #endregion


        #region [ ORGANISM OFFICE METHODS ]

        public async Task IsRepresentation(int organismId) 
        {

            var connection = _connectionFactory.GetConnection;

            string isRepresentation = $"Update OrganismOffice SET IsRepresentation = 0 WHERE OrganismId = {organismId} and IsRepresentation = 1";
            await connection.ExecuteAsync(isRepresentation);
        }


        public async Task<int> InsertOrganismOfficeAsync(OrganismOffice organismOffice)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismOffice";
                var parameters = new DynamicParameters();

                if (organismOffice.IsRepresentation)
                {
                   await IsRepresentation(organismOffice.OrganismId);
                }

                parameters.Add("OrganismId", organismOffice.OrganismId);
                parameters.Add("OfficeId", organismOffice.OfficeId);
                parameters.Add("CountryId", organismOffice.CountryId);
                parameters.Add("RegionId", organismOffice.RegionId);
                parameters.Add("CityId", organismOffice.CityId);
                parameters.Add("Population", organismOffice.Population);
                parameters.Add("OfficeAddress", organismOffice.OfficeAddress);
                parameters.Add("OfficePostalCode", organismOffice.OfficePostalCode);
                parameters.Add("IsRepresentation", organismOffice.IsRepresentation);
                parameters.Add("OfficeHightDate", DateTime.UtcNow);
                parameters.Add("OfficeLowDate", null);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 OfficeId From OrganismOffice ORDER BY OfficeId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }

        public async Task<IEnumerable<GetAllOrganismOffice>> GetAllOrganismOfficeAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOffice";

                var organismOffice = await connection.QueryAsync<GetAllOrganismOffice>(query, commandType: CommandType.StoredProcedure);

                return organismOffice;

            }
        }


        public async Task<bool> UpdateOrganismOfficeGeneralDataAsync(OrganismOffice organismOffice)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganismOffice";
                var parameters = new DynamicParameters();

                if (organismOffice.IsRepresentation)
                {
                    await IsRepresentation(organismOffice.OrganismId);
                }

                parameters.Add("OrganismId", organismOffice.OrganismId);
                parameters.Add("OfficeId", organismOffice.OfficeId);
                parameters.Add("CountryId", organismOffice.CountryId);
                parameters.Add("RegionId", organismOffice.RegionId);
                parameters.Add("CityId", organismOffice.CityId);
                parameters.Add("Population", organismOffice.Population);
                parameters.Add("OfficeAddress", organismOffice.OfficeAddress);
                parameters.Add("OfficePostalCode", organismOffice.OfficePostalCode);
                parameters.Add("IsRepresentation", organismOffice.IsRepresentation);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<IEnumerable<GetOrganismOffice>> GetAllOrganismOfficeByIdAsync(string organismOfficeId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeId);

                var organismOffice = await connection.QueryAsync<GetOrganismOffice>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOffice;

            }
        }


        public async Task<IEnumerable<GetOrganismOffice>> GetOrganismOfficeByIdAsync(string officeId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismOfficeById";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeId", officeId);

                var organismOffice = await connection.QueryAsync<GetOrganismOffice>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOffice;

            }
        }


        public async Task<bool> UpdateSelectPrincipalOrganismOfficeAsync(SelectPrincipalOrganismOffice selectPrincipalOrganismOffice)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateSelectPrincipalOrganismOffice";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeId", selectPrincipalOrganismOffice.OfficeId);
                parameters.Add("OfficePrincipal", selectPrincipalOrganismOffice.OfficePrincipal);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<int> DeleteOrganismOfficeAsync(int organismOfficeId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismOffice";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeId", organismOfficeId);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result;

            }
        }
        #endregion


        #region [ ORGANISM OFFICE CONTACT METHODS ]
        public async Task<int> InsertOrganismOfficeContactAsync(OrganismOfficeContact organismOfficeContact)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismOfficeContact";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeContact.OrganismId);
                parameters.Add("OfficeId", organismOfficeContact.OfficeId);
                parameters.Add("ContactId", organismOfficeContact.ContactId);
                parameters.Add("ContactTypeId", organismOfficeContact.ContactTypeId);
                parameters.Add("ContactName", organismOfficeContact.ContactName);
                parameters.Add("ContactLastname", organismOfficeContact.ContactLastName);
                parameters.Add("ContactPhone", organismOfficeContact.ContactPhone);
                parameters.Add("ContactFax", organismOfficeContact.ContactFax);
                parameters.Add("ContactEmail", organismOfficeContact.ContactEmail);
                parameters.Add("OrganismReasonLowId", null);
                parameters.Add("OfficeContactLowDate", null);
                //parameters.Add("OfficeContactPrincipal", null);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 ContactId From OrganismOfficeContact ORDER BY ContactId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }

        public async Task<IEnumerable<GetAllOrganismOfficeContacts>> GetAllOrganismOfficeContactAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeContact";

                var organismOfficeContact = await connection.QueryAsync<GetAllOrganismOfficeContacts>(query, commandType: CommandType.StoredProcedure);

                return organismOfficeContact;

            }
        }

        public async Task<bool> UpdateOrganismOfficeContactAsync(OrganismOfficeContact organismOfficeContact)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganismOfficeContact";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeContact.OrganismId);
                parameters.Add("OfficeId", organismOfficeContact.OfficeId);
                parameters.Add("ContactId", organismOfficeContact.ContactId);
                parameters.Add("ContactTypeId", organismOfficeContact.ContactTypeId);
                parameters.Add("ContactName", organismOfficeContact.ContactName);
                parameters.Add("ContactLastname", organismOfficeContact.ContactLastName);
                parameters.Add("ContactPhone", organismOfficeContact.ContactPhone);
                parameters.Add("ContactFax", organismOfficeContact.ContactFax);
                parameters.Add("ContactEmail", organismOfficeContact.ContactEmail);
                //parameters.Add("OfficeContactPrincipal", null);
                //parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }

        public async Task<IEnumerable<GetAllOrganismOfficeContact>> GetAllOrganismOfficeContactByIdAsync(string organismOfficeContactId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeContactById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeContactId);

                var organismOfficeContact = await connection.QueryAsync<GetAllOrganismOfficeContact>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOfficeContact;

            }
        }



        public async Task<IEnumerable<GetOrganismOfficeContactById>> GetOrganismOfficeContactByIdAsync(string contactId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismOfficeContactById";
                var parameters = new DynamicParameters();

                parameters.Add("ContactId", contactId);

                var organismOfficeContact = await connection.QueryAsync<GetOrganismOfficeContactById>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOfficeContact;

            }
        }


        public async Task IsOfficeContactPrincipal(int officeId)
        {

            var connection = _connectionFactory.GetConnection;

            string isPrincipal = $"Update OrganismOfficeContact SET OfficeContactPrincipal = 0 WHERE OfficeId = {officeId}";
            await connection.ExecuteAsync(isPrincipal);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismOfficeContactAsync(SelectPrincipalOrganismOfficeContact selectPrincipalOrganismOfficeContact)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateSelectPrincipalOrganismOfficeContact";
                var parameters = new DynamicParameters();

                await IsOfficeContactPrincipal(selectPrincipalOrganismOfficeContact.OfficeId);

                parameters.Add("ContactId", selectPrincipalOrganismOfficeContact.ContactId);
                parameters.Add("OfficeContactPrincipal", selectPrincipalOrganismOfficeContact.OfficeContactPrincipal);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }


        public async Task<bool> DeleteOrganismOfficeContactAsync(string organismOfficeContactId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismOfficeContact";
                var parameters = new DynamicParameters();

                parameters.Add("ContactId", organismOfficeContactId);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }
        #endregion


        #region [ ORGANISM OFFICE BANK ACCOUNT METHODS ]
        public async Task<int> InsertOrganismOfficeBankAccountAsync(OrganismOfficeBankAccount organismOfficeBankAccount)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismOfficeBankAccount";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeBankAccount.OrganismId);
                parameters.Add("OfficeId", organismOfficeBankAccount.OfficeId);
                parameters.Add("BankAccountId", organismOfficeBankAccount.BankAccountId);
                parameters.Add("BankAccountName", organismOfficeBankAccount.BankAccountName);
                parameters.Add("BankAccountTypeId", organismOfficeBankAccount.BankAccountTypeId);
                parameters.Add("CountryId", organismOfficeBankAccount.CountryId);
                parameters.Add("BankAccountNumber", organismOfficeBankAccount.BankAccountNumber);
                parameters.Add("BankAccountSwift", organismOfficeBankAccount.BankAccountSwift);
                parameters.Add("OrganismReasonLowId", organismOfficeBankAccount.OrganismReasonLowId);
                parameters.Add("OfficeBankAccountLowDate", null);
                parameters.Add("OfficeBankAccountPrincipal", null);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 BankAccountId From OrganismOfficeBankAccount ORDER BY BankAccountId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }

        public async Task<IEnumerable<GetAllOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeBankAccount";

                var organismOfficebankAccount = await connection.QueryAsync<GetAllOrganismOfficeBankAccount>(query, commandType: CommandType.StoredProcedure);

                return organismOfficebankAccount;

            }
        }

        public async Task<GetOrganismOfficeBankAccount> GetOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismOfficeBankAccountById";
                var parameters = new DynamicParameters();

                parameters.Add("BankAccountId", organismOfficeBankAccountById);

                var organismOfficeBankAccount = await connection.QuerySingleAsync<GetOrganismOfficeBankAccount>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOfficeBankAccount;

            }
        }

        public async Task<IEnumerable<GetOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeBankAccountById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeBankAccountById);

                var organismOfficeBankAccount = await connection.QueryAsync<GetOrganismOfficeBankAccount>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOfficeBankAccount;

            }
        }


        public async Task<IEnumerable<GetOrganismOfficeBankAccount>> GetAllOrganismOfficeBankAccountOfficeByIdAsync(string organismOfficeBankAccountOfficeById)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeBankAccountByOfficeId";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeId", organismOfficeBankAccountOfficeById);

                var organismOfficeBankAccountOfficeId = await connection.QueryAsync<GetOrganismOfficeBankAccount>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOfficeBankAccountOfficeId;

            }
        }


        public async Task IsOfficeBankAccountPrincipal(int officeId)
        {

            var connection = _connectionFactory.GetConnection;

            string isPrincipal = $"Update OrganismOfficeBankAccount SET OfficeBankAccountPrincipal = 0 WHERE OfficeId = {officeId}";
            await connection.ExecuteAsync(isPrincipal);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismOfficeBankAccount(SelectPrincipalOrganismOfficeBankAccount selectPrincipalOrganismOfficeBankAccount)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateSelectPrincipalOrganismOfficeBankAccount";
                var parameters = new DynamicParameters();

                await IsOfficeBankAccountPrincipal(selectPrincipalOrganismOfficeBankAccount.OfficeId);

                parameters.Add("BankAccountId", selectPrincipalOrganismOfficeBankAccount.BankAccountId);
                parameters.Add("OfficeBankAccountPrincipal", selectPrincipalOrganismOfficeBankAccount.OfficeBankAccountPrincipal);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }

        public async Task<bool> UpdateOrganismOfficeBankAccountAsync(OrganismOfficeBankAccount organismOfficeBankAccount)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganismOfficeBankAccount";
                var parameters = new DynamicParameters();

                parameters.Add("BankAccountId", organismOfficeBankAccount.BankAccountId);
                parameters.Add("OfficeId", organismOfficeBankAccount.OfficeId);
                parameters.Add("OrganismId", organismOfficeBankAccount.OrganismId);
                parameters.Add("BankAccountName", organismOfficeBankAccount.BankAccountName);
                parameters.Add("BankAccountTypeId", organismOfficeBankAccount.BankAccountTypeId);
                parameters.Add("CountryId", organismOfficeBankAccount.CountryId);
                parameters.Add("BankAccountNumber", organismOfficeBankAccount.BankAccountNumber);
                parameters.Add("BankAccountSwift", organismOfficeBankAccount.BankAccountSwift);
                //parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }

        public async Task<bool> DeleteOrganismOfficeBankAccountAsync(int organismBankAccountId)
        {
            try
            {
                using (var connection = _connectionFactory.GetConnection)
                {
                    var query = "DeleteOrganismOfficeBankAccount";
                    var parameters = new DynamicParameters();

                    parameters.Add("BankAccountId", organismBankAccountId);

                    var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                    return result > 0;

                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
           
        }
        #endregion


        #region [ ORGANISM OFFICE PROCESSOR METHODS ]
        public async Task<int> InsertOrganismOfficeProcessorAsync(OrganismOfficeProcessor organismOfficeProcessor)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismOfficeProcessor";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeProcessor.OrganismId);
                parameters.Add("OfficeId", organismOfficeProcessor.OfficeId);
                parameters.Add("OfficeProcessorId", organismOfficeProcessor.OfficeProcessorId);
                parameters.Add("OfficeProcessorName", organismOfficeProcessor.OfficeProcessorName);
                parameters.Add("OfficeProcessorLastName", organismOfficeProcessor.OfficeProcessorLastName);
                parameters.Add("ContactTypeId", organismOfficeProcessor.ContactTypeId);
                parameters.Add("OfficeProcessorPhone", organismOfficeProcessor.OfficeProcessorPhone);
                parameters.Add("OfficeProcessorFax", organismOfficeProcessor.OfficeProcessorFax);
                parameters.Add("OfficeProcessorEmail", organismOfficeProcessor.OfficeProcessorEmail);
                parameters.Add("OfficeProcessorPrincipal", null);
                parameters.Add("OrganismReasonLowId", organismOfficeProcessor.OrganismReasonLowId);
                parameters.Add("OfficeProcessorLowDate", null);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 OfficeProcessorId From OrganismOfficeProcessor ORDER BY OfficeProcessorId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }


        public async Task<IEnumerable<GetAllOrganismOfficeProcessor>> GetAllOrganismOfficeProcessorAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeProcessor";

                var organismOfficeProcessor = await connection.QueryAsync<GetAllOrganismOfficeProcessor>(query, commandType: CommandType.StoredProcedure);

                return organismOfficeProcessor;

            }
        }


        public async Task<GetOrganismOfficeProcessor> GetOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismOfficeProcessorById";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeProcessorId", organismOfficeProcessorId);

                var organismById = await connection.QuerySingleAsync<GetOrganismOfficeProcessor>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismById;

            }
        }


        public async Task<IEnumerable<GetAllOrganismOfficeProcessorId>> GetAllOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeProcessorById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeProcessorId);

                var organismById = await connection.QueryAsync<GetAllOrganismOfficeProcessorId>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismById;

            }
        }


        public async Task<IEnumerable<GetAllOrganismOfficeProcessorId>> GetAllOrganismOfficeProcessorOfficeByIdAsync(string organismOfficeProcessorOfficeById)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismOfficeProcessorOfficeById";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeId", organismOfficeProcessorOfficeById);

                var organismOfficeProcessorOfffice = await connection.QueryAsync<GetAllOrganismOfficeProcessorId>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismOfficeProcessorOfffice;

            }
        }

        public async Task IsOfficeProcessorPrincipal(int officeId)
        {

            var connection = _connectionFactory.GetConnection;

            string isPrincipal = $"Update OrganismOfficeProcessor SET OfficeProcessorPrincipal = 0 WHERE OfficeId = {officeId}";
            await connection.ExecuteAsync(isPrincipal);
        }

        public async Task<bool> UpdateSelectPrincipalOrganismOfficeProcessorAsync(SelectPrincipalOrganismOfficeProcessor selectPrincipalOrganismOfficeProcessor)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateSelectPrincipalOrganismOfficeProcessor";
                var parameters = new DynamicParameters();

                await IsOfficeProcessorPrincipal(selectPrincipalOrganismOfficeProcessor.OfficeId);

                parameters.Add("OfficeProcessorId", selectPrincipalOrganismOfficeProcessor.OfficeProcessorId);
                parameters.Add("OfficeProcessorPrincipal", selectPrincipalOrganismOfficeProcessor.OfficeProcessorPrincipal);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }


        public async Task<bool> UpdateOrganismOfficeProcessorAsync(OrganismOfficeProcessor organismOfficeProcessor)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganismOfficeProcessor";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismOfficeProcessor.OrganismId);
                parameters.Add("OfficeId", organismOfficeProcessor.OfficeId);
                parameters.Add("OfficeProcessorId", organismOfficeProcessor.OfficeProcessorId);
                parameters.Add("ContactTypeId", organismOfficeProcessor.ContactTypeId);
                parameters.Add("OfficeProcessorName", organismOfficeProcessor.OfficeProcessorName);
                parameters.Add("OfficeProcessorLastName", organismOfficeProcessor.OfficeProcessorLastName);
                parameters.Add("OfficeProcessorPhone", organismOfficeProcessor.OfficeProcessorPhone);
                parameters.Add("OfficeProcessorFax", organismOfficeProcessor.OfficeProcessorFax);
                parameters.Add("OfficeProcessorEmail", organismOfficeProcessor.OfficeProcessorEmail);
                //parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }

        public async Task<bool> DeleteOrganismOfficeProcessorAsync(string organismOfficeProcessorId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismOfficeProcessor";
                var parameters = new DynamicParameters();

                parameters.Add("OfficeProcessorId", organismOfficeProcessorId);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }
        #endregion


        #region [ ORGANISM REPRESENTATIVE METHODS ]
        public async Task<IEnumerable<GetAllOrganismRepresentative>> GetOrganismRepresentativeByIdAsync(string organismId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismRepresentative";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismId);

                var organismRepresentedById = await connection.QueryAsync<GetAllOrganismRepresentative>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismRepresentedById;

            }
        }

        public async Task<int> InsertOrganismRepresentativeAsync(OrganismRepresentative organismRepresentative)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismRepresentative";
                var parameters = new DynamicParameters();

                parameters.Add("RepresentationId", organismRepresentative.RepresentationId);
                parameters.Add("RepresentativeOrganismId", organismRepresentative.RepresentativeOrganismId);
                parameters.Add("RepresentedOrganismId", organismRepresentative.RepresentedOrganismId);
                parameters.Add("RepresentationStartDate", DateTime.UtcNow);
                parameters.Add("RepresentationFinishDate", null);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", null);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 RepresentationId From OrganismRepresentation ORDER BY RepresentationId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }


        public async Task<bool> DeleteOrganismRepresentativeAsync(string organismRepresentativeId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismRepresentation";
                var parameters = new DynamicParameters();

                parameters.Add("RepresentationId", organismRepresentativeId);
                parameters.Add("RepresentationFinishDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<bool> UpdateOrganismRepresentativeAsync(OrganismRepresentative organismRepresentative)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateOrganismRepresentation";
                var parameters = new DynamicParameters();

                parameters.Add("RepresentationId", organismRepresentative.RepresentationId);
                parameters.Add("RepresentativeOrganismId", organismRepresentative.RepresentativeOrganismId);
                parameters.Add("RepresentedOrganismId", organismRepresentative.RepresentedOrganismId);
                //parameters.Add("RepresentationStartDate", DateTime.UtcNow);
                //parameters.Add("RepresentationFinishDate", DateTime.UtcNow);
                //parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }

        public async Task<GetOrganismGeneralsData> GetOrganismGeneralsDataByIdAsync(string organismId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetOrganismGeneralsDataById";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismId);

                var organism = await connection.QuerySingleAsync<GetOrganismGeneralsData>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organism;

            }
        }
        #endregion


        #region [ ORGANISM REPRESENTED METHODS ]
        public async Task<int> InsertOrganismRepresentedAsync(OrganismRepresented organismRepresented)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "InsertOrganismRepresented";
                var parameters = new DynamicParameters();

                parameters.Add("RepresentationId", organismRepresented.RepresentationId);
                parameters.Add("RepresentedOrganismId", organismRepresented.RepresentedOrganismId);
                parameters.Add("RepresentativeOrganismId", organismRepresented.RepresentativeOrganismId);
                parameters.Add("RepresentationStartDate", DateTime.UtcNow);
                parameters.Add("RepresentationFinishDate", null);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                string sql = "SELECT TOP 1 RepresentedOrganismId From OrganismRepresentation ORDER BY RepresentedOrganismId Desc";
                var id = await connection.QueryFirstAsync<int>(sql, new { id = 1 });

                return id;

            }
        }

        public async Task<IEnumerable<GetAllOrganismRepresented>> GetOrganismRepresentedByIdAsync(string organismId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllOrganismRepresented";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organismId);

                var organismRepresentedById = await connection.QueryAsync<GetAllOrganismRepresented>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return organismRepresentedById;

            }
        }

        public async Task<bool> DeleteOrganismRepresentedAsync(string organismRepresentedId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "DeleteOrganismRepresented";
                var parameters = new DynamicParameters();

                parameters.Add("RepresentationId", organismRepresentedId);
                parameters.Add("RepresentationFinishDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }
        #endregion


        #region [ DOCUMENT TYPE ]
        /// <summary>
        /// Get All Document Types
        /// </summary>
        /// <returns> Documents Types </returns>
        public async Task<IEnumerable<DocumentType>> GetAllDocumentTypeAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllDocumentType";

                var documentType = await connection.QueryAsync<DocumentType>(query, commandType: CommandType.StoredProcedure);

                return documentType;

            }
        }
        #endregion


        #region [ COUNTRY METHODS ]
        /// <summary>
        /// Get All Countrys
        /// </summary>
        /// <returns> All Countrys </returns>
        public async Task<IEnumerable<Country>> GetAllCountryAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllCountry";

                var country = await connection.QueryAsync<Country>(query, commandType: CommandType.StoredProcedure);

                return country;

            }
        }


        /// <summary>
        ///  Get Country By Region
        /// </summary>
        /// <returns>All Countries With Regions</returns>
        public async Task<IEnumerable<CountryByRegion>> GetCountryByRegionIdAsync(string countryByRegionId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var storeProcedure = "GetCountryByRegion";

                var parameters = new DynamicParameters();

                parameters.Add("CountryId", countryByRegionId);

                var country = await connection.QueryAsync<CountryByRegion>(storeProcedure, param: parameters, commandType: CommandType.StoredProcedure);

                return country;

            }
        }

        /// <summary>
        /// Get All Phone Code by Country
        /// </summary>
        /// <returns>All Phone Codes With Country</returns>
        public async Task<IEnumerable<PhoneCodeByCountry>> GetAllPhoneCodeByCountryIdAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var storeProcedure = "GetAllPhoneCodeByCountry";

                var phoneCode = await connection.QueryAsync<PhoneCodeByCountry>(storeProcedure, commandType: CommandType.StoredProcedure);

                return phoneCode;

            }
        }
        #endregion


        #region [ REGION METHODS ]
        /// <summary>
        /// Get All Regions
        /// </summary>
        /// <returns> Get All Regions </returns>
        public async Task<IEnumerable<Region>> GetAllRegionAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllRegion";

                var regions = await connection.QueryAsync<Region>(query, commandType: CommandType.StoredProcedure);

                return regions;

            }
        }


        /// <summary>
        /// Get Region By Id
        /// </summary>
        /// <param name="regionId"></param>
        /// <returns> Region By Id </returns>
        public async Task<Region> GetRegionByIdAsync(string regionId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetRegionById";
                var parameters = new DynamicParameters();

                parameters.Add("RegionId", regionId);

                var region = await connection.QuerySingleOrDefaultAsync<Region>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return region;

            }
        }
        #endregion


        #region [ AUTONOMOUS COMMUNITY ]
        public async Task<IEnumerable<AutonomousCommunity>> GetAllAutonomousCommunityAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllAutonomousCommunity";

                var autonomousCommunity = await connection.QueryAsync<AutonomousCommunity>(query, commandType: CommandType.StoredProcedure);

                return autonomousCommunity;

            }
        }
        #endregion


        #region [ PROVINCE SPAIN ]
        public async Task<IEnumerable<ProvinceSpain>> GetAllProvinceSpainAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllProvinceSpain";

                var provinceSpain = await connection.QueryAsync<ProvinceSpain>(query, commandType: CommandType.StoredProcedure);

                return provinceSpain;

            }
        }
        #endregion


        #region [ CITY METHODS ]
        /// <summary>
        /// Get All Citys
        /// </summary>
        /// <returns> Citys </returns>
        public async Task<IEnumerable<City>> GetAllCityAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllCity";

                var city = await connection.QueryAsync<City>(query, commandType: CommandType.StoredProcedure);

                return city;

            }
        }


        /// <summary>
        /// Get City By Id
        /// </summary>
        /// <param name="cityId"></param>
        /// <returns></returns>
        public async Task<City> GetCityByIdAsync(string cityId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "GetCityById";
                var parameters = new DynamicParameters();

                parameters.Add("CityId", cityId);

                var city = await connection.QuerySingleAsync<City>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return city;

            }
        }


        /// <summary>
        ///  Get City By Country
        /// </summary>
        /// <returns>All Cities with Countries</returns>
        public async Task<IEnumerable<CityByRegionByCountry>> GetCityByRegionByCountryAsync(string countryId, string regionId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var storeProcedure = "GetCityByRegionByCountry";

                var parameters = new DynamicParameters();

                parameters.Add("CountryId", countryId);
                parameters.Add("RegionId", regionId);

                var city = await connection.QueryAsync<CityByRegionByCountry>(storeProcedure, param: parameters, commandType: CommandType.StoredProcedure);

                return city;

            }
        }
        #endregion


        #region [ AUTHENTICATE METHODS ]
        /// <summary>
        /// Verificate Email and Password User
        /// </summary>
        /// <param name="login"></param>
        /// <returns> Email And Password User </returns>
        public LoginDTO Authenticate(LoginDTO login)
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "GetUserByUserAndPassword";
                var parameters = new DynamicParameters();

                parameters.Add("Email", login.Email);
                parameters.Add("Password", ConvertToEncrypt(login.Password));

                var user = connection.QuerySingle<LoginDTO>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return login;

            }
        }
        #endregion


        #region [ FORGET PASSWORD METHOD ]
        /// <summary>
        /// Validate Email User If Exists Generate Verification And Insert Code In Database
        /// </summary>
        /// <param name="validateEmail"></param>
        /// <returns> Verification Code </returns>
        public ValidateEmailUserDTO ForgetPassword(ValidateEmailUserDTO validateEmail)
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "ValidateUserEmail";
                var parameters = new DynamicParameters();
                parameters.Add("Email", validateEmail.Email);
                parameters.Add("VerificationCode", Convert.ToInt32(validateEmail.VerificationCode));

                var email = connection.QuerySingle<ValidateEmailUserDTO>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return email;

            }
        }


        /// <summary>
        /// Validate Only Email User
        /// </summary>
        /// <param name="email"></param>
        /// <returns> Email User </returns>
        public async Task<ValidateEmail> GetEmailAsync(string email)
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "GetValidateEmail";
                var parameters = new DynamicParameters();

                parameters.Add("Email", email);

                var validateEmail = await connection.QuerySingleAsync<ValidateEmail>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return validateEmail;

            }
        }


        /// <summary>
        /// Validate Verification Code If Exists In The Database
        /// </summary>
        /// <param name="validateCodeVerificationDTO"></param>
        /// <returns> Verification Code </returns>
        public ValidateVerificationCodeDTO ForgetPasswordVerificationCode(ValidateVerificationCodeDTO validateCodeVerificationDTO)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "ValidateUserVerificationCode";
                var parameters = new DynamicParameters();

                parameters.Add("Email", validateCodeVerificationDTO.Email);
                parameters.Add("VerificationCode", validateCodeVerificationDTO.CodeVerification);

                var code = connection.QuerySingle<ValidateVerificationCodeDTO>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return code;
            }
        }


        /// <summary>
        /// Update Password of User
        /// </summary>
        /// <param name="changeUserPassword"></param>
        /// <returns> New Password </returns>
        public async Task<bool> UpdateUserPasswordAsync(ChangeUserPassword changeUserPassword)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UpdateChangeUserPassword";
                var parameters = new DynamicParameters();

                parameters.Add("Email", changeUserPassword.Email);
                parameters.Add("Password", ConvertToEncrypt(changeUserPassword.Password));

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }

        #endregion


        #region [ ENCRYPT PASSWORD ]
        /// <summary>
        /// Encrypt Password
        /// </summary>
        /// <param name="encryptPassword"></param>
        /// <returns> Password </returns>
        public static string ConvertToEncrypt(string encryptPassword)
        {

            if (string.IsNullOrEmpty(encryptPassword))
            {
                return "";
            }

            encryptPassword += secretKey;
            var passwordBytes = Encoding.UTF8.GetBytes(encryptPassword);

            return Convert.ToBase64String(passwordBytes);
        }
        #endregion

        #endregion

    }
    #endregion
}


