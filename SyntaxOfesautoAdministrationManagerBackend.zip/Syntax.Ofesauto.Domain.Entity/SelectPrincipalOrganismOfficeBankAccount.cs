﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class SelectPrincipalOrganismOfficeBankAccount
    {

        public int BankAccountId { get; set; }

        public int OfficeId { get; set; }

        [Display(Name = "Office Bank Account Principal")]
        public bool OfficeBankAccountPrincipal { get; set; }

    }
}
