﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{

    public class GetOrganismOffice
    {

        public int OrganismId { get; set; }

        public int OfficeId { get; set; }
        public int CityId { get; set; }
        public int CountryId { get; set; }
        public int RegionId { get; set; }

        [Display(Name = "Office Hight Date")]
        public string OfficeHightDate { get; set; }

        [Display(Name = "Country Name")]
        public string CountryName { get; set; }

        [Display(Name = "Region Name")]
        public string RegionName { get; set; }

        [Display(Name = "City Name")]
        public string CityName { get; set; }

        [Display(Name = "Population")]
        public string Population { get; set; }

        [Display(Name = "Office Address")]
        public string OfficeAddress { get; set; }

        [Display(Name = "Office Postal Code")]
        public string OfficePostalCode { get; set; }

        [Display(Name = "Organism Reason Low Name")]
        public string OrganismReasonLowName { get; set; }

        [Display(Name = "Office Low Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime OfficeLowDate { get; set; }

        public bool OfficePrincipal { get; set; }

        public bool IsRepresentation { get; set; }

    }
}
