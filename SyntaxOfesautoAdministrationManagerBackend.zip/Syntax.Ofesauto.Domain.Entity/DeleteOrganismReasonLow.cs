﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class DeleteOrganismReasonLow
    {

        public int OrganismId { get; set; }
        public int OrganismReasonLowId { get; set; }
        public int OrganismIdPassTo { get; set; }
        public DateTime OrganismLowDate { get; set; }
        public DateTime ContactLowDate { get; set; }
        public DateTime BankAccountLowDate { get; set; }
        public DateTime OfficeLowDate { get; set; }
        public DateTime OfficeContactLowDate { get; set; }
        public DateTime OfficeBankAccountLowDate { get; set; }
        public DateTime OfficeProcessorLowDate { get; set; }
    }
}
