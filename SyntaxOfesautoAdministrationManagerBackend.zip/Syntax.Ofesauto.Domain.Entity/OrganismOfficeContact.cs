﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class OrganismOfficeContact
    {


        public int OrganismId { get; set; }

        public int OfficeId { get; set; }

        public int ContactId { get; set; }

        public int ContactTypeId { get; set; }

        [Display(Name = "Office Contact Name")]
        public string ContactName { get; set; }

        [Display(Name = "Office Contact LastName")]
        public string ContactLastName { get; set; }

        [Display(Name = "Office Contact Phone")]
        public string ContactPhone { get; set; }

        [Display(Name = "Office Contact Fax")]
        public string ContactFax { get; set; }

        [Display(Name = "Office Contact Email")]
        public string ContactEmail { get; set; }

        public int? OrganismReasonLowId { get; set; }

        public DateTime? OfficeContactLowDate { get; set; }

        //[Display(Name = "Office Contact Principal")]
        //public bool? OfficeContactPrincipal { get; set; }

    }
}
