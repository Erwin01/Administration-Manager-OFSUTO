﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{

    public class GetAllOrganismOffice
    {

        public int OrganismId { get; set; }

        public int OfficeId { get; set; }
        public int CityId { get; set; }
        public int CountryId { get; set; }
        public int RegionId { get; set; }

        [Display(Name = "Office Address")]
        public string OfficeAddress { get; set; }

        [Display(Name = "Country Name")]
        public string CountryName { get; set; }

        [Display(Name = "Region Name")]
        public string RegionName { get; set; }

        [Display(Name = "City Name")]
        public string CityName { get; set; }

        [Display(Name = "Population")]
        public string Population { get; set; }

        [Display(Name = "Office Contact Principal")]
        public string OfficeContactPrincipal { get; set; }

        public bool IsRepresentation { get; set; }

    }
}
