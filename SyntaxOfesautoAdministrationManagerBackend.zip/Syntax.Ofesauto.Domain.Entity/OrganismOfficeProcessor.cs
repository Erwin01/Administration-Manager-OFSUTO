﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class OrganismOfficeProcessor
    {

        public int OrganismId { get; set; }
        public int OfficeId { get; set; }
        public int OfficeProcessorId { get; set; }
        public string OfficeProcessorName { get; set; }
        public string OfficeProcessorLastName { get; set; }
        public int ContactTypeId { get; set; }
        public string OfficeProcessorPhone { get; set; }
        public string OfficeProcessorFax { get; set; }
        public string OfficeProcessorEmail { get; set; }
        //public bool? OfficeProcessorPrincipal { get; set; }
        public int? OrganismReasonLowId { get; set; }
        public DateTime? OfficeProcessorLowDate { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }

    }
}
