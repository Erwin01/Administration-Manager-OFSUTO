﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class ProvinceSpain
    {

        public int ProvinceId { get; set; }

        [Display(Name = "Province Name")]
        public string ProvinceName { get; set; }
    }
}
