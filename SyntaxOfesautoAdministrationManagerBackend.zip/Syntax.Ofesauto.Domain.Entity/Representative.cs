﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class Representative
    {

        public int RepresentationId { get; set; }

        public int RepresentativeOrganismId { get; set; }

        public int RepresentedOrganismId { get; set; }

        public List<Representative> RepresentativeTo { get; set; }
    }
}
