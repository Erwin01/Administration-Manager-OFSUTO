﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class OrganismBankAccount
    {

        public int OrganismId { get; set; }

        public int BankAccountId { get; set; }

        public string BankAccountName { get; set; }
        
        //Este campo es la relación contact type
        public int BankAccountTypeId { get; set; }

        public int CountryId { get; set; }

        [Display(Name = "Contact LastName")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Contact Phone")]
        public string BankAccountSwift { get; set; }

        [Display(Name = "Contact Fax")]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Contact Email")]
        public DateTime UpdateDate { get; set; }

        //[Display(Name = "Bank Account Principal")]
        //public bool? BankAccountPrincipal { get; set; }
    }
}
