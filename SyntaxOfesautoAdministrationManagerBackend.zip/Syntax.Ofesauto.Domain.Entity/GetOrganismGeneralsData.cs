﻿namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class GetOrganismGeneralsData
    {
        public int OrganismId { get; set; }
        public string OrganismName { get; set; }
        public string OrganismLastName { get; set; }
        public string DocumentTypeName { get; set; }
        public string OrganismCIF { get; set; }
        public string CountryName { get; set; }
        public string RegionName { get; set; }
        public string CityName { get; set; }
        public string OrganismAddress { get; set; }
        public string OrganismPostalCode { get; set; }
    }
}
