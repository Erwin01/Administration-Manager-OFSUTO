﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class SelectPrincipalOrganismOfficeContact
    {

        public int ContactId { get; set; }

        public int OfficeId { get; set; }

        [Display(Name = "Office Contact Principal")]
        public bool OfficeContactPrincipal { get; set; }
    }
}
