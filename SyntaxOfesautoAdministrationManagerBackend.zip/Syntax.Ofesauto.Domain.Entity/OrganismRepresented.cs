﻿namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class OrganismRepresented
    {

        public int RepresentationId { get; set; }

        public int RepresentedOrganismId { get; set; }

        public int RepresentativeOrganismId { get; set; }

        //public DateTime RepresentationStartDate { get; set; }

        //public DateTime RepresentationFinishDate { get; set; }
    }
}
