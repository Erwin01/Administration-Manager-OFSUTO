﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class GetAllContactType
    {

        public int ContactTypeId { get; set; }

        [Display(Name = "Contact Type Name")]
        public string ContactTypeName { get; set; }

        [Display(Name = "Contact Type Description")]
        public string ContactTypeDescription { get; set; }
    }
}
