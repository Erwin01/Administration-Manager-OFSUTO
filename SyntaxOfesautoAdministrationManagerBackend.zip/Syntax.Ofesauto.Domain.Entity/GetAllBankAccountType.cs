﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class GetAllBankAccountType
    {

        public int BankAccountTypeId { get; set; }

        [Display(Name = "Bank Account Type Name")]
        public string BankAccountTypeName { get; set; }

        [Display(Name = "Bank Account Description")]
        public string BankAccountTypeDescription { get; set; }
    }
}
