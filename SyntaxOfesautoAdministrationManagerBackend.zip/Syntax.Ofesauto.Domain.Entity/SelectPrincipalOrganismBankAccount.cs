﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class SelectPrincipalOrganismBankAccount
    {

        public int BankAccountId { get; set; }

        public int OrganismId { get; set; }

        [Display(Name = "Bank Account Principal")]
        public bool BankAccountPrincipal { get; set; }
    }
}
