﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class AutonomousCommunity
    {

        public int AutonomousCommunityId { get; set; }

        [Display(Name = "Autonomous Community")]
        public string AutonomousCommunityName { get; set; }
    }
}
