﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class SelectPrincipalOrganismOffice
    {

        public int OfficeId { get; set; }

        [Display(Name = "Office Principal")]
        public bool OfficePrincipal { get; set; }
    }
}
