﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class ReasonLowOrganism
    {

        public int OrganismId { get; set; }
        
        public int OrganisReasonLowId { get; set; }
        
        //public int OfesautoStateId { get; set; }
        
        public DateTime OrganismLowDate { get; set; }

    }
}
