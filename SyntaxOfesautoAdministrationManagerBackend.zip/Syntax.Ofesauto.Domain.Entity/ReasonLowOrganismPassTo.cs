﻿namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class ReasonLowOrganismPassTo
    {

        public int OrganismId { get; set; }
        public int OrganismIdPassTo { get; set; }

    }
}
