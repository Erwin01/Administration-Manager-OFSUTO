﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class OrganismReasonLow
    {

        public int OrganismReasonLowId { get; set; }

        [Display(Name = "Organism Reason Low Name")]
        public string OrganismReasonLowName { get; set; }

        [Display(Name = "Organism Reason Low Description")]
        public string OrganismReasonLowDescription { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdatedDate { get; set; }
    }
}
