﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class OrganismContact
    {

        public int OrganismId { get; set; }

        public int ContactId { get; set; }

        public int ContactTypeId { get; set; }

        [Display(Name = "Contact Name")]
        public string ContactName { get; set; }

        [Display(Name = "Contact LastName")]
        public string ContactLastName { get; set; }

        [Display(Name = "Contact Phone")]
        public string ContactPhone { get; set; }

        [Display(Name = "Contact Fax")]
        public string ContactFax { get; set; }

        [Display(Name = "Contact Email")]
        public string ContactEmail { get; set; }

        //[Display(Name = "Principal")]
        //public bool? ContactPrincipal { get; set; }

        //[Display(Name = "Created Date")]
        //[DataType(DataType.DateTime)]
        //[DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        //public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdateDate { get; set; }

    }
}
