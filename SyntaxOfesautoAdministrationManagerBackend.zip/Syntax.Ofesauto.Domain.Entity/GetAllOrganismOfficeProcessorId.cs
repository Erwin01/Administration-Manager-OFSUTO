﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class GetAllOrganismOfficeProcessorId
    {

        public int OrganismId { get; set; }
        public int OfficeId { get; set; }
        public int ContactTypeId { get; set; }
        public int OfficeProcessorId { get; set; }
        public string OfficeProcessorName { get; set; }
        public string OfficeProcessorLastName { get; set; }
        public string ContactTypeName { get; set; }
        public string OfficeProcessorPhone { get; set; }
        public string OfficeProcessorFax { get; set; }
        public string OfficeProcessorEmail { get; set; }
        public string OrganismReasonLowName { get; set; }
        public DateTime OfficeProcessorLowDate { get; set; }
        public bool OfficeProcessorPrincipal { get; set; }
    }
}
