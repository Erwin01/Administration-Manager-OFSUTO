﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class OrganismRepresentative
    {
        [Key]
        public int RepresentationId { get; set; }
        public int RepresentativeOrganismId { get; set; }
        public int RepresentedOrganismId { get; set; }
        public DateTime RepresentationStartDate { get; set; }
        public DateTime? RepresentationFinishDate { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
