﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class GetAllOrganismBankAccount
    {

        public int BankAccountId { get; set; }

        public int OrganismId { get; set; }

        [Display(Name = "Contact Type Name")]
        public string ContactTypeName { get; set; }

        [Display(Name = "Bank Account Type Name")]
        public string BankAccountTypeName { get; set; }

        [Display(Name = "Bank Account Name")]
        public string BankAccountName { get; set; }

        [Display(Name = "Bank Account Type Description")]
        public string BankAccountTypeDescription { get; set; }

        [Display(Name = "Country Name")]
        public string CountryName { get; set; }

        public int CountryId { get; set; }

        [Display(Name = "Bank Account Swift")]
        public string BankAccountSwift { get; set; }

        [Display(Name = "Bank Account Number")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Bank Account Principal")]
        public bool BankAccountPrincipal { get; set; }
    }
}
