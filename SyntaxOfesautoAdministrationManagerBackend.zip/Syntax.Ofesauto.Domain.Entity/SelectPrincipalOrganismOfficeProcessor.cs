﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class SelectPrincipalOrganismOfficeProcessor
    {

        public int OfficeProcessorId { get; set; }

        public int OfficeId { get; set; }

        [Display(Name = "Office Processor Principal")]
        public bool OfficeProcessorPrincipal { get; set; }
    }
}
