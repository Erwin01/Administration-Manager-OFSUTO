﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class GetOrganismBankAccount
    {

        public int BankAccountId { get; set; }

        public int OrganismId { get; set; }
        
        public int CountryId { get; set; }

        public string ContactTypeName { get; set; }

        public string BankAccountTypeName { get; set; }

        [Display(Name = "Bank Account Name")]
        public string BankAccountName { get; set; }
        public int BankAccountTypeId { get; set; }

        public string BankAccountTypeDescription { get; set; }

        public string CountryName { get; set; }

        [Display(Name = "Bank Account Swift")]
        public string BankAccountSwift { get; set; }

        [Display(Name = "Bank Account Number")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Bank Account Principal")]
        public bool BankAccountPrincipal { get; set; }
    }
}
