﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class SelectPrincipalOrganismContac
    {

        public int ContactId { get; set; }

        public int OrganismId { get; set; }

        public bool ContactPrincipal { get; set; }
    }
}
