﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class GetAllOrganismRepresentative
    {


        public int RepresentationId { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }

        public string OrganismName { get; set; }

        public DateTime RepresentationStartDate { get; set; }

        public DateTime? RepresentationFinishDate { get; set; }

        public int OrganismId { get; set; }

        public bool IsRepresentation { get; set; }
    }
}
