﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    [Keyless]
    public class GetOrganismToRepresented
    {
        public int OrganismId { get; set; }
        public string OrganismName { get; set; }
        public string OrganismLastName { get; set; }
        public string DocumentTypeName { get; set; }
        public string CountryName { get; set; }
        public int CountryId { get; set; }
        public string OrganismTypeName { get; set; }
        public string OrganismCIF { get; set; }
        public string OfesautoStateName { get; set; }
        public bool RespresentedTo { get; set; }
        public bool RepresentedBy { get; set; }
    }
}
