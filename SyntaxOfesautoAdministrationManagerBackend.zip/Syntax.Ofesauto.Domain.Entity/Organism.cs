﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Domain.Entity
{
    public class Organism
    {

        public int OrganismId { get; set; }

        public int OrganismTypeId { get; set; }

        public int CountryId { get; set; }

        public string Poblation { get; set; }

        public int? RegionId { get; set; }

        public int? CityId { get; set; }

        public string OrganismName { get; set; }

        public string OrganismLastName { get; set; }

        public string DocumentType { get; set; }

        public string OrganismAddress { get; set; }

        public string OrganismPostalCode { get; set; }

        public string OrganismCIF { get; set; }

        public string OrganismWebSite { get; set; }

        public string OrganismCode { get; set; }

        public byte? OrganismReasonLowId { get; set; }

        [Display(Name = "Organism Low Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime? OrganismLowDate { get; set; } = DateTime.Now;

        public int? OrganismIdPassTo { get; set; }

        [Display(Name = "Organism Hight Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime? OrganismHightDate { get; set; } = DateTime.Now;

        public int? OrganismSubTypeId { get; set; }

        public byte OfesautoStateId { get; set; } = 1;

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreateDate { get; set; } = DateTime.Now;

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime? UpdateDate { get; set; } = DateTime.Now;
        
        public int AmbitId { get; set; }
        public OrganismType OrganismType { get; set; }

    }
}
