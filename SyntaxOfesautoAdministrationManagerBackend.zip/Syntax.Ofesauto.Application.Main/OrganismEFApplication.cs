﻿using MoreLinq;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Application.Main
{
    public class OrganismEFApplication : IOrganismEFApplication
    {

        private readonly IOrganismEFDomain _repository;
        private readonly IAppLogger<OrganismEFApplication> _logger;
        public OrganismEFApplication(IOrganismEFDomain repository, IAppLogger<OrganismEFApplication> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        public async Task<Response<OrganismDTO>> Add(OrganismDTO obj)
        {
            try
            {

                var mapp = AutoMapp<OrganismDTO, Organism>.Convert(obj);
                var add = await _repository.Add(mapp);
                obj.OrganismId = add.OrganismId;
                return Response<OrganismDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OrganismDTO>.Error(null, ex, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.OrganismId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Error(false, ex, ex.Message, false);
            }
        }

        public async Task<Response<List<OrganismDTO>>> GetAll()
        {

            try
            {
                var ListData = await _repository.GetAll();
                var mapp = AutoMapp<Organism, OrganismDTO>.ConvertList2(ListData);
                return Response<List<OrganismDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<OrganismDTO>>.Error(null, ex, ex.Message, false);
            }

        }

        public async Task<Response<OrganismDTO>> GetById(int id)
        {
            try
            {
                var ListData = await _repository.GetById(id);
                var data = AutoMapp<Organism, OrganismDTO>.Convert(ListData);
                return Response<OrganismDTO>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<OrganismDTO>.Error(null, ex, ex.Message, false);
            }
        }

        public async Task<Response<List<GetAllOrganismDTO>>> GetOrganismParam(ParamOrganismDTO paramsDto)
        {
            try
            {
                var ListData = await _repository.GetOrganismParam(paramsDto.Countries, paramsDto.OrgaismTypes, paramsDto.status);
                var mapp = AutoMapp<GetAllOrganism, GetAllOrganismDTO>.ConvertList2(ListData);
                return Response<List<GetAllOrganismDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<GetAllOrganismDTO>>.Error(null, ex, ex.Message, false);
            }

        }

        public async  Task<Response<List<OrganismDTO>>> ListOrganismCompany(int CountryId, int OrganismId)
        {
            try
            {
                var ListData = await _repository.ListOrganismCompany(CountryId, OrganismId);
                var mapp = AutoMapp<Organism, OrganismDTO>.ConvertList2(ListData);
                return Response<List<OrganismDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<OrganismDTO>>.Error(null, ex, ex.Message, false);
            }
        }

        public async Task<Response<OrganismDTO>> Update(OrganismDTO obj, int id)
        {
            try
            {
                var mapp = AutoMapp<OrganismDTO, Organism>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<OrganismDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OrganismDTO>.Error(null, ex, ex.Message, false);
            }
        }

    }
}
