﻿using AutoMapper;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.Security.Application.DTO;
using Syntax.Ofesauto.Security.Domain.Entity;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Application.Main
{

    /// <summary>
    /// Maps with DTO's and business entities and vice versa
    /// </summary>
    public class OrganismApplication : IOrganismApplication
    {
        /// <summary>
        /// Variables globlals
        /// </summary>
        private readonly IOrganismDomain _organismDomain;
        private readonly IMapper _mapper;
        private readonly IAppLogger<OrganismApplication> _logger;

        /// <summary>
        /// This method allows to perform dependency injection
        /// </summary>

        /// <param name="userDomain"></param>
        /// <param name="imapper"></param>

        /// <param name="userDomain"></param>
        /// <param name="imapper"></param>
        /// <param name="appLogger"></param>

        public OrganismApplication(IOrganismDomain userDomain, IMapper imapper, IAppLogger<OrganismApplication> appLogger)
        {
            _organismDomain = userDomain;
            _mapper = imapper;
            _logger = appLogger;
        }


        #region [ ASYNCHRONOUS METHODS ]



        #region [ METHODS ORGANISM ] 

        #region [ ORGANISM METHODS ] 

        /// <summary>
        /// Insert Organism
        /// </summary>
        /// <param name="organismDTO"></param>
        /// <returns></returns>
        public async Task<Response<int>> InsertOrganismAsync(OrganismDTO organismDTO)
        {
            var response = new Response<int>();

            try
            {
                var organism = _mapper.Map<Organism>(organismDTO);
                response.Data = await _organismDomain.InsertOrganismAsync(organism);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organisms
        /// </summary>
        /// <returns> Organisms </returns>
        public async Task<Response<IEnumerable<GetAllOrganismDTO>>> GetAllOrganismAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismDTO>>();

            try
            {

                var organisms = await _organismDomain.GetAllOrganismAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismDTO>>(organisms);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organisms are company
        /// </summary>
        /// <returns> Organisms </returns>
        public async Task<Response<IEnumerable<GetAllOrganismDTO>>> GetAllOrganismsCompanyAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismDTO>>();

            try
            {

                var organisms = await _organismDomain.GetAllOrganismsCompanyAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismDTO>>(organisms);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Update Organism
        /// </summary>
        /// <param name="organismDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> UpdateOrganismAsync(OrganismDTO organismDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organism = _mapper.Map<Organism>(organismDTO);
                response.Data = await _organismDomain.UpdateOrganismAsync(organism);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get Organism By Id
        /// </summary>
        /// <param name="organismId"></param>
        /// <returns> Organism Id </returns>
        public async Task<Response<ViewOrganismDTO>> GetOrganismByIdAsync(string organismId)
        {
            var response = new Response<ViewOrganismDTO>();

            try
            {

                var organismById = await _organismDomain.GetOrganismByIdAsync(organismId);
                response.Data = _mapper.Map<ViewOrganismDTO>(organismById);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismById.OrganismId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Delete REason Low by Id
        /// </summary>
        /// <param name="reasonLowOrganismDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> DeleteReasonLowByIdAsync(ReasonLowOrganismDTO reasonLowOrganismDTO)
        {
            var response = new Response<bool>();

            try
            {
                var reasonLowOrganism = _mapper.Map<ReasonLowOrganism>(reasonLowOrganismDTO);
                response.Data = await _organismDomain.DeleteReasonLowByIdAsync(reasonLowOrganism);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Delete Reason Low Pass To By Id
        /// </summary>
        /// <param name="reasonLowOrganismPassToDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> DeleteReasonLowPassToByIdAsync(ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        {
            var response = new Response<bool>();

            try
            {
                var reasonLowOrganismPassTo = _mapper.Map<ReasonLowOrganismPassTo>(reasonLowOrganismPassToDTO);
                response.Data = await _organismDomain.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassTo);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organisms Types
        /// </summary>
        /// <returns> Organism Types </returns>
        public async Task<Response<IEnumerable<OrganismTypeDTO>>> GetAllOrganismTypeAsync()
        {
            var response = new Response<IEnumerable<OrganismTypeDTO>>();

            try
            {

                var organismType = await _organismDomain.GetAllOrganismTypeAsync();
                response.Data = _mapper.Map<IEnumerable<OrganismTypeDTO>>(organismType);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organisms SubTypes
        /// </summary>
        /// <returns> Organism SubTypes </returns>
        public async Task<Response<IEnumerable<OrganismSubTypeDTO>>> GetAllOrganismSubTypeAsync()
        {
            var response = new Response<IEnumerable<OrganismSubTypeDTO>>();

            try
            {

                var organismSubType = await _organismDomain.GetAllOrganismSubTypeAsync();
                response.Data = _mapper.Map<IEnumerable<OrganismSubTypeDTO>>(organismSubType);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organism Reason Low
        /// </summary>
        /// <returns> Organisms Reason Low </returns>
        /// 
        public async Task<Response<IEnumerable<OrganismReasonLowDTO>>> GetAllOrganismReasonLowAsync()
        {
            var response = new Response<IEnumerable<OrganismReasonLowDTO>>();

            try
            {

                var organismReasonLow = await _organismDomain.GetAllOrganismReasonLowAsync();
                response.Data = _mapper.Map<IEnumerable<OrganismReasonLowDTO>>(organismReasonLow);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Delete Organism Pass To
        /// </summary>
        /// <param name="deleteOrganismReasonLowDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> DeleteOrganismReasonLowPassToByIdAsync(DeleteOrganismReasonLowDTO deleteOrganismReasonLowDTO)
        {
            var response = new Response<bool>();

            try
            {
                var deleteOrganismReasonLow = _mapper.Map<DeleteOrganismReasonLow>(deleteOrganismReasonLowDTO);
                response.Data = await _organismDomain.DeleteOrganismReasonLowPassToByIdAsync(deleteOrganismReasonLow);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ ORGANISM CONTACTS METHODS ]
        /// <summary>
        /// Insert Organism Contact
        /// </summary>
        /// <param name="organismContactDTO"></param>
        /// <returns> Organism Contact </returns>
        public async Task<Response<int>> InsertOrganismContactAsync(OrganismContactDTO organismContactDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismContact = _mapper.Map<OrganismContact>(organismContactDTO);
                response.Data = await _organismDomain.InsertOrganismContactAsync(organismContact);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Update Organism Contac
        /// </summary>
        /// <param name="organismContactDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> UpdateOrganismContactAsync(OrganismContactDTO organismContactDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organismContact = _mapper.Map<OrganismContact>(organismContactDTO);
                response.Data = await _organismDomain.UpdateOrganismContactAsync(organismContact);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organism Contact
        /// </summary>
        /// <returns></returns>
        /// <returns> Organism Contacts </returns>
        public async Task<Response<IEnumerable<GetAllOrganismContactDTO>>> GetAllOrganismContactAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismContactDTO>>();

            try
            {

                var getAllOrganismContact = await _organismDomain.GetAllOrganismContactAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismContactDTO>>(getAllOrganismContact);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get Organism Contact By Id
        /// </summary>
        /// <param name="organismContactId"></param>
        /// <returns> Organism Id </returns>
        public async Task<Response<GetOrganismContactDTO>> GetOrganismContactByIdAsync(string organismContactId)
        {
            var response = new Response<GetOrganismContactDTO>();

            try
            {

                var organismContact = await _organismDomain.GetOrganismContactByIdAsync(organismContactId);
                response.Data = _mapper.Map<GetOrganismContactDTO>(organismContact);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismContactId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All organism Contact By Id
        /// </summary>
        /// <param name="organismContactId"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<GetOrganismContactDTO>>> GetAllOrganismContactByIdAsync(string organismContactId)
        {
            var response = new Response<IEnumerable<GetOrganismContactDTO>>();

            try
            {
                var organismContact = await _organismDomain.GetAllOrganismContactByIdAsync(organismContactId);
                response.Data = _mapper.Map<IEnumerable<GetOrganismContactDTO>>(organismContact);

                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismContactId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Select Principal Organism Contact 
        /// </summary>
        /// <param name="selectPrincipalOrganismContactDTO"></param>
        /// <returns> True or False </returns>
        public async Task<Response<bool>> UpdateSelectPrincipalOrganismContactAsync(SelectPrincipalOrganismContactDTO selectPrincipalOrganismContactDTO)
        {
            var response = new Response<bool>();

            try
            {
                var selectPrincipalOrganismContact = _mapper.Map<SelectPrincipalOrganismContac>(selectPrincipalOrganismContactDTO);
                response.Data = await _organismDomain.UpdateSelectPrincipalOrganismContactAsync(selectPrincipalOrganismContact);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Delete OrganismContact By Id
        /// </summary>
        /// <param name="organismContactId"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> DeleteOrganismContactAsync(string organismContactId)
        {
            var response = new Response<bool>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismContactAsync(organismContactId);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A user was deleted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organism Contacts Type
        /// </summary>
        /// <returns> Type Contacts </returns>
        public async Task<Response<IEnumerable<GetAllContactTypeDTO>>> GetAllOrganismContactTypeAsync()
        {
            var response = new Response<IEnumerable<GetAllContactTypeDTO>>();

            try
            {

                var getAllContactType = await _organismDomain.GetAllOrganismContactTypeAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllContactTypeDTO>>(getAllContactType);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ ORGANISM BANK ACCOUNT METHODS ]
        public async Task<Response<int>> InsertOrganismBankAccountAsync(OrganismBankAccountDTO organismBankAccountDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismBankAccount = _mapper.Map<OrganismBankAccount>(organismBankAccountDTO);
                response.Data = await _organismDomain.InsertOrganismBankAccountAsync(organismBankAccount);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Update Organism Bank Account Type
        /// </summary>
        /// <param name="organismBankAccountDTO"></param>
        /// <returns> </returns>
        public async Task<Response<bool>> UpdateOrganismBankAccountAsync(OrganismBankAccountDTO organismBankAccountDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organismBankAccount = _mapper.Map<OrganismBankAccount>(organismBankAccountDTO);
                response.Data = await _organismDomain.UpdateOrganismBankAccountAsync(organismBankAccount);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Bank Account Type
        /// </summary>
        /// <returns> Organisms </returns>
        public async Task<Response<IEnumerable<GetAllBankAccountTypeDTO>>> GetAllOrganismBankAccountTypeAsync()
        {
            var response = new Response<IEnumerable<GetAllBankAccountTypeDTO>>();

            try
            {

                var getAllBankAccountType = await _organismDomain.GetAllOrganismBankAccountTypeAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllBankAccountTypeDTO>>(getAllBankAccountType);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organism Bank Account
        /// </summary>
        /// <returns> Get All </returns>
        public async Task<Response<IEnumerable<GetAllOrganismBankAccountDTO>>> GetAllOrganismBankAccountAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismBankAccountDTO>>();

            try
            {

                var organismBankAccount = await _organismDomain.GetAllOrganismBankAccountAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismBankAccountDTO>>(organismBankAccount);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get Organism Bank Account By Id
        /// </summary>
        /// <param name="organismBankAccountId"></param>
        /// <returns></returns>
        public async Task<Response<GetOrganismBankAccountDTO>> GetOrganismBankAccountByIdAsync(string organismBankAccountId)
        {
            var response = new Response<GetOrganismBankAccountDTO>();

            try
            {

                var organismBankAccount = await _organismDomain.GetOrganismBankAccountByIdAsync(organismBankAccountId);
                response.Data = _mapper.Map<GetOrganismBankAccountDTO>(organismBankAccount);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismBankAccountId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Bank Account By Id
        /// </summary>
        /// <param name="organismBankAccountId"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<GetOrganismBankAccountDTO>>> GetAllOrganismBankAccountByIdAsync(string organismBankAccountId)
        {
            var response = new Response<IEnumerable<GetOrganismBankAccountDTO>>();

            try
            {
                var organismBankAccount = await _organismDomain.GetAllOrganismBankAccountByIdAsync(organismBankAccountId);
                response.Data = _mapper.Map<IEnumerable<GetOrganismBankAccountDTO>>(organismBankAccount);

                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismBankAccountId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }



        /// <summary>
        /// Select Principal Organism Bank Account
        /// </summary>
        /// <param name="selectPrincipalOrganismBankAccountDTO"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> UpdateSelectPrincipalOrganismBankAccountAsync(SelectPrincipalOrganismBankAccountDTO selectPrincipalOrganismBankAccountDTO)
        {
            var response = new Response<bool>();

            try
            {
                var selectPrincipalOrganismBankAccount = _mapper.Map<SelectPrincipalOrganismBankAccount>(selectPrincipalOrganismBankAccountDTO);
                response.Data = await _organismDomain.UpdateSelectPrincipalOrganismBankAccountAsync(selectPrincipalOrganismBankAccount);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Delete Organism Bank Account
        /// </summary>
        /// <param name="organismBankAccountId"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> DeleteOrganismBankAccountAsync(int organismBankAccountId)
        {
            var response = new Response<bool>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismBankAccountAsync(organismBankAccountId);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A user was deleted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ ORGANISM OFFICE METHODS ]
        /// <summary>
        /// Insert Organism Office
        /// </summary>
        /// <param name="organismOfficeDTO"></param>
        /// <returns> Organism Office </returns>
        public async Task<Response<int>> InsertOrganismOfficeAsync(OrganismOfficeDTO organismOfficeDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismOffice = _mapper.Map<OrganismOffice>(organismOfficeDTO);
                response.Data = await _organismDomain.InsertOrganismOfficeAsync(organismOffice);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Office
        /// </summary>
        /// <returns> Get All </returns>
        public async Task<Response<IEnumerable<GetAllOrganismOfficeDTO>>> GetAllOrganismOfficeAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismOfficeDTO>>();

            try
            {

                var getAllOrganismOffice = await _organismDomain.GetAllOrganismOfficeAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismOfficeDTO>>(getAllOrganismOffice);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Update organism Office
        /// </summary>
        /// <param name="organismOfficeDTO"></param>
        /// <returns> Organism Office </returns>
        public async Task<Response<bool>> UpdateOrganismOfficeGeneralDataAsync(OrganismOfficeDTO organismOfficeDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organismOffice = _mapper.Map<OrganismOffice>(organismOfficeDTO);
                response.Data = await _organismDomain.UpdateOrganismOfficeGeneralDataAsync(organismOffice);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get Organism Office By Id
        /// </summary>
        /// <param name="officeId"></param>
        /// <returns> Organism Office </returns>
        public async Task<Response<IEnumerable<GetOrganismOfficeDTO>>> GetOrganismOfficeByIdAsync(string officeId)
        {
            var response = new Response<IEnumerable<GetOrganismOfficeDTO>>();

            try
            {

                var organismOffice = await _organismDomain.GetOrganismOfficeByIdAsync(officeId);
                response.Data = _mapper.Map<IEnumerable<GetOrganismOfficeDTO>>(organismOffice);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{officeId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Office By Id
        /// </summary>
        /// <param name="organismOfficeId"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<GetOrganismOfficeDTO>>> GetAllOrganismOfficeByIdAsync(string organismOfficeId)
        {
            var response = new Response<IEnumerable<GetOrganismOfficeDTO>>();

            try
            {

                var organismOffice = await _organismDomain.GetAllOrganismOfficeByIdAsync(organismOfficeId);
                response.Data = _mapper.Map<IEnumerable<GetOrganismOfficeDTO>>(organismOffice);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organism Office Bank Account Office By Id
        /// </summary>
        /// <param name="organismOfficeBankAccountOfficeById"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>> GetAllOrganismOfficeBankAccountOfficeByIdAsync(string organismOfficeBankAccountOfficeById)
        {
            var response = new Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>();

            try
            {
                var organismOfficeBankAccountOffice = await _organismDomain.GetAllOrganismOfficeBankAccountOfficeByIdAsync(organismOfficeBankAccountOfficeById);
                var mapp = AutoMapp<GetOrganismOfficeBankAccount, GetOrganismOfficeBankAccountDTO>.ConvertList(organismOfficeBankAccountOffice);
               // response.Data = mapp;//_mapper.Map<IEnumerable<GetOrganismOfficeBankAccountDTO>>(organismOfficeBankAccountOffice);
                return Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>.Error(null, ex, ex.Message, false);
            }
        }


        /// <summary>
        /// Select principal Organism Office
        /// </summary>
        /// <param name="selectPrincipalOrganismOfficeDTO"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeAsync(SelectPrincipalOrganismOfficeDTO selectPrincipalOrganismOfficeDTO)
        {
            var response = new Response<bool>();

            try
            {
                var selectPrincipalOrganismOffice = _mapper.Map<SelectPrincipalOrganismOffice>(selectPrincipalOrganismOfficeDTO);
                response.Data = await _organismDomain.UpdateSelectPrincipalOrganismOfficeAsync(selectPrincipalOrganismOffice);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Delete Organism Office
        /// </summary>
        /// <param name="organismOfficeId"></param>
        /// <returns> True </returns>
        public async Task<Response<int>> DeleteOrganismOfficeAsync(int organismOfficeId)
        {
            var response = new Response<int>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismOfficeAsync(organismOfficeId);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A user was deleted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ ORGANISM OFFICE CONTACT METHODS ]
        /// <summary>
        /// Insert Organism Office Contact
        /// </summary>
        /// <param name="organismOfficeContactDTO"></param>
        /// <returns> Office Contact </returns>
        public async Task<Response<int>> InsertOrganismOfficeContactAsync(OrganismOfficeContactDTO organismOfficeContactDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismOfficeContact = _mapper.Map<OrganismOfficeContact>(organismOfficeContactDTO);
                response.Data = await _organismDomain.InsertOrganismOfficeContactAsync(organismOfficeContact);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Office
        /// </summary>
        /// <returns> Organisms Office Contacts </returns>
        public async Task<Response<IEnumerable<GetAllOrganismOfficeContactsDTO>>> GetAllOrganismOfficeContactAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismOfficeContactsDTO>>();

            try
            {

                var organismOfficeContact = await _organismDomain.GetAllOrganismOfficeContactAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismOfficeContactsDTO>>(organismOfficeContact);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Update Organism Office Contact
        /// </summary>
        /// <param name="organismOfficeContactDTO"></param>
        /// <returns> Organism Office Contact </returns>
        public async Task<Response<bool>> UpdateOrganismOfficeContactAsync(OrganismOfficeContactDTO organismOfficeContactDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organismOfficeContact = _mapper.Map<OrganismOfficeContact>(organismOfficeContactDTO);
                response.Data = await _organismDomain.UpdateOrganismOfficeContactAsync(organismOfficeContact);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get Organism Office Contact By Id
        /// </summary>
        /// <param name="contactId"></param>
        /// <returns> Organism Office Contact </returns>
        public async Task<Response<IEnumerable<GetOrganismOfficeContactByIdDTO>>> GetOrganismOfficeContactByIdAsync(string contactId)
        {
            var response = new Response<IEnumerable<GetOrganismOfficeContactByIdDTO>>();

            try
            {

                var organismOfficeContact = await _organismDomain.GetOrganismOfficeContactByIdAsync(contactId);
                response.Data = _mapper.Map<IEnumerable<GetOrganismOfficeContactByIdDTO>>(organismOfficeContact);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeContact}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organism Office Contact By Id's
        /// </summary>
        /// <param name="organismOfficeContactId"></param>
        /// <returns> All Organism Office Contacts </returns>
        public async Task<Response<IEnumerable<GetAllOrganismOfficeContactDTO>>> GetAllOrganismOfficeContactByIdAsync(string organismOfficeContactId)
        {
            var response = new Response<IEnumerable<GetAllOrganismOfficeContactDTO>>();

            try
            {

                var organismOfficeContact = await _organismDomain.GetAllOrganismOfficeContactByIdAsync(organismOfficeContactId);
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismOfficeContactDTO>>(organismOfficeContact);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeContactId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }



        /// <summary>
        /// Get All Organism Office Contact By Office Id
        /// </summary>
        /// <param name="organismOfficeContactOfficeById"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<GetOrganismOfficeContactByIdDTO>>> GetAllOrganismOfficeContactOfficeByIdAsync(string organismOfficeContactOfficeById)
        {
            var response = new Response<IEnumerable<GetOrganismOfficeContactByIdDTO>>();

            try
            {

                var organismOfficeContactOffice = await _organismDomain.GetAllOrganismOfficeContactOfficeByIdAsync(organismOfficeContactOfficeById);
                response.Data = _mapper.Map<IEnumerable<GetOrganismOfficeContactByIdDTO>>(organismOfficeContactOffice);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeContactOfficeById}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Select Principal Organism Office Contact
        /// </summary>
        /// <param name="selectPrincipalOrganismOfficeContactDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeContactAsync(SelectPrincipalOrganismOfficeContactDTO selectPrincipalOrganismOfficeContactDTO)
        {
            var response = new Response<bool>();

            try
            {
                var selectPrincipalOrganismOfficeContact = _mapper.Map<SelectPrincipalOrganismOfficeContact>(selectPrincipalOrganismOfficeContactDTO);
                response.Data = await _organismDomain.UpdateSelectPrincipalOrganismOfficeContactAsync(selectPrincipalOrganismOfficeContact);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Delete Organism Office Contact
        /// </summary>
        /// <param name="organismOfficeContactId"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> DeleteOrganismOfficeContactAsync(string organismOfficeContactId)
        {
            var response = new Response<bool>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismOfficeContactAsync(organismOfficeContactId);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A user was deleted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ ORGANISM OFFICE BANK ACCOUNT ]
        /// <summary>
        /// Insert Office Bank Account
        /// </summary>
        /// <param name="organismOfficeBankAccountDTO"></param>
        /// <returns> Office Bank Account </returns>
        public async Task<Response<int>> InsertOrganismOfficeBankAccountAsync(OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismOfficeBankAccount = AutoMapp<OrganismOfficeBankAccountDTO, OrganismOfficeBankAccount>.Convert(organismOfficeBankAccountDTO);
                //var organismOfficeBankAccount = _mapper.Map<OrganismOfficeBankAccount>(organismOfficeBankAccountDTO);
                response.Data = await _organismDomain.InsertOrganismOfficeBankAccountAsync(organismOfficeBankAccount);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Office Bank Account
        /// </summary>
        /// <returns> Get All Organisms Office Bank Account </returns>
        public async Task<Response<IEnumerable<GetAllOrganismOfficeBankAccountDTO>>> GetAllOrganismOfficeBankAccountAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismOfficeBankAccountDTO>>();

            try
            {

                var organismOfficeBankAccount = await _organismDomain.GetAllOrganismOfficeBankAccountAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismOfficeBankAccountDTO>>(organismOfficeBankAccount);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get Organism Office Bank Account By Id
        /// </summary>
        /// <param name="organismOfficeBankAccountById"></param>
        /// <returns></returns>
        public async Task<Response<GetOrganismOfficeBankAccountDTO>> GetOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById)
        {
            var response = new Response<GetOrganismOfficeBankAccountDTO>();

            try
            {

                var organismOfficeBankAccount = await _organismDomain.GetOrganismOfficeBankAccountByIdAsync(organismOfficeBankAccountById);
                response.Data = _mapper.Map<GetOrganismOfficeBankAccountDTO>(organismOfficeBankAccount);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeBankAccountById}");
                }
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Office Bank Account By Id
        /// </summary>
        /// <param name="organismOfficeBankAccountById"></param>
        /// <returns> All Organism Office Bank Account Id's </returns>
        public async Task<Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>> GetAllOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById)
        {
            var response = new Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>();

            try
            {

                var organismOfficeBankAccount = await _organismDomain.GetAllOrganismOfficeBankAccountByIdAsync(organismOfficeBankAccountById);
                response.Data = _mapper.Map<IEnumerable<GetOrganismOfficeBankAccountDTO>>(organismOfficeBankAccount);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeBankAccountById}");
                }
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Select Principal Organism Office Bank Account
        /// </summary>
        /// <param name="selectPrincipalOrganismOfficeBankAccountDTO"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeBankAccount(SelectPrincipalOrganismOfficeBankAccountDTO selectPrincipalOrganismOfficeBankAccountDTO)
        {
            var response = new Response<bool>();

            try
            {
                var selectPrincipalOrganismBankAccount = _mapper.Map<SelectPrincipalOrganismOfficeBankAccount>(selectPrincipalOrganismOfficeBankAccountDTO);
                response.Data = await _organismDomain.UpdateSelectPrincipalOrganismOfficeBankAccount(selectPrincipalOrganismBankAccount);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Update Organism Office Account
        /// </summary>
        /// <param name="organismOfficeBankAccountDTO"></param>
        /// <returns> Organism Office Account </returns>
        public async Task<Response<bool>> UpdateOrganismOfficeBankAccountAsync(OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organismOfficeBankAccount = _mapper.Map<OrganismOfficeBankAccount>(organismOfficeBankAccountDTO);
                organismOfficeBankAccount.CountryId = organismOfficeBankAccountDTO.CountryId;
                response.Data = await _organismDomain.UpdateOrganismOfficeBankAccountAsync(organismOfficeBankAccount);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Delete Organism Office Bank Account
        /// </summary>
        /// <param name="organismBankAccountId"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> DeleteOrganismOfficeBankAccountAsync(int organismBankAccountId)
        {
            var response = new Response<bool>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismOfficeBankAccountAsync(organismBankAccountId);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A bank office was deleted!");
                }
                return response;
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
                return Response<bool>.Error(false, e, "An error has occurred please try again, if the error persists contact the administrator", false);
            }


        }
        #endregion


        #region [ ORGANISM OFFICE PROCESSOR METHODS ]
        /// <summary>
        /// Insert Organism Office Processor
        /// </summary>
        /// <param name="organismOfficeProcessorDTO"></param>
        /// <returns> Organism Office Processor </returns>
        public async Task<Response<int>> InsertOrganismOfficeProcessorAsync(OrganismOfficeProcessorDTO organismOfficeProcessorDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismOfficeProcessor = _mapper.Map<OrganismOfficeProcessor>(organismOfficeProcessorDTO);
                response.Data = await _organismDomain.InsertOrganismOfficeProcessorAsync(organismOfficeProcessor);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Office Processor
        /// </summary>
        /// <returns> Get All Organism Office Processor </returns>
        public async Task<Response<IEnumerable<GetAllOrganismOfficeProcessorDTO>>> GetAllOrganismOfficeProcessorAsync()
        {
            var response = new Response<IEnumerable<GetAllOrganismOfficeProcessorDTO>>();

            try
            {

                var organismOfficeProcessor = await _organismDomain.GetAllOrganismOfficeProcessorAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismOfficeProcessorDTO>>(organismOfficeProcessor);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get Organism Office Processor By Id
        /// </summary>
        /// <param name="organismOfficeProcessorId"></param>
        /// <returns> Id </returns>
        public async Task<Response<GetOrganismOfficeProcessorDTO>> GetOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId)
        {
            var response = new Response<GetOrganismOfficeProcessorDTO>();

            try
            {

                var organismOfficeProcessor = await _organismDomain.GetOrganismOfficeProcessorByIdAsync(organismOfficeProcessorId);
                response.Data = _mapper.Map<GetOrganismOfficeProcessorDTO>(organismOfficeProcessor);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeProcessorId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        public async Task<Response<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>> GetAllOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId)
        {
            var response = new Response<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>();

            try
            {

                var organismOfficeProcessor = await _organismDomain.GetAllOrganismOfficeProcessorByIdAsync(organismOfficeProcessorId);
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>(organismOfficeProcessor);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeProcessorId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All Organism Office Processor Office By Id
        /// </summary>
        /// <param name="organismOfficeProcessorOfficeById"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>> GetAllOrganismOfficeProcessorOfficeByIdAsync(string organismOfficeProcessorOfficeById)
        {
            var response = new Response<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>();

            try
            {

                var organismOfficeProcessorOffice = await _organismDomain.GetAllOrganismOfficeProcessorOfficeByIdAsync(organismOfficeProcessorOfficeById);
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>(organismOfficeProcessorOffice);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismOfficeProcessorOfficeById}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Select Principal Organism Office Processor
        /// </summary>
        /// <param name="selectPrincipalOrganismOfficeProcessorDTO"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeProcessorAsync(SelectPrincipalOrganismOfficeProcessorDTO selectPrincipalOrganismOfficeProcessorDTO)
        {
            var response = new Response<bool>();

            try
            {
                var selectPrincipalOrganismOfficeProcessor = _mapper.Map<SelectPrincipalOrganismOfficeProcessor>(selectPrincipalOrganismOfficeProcessorDTO);
                response.Data = await _organismDomain.UpdateSelectPrincipalOrganismOfficeProcessorAsync(selectPrincipalOrganismOfficeProcessor);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        public async Task<Response<bool>> UpdateOrganismOfficeProcessorAsync(OrganismOfficeProcessorDTO organismOfficeProcessorDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organismOfficeProcessor = _mapper.Map<OrganismOfficeProcessor>(organismOfficeProcessorDTO);
                response.Data = await _organismDomain.UpdateOrganismOfficeProcessorAsync(organismOfficeProcessor);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Delete Organism Office Processor
        /// </summary>
        /// <param name="organismOfficeProcessorId"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> DeleteOrganismOfficeProcessorAsync(string organismOfficeProcessorId)
        {
            var response = new Response<bool>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismOfficeProcessorAsync(organismOfficeProcessorId);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A user was deleted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ ORGANISM REPRESENTATIVE METHODS ]
        /// <summary>
        /// Get All Organims Representatives By Id
        /// </summary>
        /// <param name="organismId"></param>
        /// <returns> All Organims Representatives By Id </returns>
        public async Task<Response<IEnumerable<GetAllOrganismRepresentativeDTO>>> GetOrganismRepresentativeByIdAsync(string organismId)
        {
            var response = new Response<IEnumerable<GetAllOrganismRepresentativeDTO>>();

            try
            {

                var organismById = await _organismDomain.GetOrganismRepresentativeByIdAsync(organismId);
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismRepresentativeDTO>>(organismById);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismById}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Insert Organism Representative
        /// </summary>
        /// <param name="organismRepresentativeDTO"></param>
        /// <returns> Organism Representative </returns>
        public async Task<Response<int>> InsertOrganismRepresentativeAsync(OrganismRepresentativeDTO organismRepresentativeDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismRepresentative = _mapper.Map<OrganismRepresentative>(organismRepresentativeDTO);
                response.Data = await _organismDomain.InsertOrganismRepresentativeAsync(organismRepresentative);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Delete Organism Representative
        /// </summary>
        /// <param name="organismRepresentativeId"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> DeleteOrganismRepresentativeAsync(string organismRepresentativeId)
        {
            var response = new Response<bool>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismRepresentativeAsync(organismRepresentativeId);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A user was deleted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Update Organism Representative
        /// </summary>
        /// <param name="representativeDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> UpdateOrganismRepresentativeAsync(OrganismRepresentativeDTO representativeDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organismRepresentative = _mapper.Map<OrganismRepresentative>(representativeDTO);
                response.Data = await _organismDomain.UpdateOrganismRepresentativeAsync(organismRepresentative);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("A user was updated!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get Organism Generals Data By Id
        /// </summary>
        /// <param name="organismId"></param>
        /// <returns> Organism Generals Data By Id </returns>
        public async Task<Response<GetOrganismGeneralsDataDTO>> GetOrganismGeneralsDataByIdAsync(string organismId)
        {
            var response = new Response<GetOrganismGeneralsDataDTO>();

            try
            {

                var organism = await _organismDomain.GetOrganismGeneralsDataByIdAsync(organismId);
                response.Data = _mapper.Map<GetOrganismGeneralsDataDTO>(organism);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismId}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ ORGANISM REPRESENTED METHODS ]
        /// <summary>
        /// Insert Organism Represented
        /// </summary>
        /// <param name="organismRepresentedDTO"></param>
        /// <returns> Organism Represented </returns>
        public async Task<Response<int>> InsertOrganismRepresentedAsync(OrganismRepresentedDTO organismRepresentedDTO)
        {
            var response = new Response<int>();

            try
            {
                var organismRepresented = _mapper.Map<OrganismRepresented>(organismRepresentedDTO);
                response.Data = await _organismDomain.InsertOrganismRepresentedAsync(organismRepresented);

                if (response.Data > 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Organism Represented By Id's
        /// </summary>
        /// <param name="organismId"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<GetAllOrganismRepresentedDTO>>> GetOrganismRepresentedByIdAsync(string organismId)
        {
            var response = new Response<IEnumerable<GetAllOrganismRepresentedDTO>>();

            try
            {

                var organismById = await _organismDomain.GetOrganismRepresentedByIdAsync(organismId);
                response.Data = _mapper.Map<IEnumerable<GetAllOrganismRepresentedDTO>>(organismById);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{organismById}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Delete Organism represented
        /// </summary>
        /// <param name="organismRepresentedId"></param>
        /// <returns> True </returns>
        public async Task<Response<bool>> DeleteOrganismRepresentedAsync(string organismRepresentedId)
        {
            var response = new Response<bool>();

            try
            {

                response.Data = await _organismDomain.DeleteOrganismRepresentativeAsync(organismRepresentedId);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful delete";
                    _logger.LogInformation("A user was deleted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ DOCUMENT TYPE ]
        public async Task<Response<IEnumerable<DocumentTypeDTO>>> GetAllDocumentTypeAsync()
        {
            var response = new Response<IEnumerable<DocumentTypeDTO>>();

            try
            {

                var users = await _organismDomain.GetAllDocumentTypeAsync();
                response.Data = _mapper.Map<IEnumerable<DocumentTypeDTO>>(users);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("All document types were consulted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ COUNTRY METHODS ]
        public async Task<Response<IEnumerable<CountryDTO>>> GetAllCountryAsync()
        {
            var response = new Response<IEnumerable<CountryDTO>>();

            try
            {

                var country = await _organismDomain.GetAllCountryAsync();
                response.Data = _mapper.Map<IEnumerable<CountryDTO>>(country);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("All countries were consulted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        ///  Get Country By Region Id
        /// </summary>
        /// <returns>All Country By Region</returns>
        public async Task<Response<IEnumerable<CountryByRegionDTO>>> GetCountryByRegionIdAsync(string countryByRegionId)
        {
            var response = new Response<IEnumerable<CountryByRegionDTO>>();

            try
            {

                var country = await _organismDomain.GetCountryByRegionIdAsync(countryByRegionId);
                response.Data = _mapper.Map<IEnumerable<CountryByRegionDTO>>(country);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Countries were consulted by region!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
            }

            return response;
        }


        public async Task<Response<IEnumerable<PhoneCodeByCountryDTO>>> GetAllPhoneCodeByCountryIdAsync()
        {
            var response = new Response<IEnumerable<PhoneCodeByCountryDTO>>();

            try
            {

                var phoneCode = await _organismDomain.GetAllPhoneCodeByCountryIdAsync();
                response.Data = _mapper.Map<IEnumerable<PhoneCodeByCountryDTO>>(phoneCode);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("All phone codes were consulted!" + $"{phoneCode}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
            }

            return response;
        }
        #endregion


        #region [ REGION METHODS ]
        public async Task<Response<IEnumerable<RegionDTO>>> GetAllRegionAsync()
        {
            var response = new Response<IEnumerable<RegionDTO>>();

            try
            {

                var region = await _organismDomain.GetAllRegionAsync();
                response.Data = _mapper.Map<IEnumerable<RegionDTO>>(region);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("All regions were consulted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        public async Task<Response<RegionDTO>> GetRegionByIdAsync(string regionId)
        {
            var response = new Response<RegionDTO>();

            try
            {

                var region = await _organismDomain.GetRegionByIdAsync(regionId);
                response.Data = _mapper.Map<RegionDTO>(region);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Region was consulted by Id!" + $"{region.RegionName}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
            }

            return response;
        }
        #endregion


        #region [ AUTONOMOUS COMMUNITY ]
        public async Task<Response<IEnumerable<AutonomousCommunityDTO>>> GetAllAutonomousCommunityAsync()
        {
            var response = new Response<IEnumerable<AutonomousCommunityDTO>>();

            try
            {

                var getAllAutonomousCommunity = await _organismDomain.GetAllAutonomousCommunityAsync();
                response.Data = _mapper.Map<IEnumerable<AutonomousCommunityDTO>>(getAllAutonomousCommunity);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ PROVINCE SPAIN ]
        public async Task<Response<IEnumerable<ProvinceSpainDTO>>> GetAllProvinceSpainAsync()
        {
            var response = new Response<IEnumerable<ProvinceSpainDTO>>();

            try
            {

                var getAllProvinceSpain = await _organismDomain.GetAllProvinceSpainAsync();
                response.Data = _mapper.Map<IEnumerable<ProvinceSpainDTO>>(getAllProvinceSpain);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ CITY METHODS ]
        public async Task<Response<IEnumerable<CityDTO>>> GetAllCityAsync()
        {
            var response = new Response<IEnumerable<CityDTO>>();

            try
            {

                var city = await _organismDomain.GetAllCityAsync();
                response.Data = _mapper.Map<IEnumerable<CityDTO>>(city);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("All cities were consulted!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        public async Task<Response<CityDTO>> GetCityByIdAsync(string cityId)
        {
            var response = new Response<CityDTO>();

            try
            {

                var city = await _organismDomain.GetCityByIdAsync(cityId);
                response.Data = _mapper.Map<CityDTO>(city);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("City was consulted by Id!" + $"{city.CityName}");

                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
            }

            return response;
        }

        /// <summary>
        ///  Get City by Country Id
        /// </summary>
        /// <returns>All Country with regions</returns>
        public async Task<Response<IEnumerable<CityByRegionByCountryDTO>>> GetCityByRegionByCountryAsync(string countryId, string regionId)
        {
            var response = new Response<IEnumerable<CityByRegionByCountryDTO>>();

            try
            {

                var city = await _organismDomain.GetCityByRegionByCountryAsync(countryId, regionId);
                response.Data = _mapper.Map<IEnumerable<CityByRegionByCountryDTO>>(city);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("City by country Id was consulted!");

                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
            }

            return response;
        }
        #endregion


        #region [ AUTHENTICATE METHODS ]
        /// <summary>
        /// Authenticate user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Data user</returns>
        public Response<LoginDTO> Authenticate(LoginDTO loginDTO)
        {
            var response = new Response<LoginDTO>();

            if (string.IsNullOrEmpty(loginDTO.Email) || string.IsNullOrEmpty(loginDTO.Password))
            {
                response.Message = "Fields cannot be empty";

                return response;
            }

            try
            {
                var user = _organismDomain.Authenticate(loginDTO);

                response.Data = _mapper.Map<LoginDTO>(user);
                response.IsSuccess = true;
                response.Message = "Succesfull authentication";
                _logger.LogInformation("The user has logged in!" + $"{loginDTO.Email}");

            }
            catch (InvalidOperationException)
            {
                response.IsSuccess = true;
                response.Message = "User or password incorrect.";

            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ FORGET PASSWORD METHOD ]
        /// <summary>
        /// Validate if the user's email exists
        /// </summary>
        /// <param name="validateEmail"></param>
        /// <returns>Email user</returns>
        public Response<ValidateEmailUserDTO> ForgetPassword(ValidateEmailUserDTO validateEmail)
        {
            var response = new Response<ValidateEmailUserDTO>();

            if (string.IsNullOrEmpty(validateEmail.Email))
            {
                response.Message = "Field cannot be empty!";

                return response;
            }

            try
            {

                var email = _organismDomain.ForgetPassword(validateEmail);

                if (string.IsNullOrEmpty(validateEmail.Email))
                {
                    response.Message = "Field cannot be empty!";
                }

                response.Data = _mapper.Map<ValidateEmailUserDTO>(validateEmail);
                response.IsSuccess = true;
                response.Message = "The user has validated his email and an email has been sent!" + $"{validateEmail.Email}";
                _logger.LogInformation("Succesful query!");

            }
            catch (InvalidOperationException)
            {
                response.IsSuccess = true;
                response.Message = "Invalid email. Please create account!";
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;

        }



        public async Task<Response<ValidateEmailDTO>> GetEmailAsync(string validateEmail)
        {
            var response = new Response<ValidateEmailDTO>();

            try
            {

                var email = await _organismDomain.GetEmailAsync(validateEmail);
                response.Data = _mapper.Map<ValidateEmailDTO>(email);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Email Successful query";
                    _logger.LogInformation("The user has validated his email!" + $"{email}");

                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                response.Message = "Invalid email. Please create account!";
            }

            return response;
        }


        public Response<ValidateVerificationCodeDTO> ForgetPasswordVerificationCode(ValidateVerificationCodeDTO validateCodeVerification)
        {
            var response = new Response<ValidateVerificationCodeDTO>();

            if (string.IsNullOrEmpty(validateCodeVerification.CodeVerification))
            {
                response.Message = "Field cannot be empty!";

                return response;
            }

            try
            {

                var email = _organismDomain.ForgetPasswordVerificationCode(validateCodeVerification);

                if (string.IsNullOrEmpty(validateCodeVerification.CodeVerification))
                {
                    response.Message = "Field cannot be empty!";
                }

                response.Data = _mapper.Map<ValidateVerificationCodeDTO>(validateCodeVerification);
                response.IsSuccess = true;
                response.Message = "Valid code successfully";
                _logger.LogInformation("The user has validated the verification code!" + $"{validateCodeVerification.Email}");

            }
            catch (InvalidOperationException)
            {
                response.IsSuccess = true;
                response.Message = "Invalid Verification Code or Email incorrect. Please enter the correct code or Email correct!";
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;

        }


        public async Task<Response<bool>> UpdateUserPasswordAsync(ChangeUserPasswordDTO changeUserPasswordDTO)
        {
            var response = new Response<bool>();

            try
            {
                var changePassword = _mapper.Map<ChangeUserPassword>(changeUserPasswordDTO);
                response.Data = await _organismDomain.UpdateUserPasswordAsync(changePassword);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful update";
                    _logger.LogInformation("User has updated their password!" + $"{changePassword.Email}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion

        #endregion

    }
    #endregion

}
