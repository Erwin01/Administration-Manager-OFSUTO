﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Application.Main
{
    public class OrganismContactApplication : IOrganismContactApplication
    {
        private readonly IOrganismContactDomain _repository;
        private readonly IAppLogger<OrganismContactApplication> _logger;

        public OrganismContactApplication(IOrganismContactDomain repository, IAppLogger<OrganismContactApplication> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        public async Task<Response<OrganismContactDTO>> Add(OrganismContactDTO obj)
        {
            try
            {
                var mapp = AutoMapp<OrganismContactDTO, OrganismContact>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.OrganismId = add.OrganismId;
                return Response<OrganismContactDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OrganismContactDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.OrganismId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<OrganismContactDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = AutoMapp<OrganismContact, OrganismContactDTO>.ConvertList2(ListData);
                return Response<List<OrganismContactDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<OrganismContactDTO>>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<OrganismContactDTO>> GetById(int id)
        {
            Response<OrganismContactDTO> ListRta = new Response<OrganismContactDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = AutoMapp<OrganismContact, OrganismContactDTO>.Convert(ListData);
                return Response<OrganismContactDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<OrganismContactDTO>.Sucess(null, ex.Message, false);
            }
        }

        public Task<Response<List<OrganismContactDTO>>> GetByParam(Func<OrganismContactDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<Response<OrganismContactDTO>> GetByParamFirst(Func<OrganismContactDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<OrganismContactDTO>> Update(OrganismContactDTO obj, int id)
        {
            try
            {
                var mapp = AutoMapp<OrganismContactDTO, OrganismContact>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<OrganismContactDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OrganismContactDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
