﻿using MoreLinq;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Application.Main
{
    public class OrganismRepresentativeApplication : IOrganismRepresentativeApplication
    {

        private readonly IOrganismRepresentativeDomain _repository;
        private readonly IAppLogger<OrganismRepresentativeApplication> _logger;

        public OrganismRepresentativeApplication(IOrganismRepresentativeDomain repository, IAppLogger<OrganismRepresentativeApplication> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        public async Task<Response<OrganismRepresentativeDTO>> Add(OrganismRepresentativeDTO obj)
        {
            try
            {

                var mapp = AutoMapp<OrganismRepresentativeDTO, OrganismRepresentative>.Convert(obj);
                var add = await _repository.Add(mapp);
                obj.RepresentationId = add.RepresentationId;
                return Response<OrganismRepresentativeDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OrganismRepresentativeDTO>.Error(null, ex, ex.Message, false);
            }
        }

        public async Task<Response<List<OrganismRepresentativeDTO>>> AddListOrganismRepresentative(List<OrganismRepresentativeDTO> obj)
        {
            try
            {

                var objToSave = new List<OrganismRepresentativeDTO>();
                obj = obj.Distinct().ToList();
                foreach (var item in obj)
                {
                    var exist = await GetRepresentative(item);
                    if (exist.Data != null)
                    {
                        if (exist.Data.Count == 0)
                        {
                            objToSave.Add(item);
                        }

                    }
                }
                var mapp = AutoMapp<OrganismRepresentativeDTO, OrganismRepresentative>.ConvertList2(objToSave);
                var organismList = await _repository.AddListOrganismRepresentative(mapp);
                return Response<List<OrganismRepresentativeDTO>>.Sucess(obj, "Success", true);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<List<OrganismRepresentativeDTO>>.Error(null, ex, ex.Message, false);
            }
        }


        public async Task<Response<bool>> Delete(int id)
        {
            try
            {
                var add = await _repository.GetById(id);
                if (add.RepresentationId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Error(false, ex, ex.Message, false);
            }
        }

        public async Task<Response<List<OrganismRepresentativeDTO>>> GetAll()
        {

            try
            {
                var ListData = await _repository.GetAll();
                var mapp = AutoMapp<OrganismRepresentative, OrganismRepresentativeDTO>.ConvertList2(ListData);
                return Response<List<OrganismRepresentativeDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<OrganismRepresentativeDTO>>.Error(null, ex, ex.Message, false);
            }

        }

        public async Task<Response<OrganismRepresentativeDTO>> GetById(int id)
        {
            try
            {
                var ListData = await _repository.GetById(id);
                var data = AutoMapp<OrganismRepresentative, OrganismRepresentativeDTO>.Convert(ListData);
                return Response<OrganismRepresentativeDTO>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<OrganismRepresentativeDTO>.Error(null, ex, ex.Message, false);
            }
        }

        public async Task<Response<List<OrganismRepresentativeDTO>>> GetRepresentative(OrganismRepresentativeDTO item)
        {
            try
            {
                var obj = await _repository.GetByParam(c => c.RepresentativeOrganismId == item.RepresentativeOrganismId && c.RepresentedOrganismId == item.RepresentedOrganismId);

                var data = AutoMapp<OrganismRepresentative, OrganismRepresentativeDTO>.ConvertList2(obj);
                return Response<List<OrganismRepresentativeDTO>>.Sucess(data, "Success", true);

            }
            catch (Exception ex)
            {

                return Response<List<OrganismRepresentativeDTO>>.Error(null, ex, ex.Message, false);
            }
        }

        public async Task<Response<List<GetOrganismToRepresentedDTO>>> GetOrganismToRepresented(int organismId)
        {
            try
            {
                var ListData = await _repository.GetOrganismToRepresented(organismId);
                var data = AutoMapp<GetOrganismToRepresented, GetOrganismToRepresentedDTO>.ConvertList2(ListData);
                return Response<List<GetOrganismToRepresentedDTO>>.Sucess(data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<GetOrganismToRepresentedDTO>>.Error(null, ex, ex.Message, false);
            }
        }

        public async Task<Response<OrganismRepresentativeDTO>> Update(OrganismRepresentativeDTO obj, int id)
        {
            try
            {
                var mapp = AutoMapp<OrganismRepresentativeDTO, OrganismRepresentative>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<OrganismRepresentativeDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OrganismRepresentativeDTO>.Error(null, ex, ex.Message, false);
            }
        }



    }
}
