﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Application.Interface
{
    public interface IOrganismEFApplication : IGenericApplication<OrganismDTO>
    {
        Task<Response<List<GetAllOrganismDTO>>> GetOrganismParam(ParamOrganismDTO paramsDto);
        Task<Response<List<OrganismDTO>>> ListOrganismCompany(int CountryId, int OrganismId);
    }
}
