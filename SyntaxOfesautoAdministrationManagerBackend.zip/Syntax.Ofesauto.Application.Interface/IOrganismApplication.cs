﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.Security.Application.DTO;
using Syntax.Ofesauto.Security.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Application.Interface
{



    #region [ IORGANISM APPLICATION ]
    public interface IOrganismApplication
    {


        #region [ ASYNCHRONOUS METHODS ]


        #region [ ORGANISM METHODS ]
        Task<Response<int>> InsertOrganismAsync(OrganismDTO organismDTO);
        Task<Response<IEnumerable<GetAllOrganismDTO>>> GetAllOrganismAsync();
        Task<Response<IEnumerable<GetAllOrganismDTO>>> GetAllOrganismsCompanyAsync();
        Task<Response<ViewOrganismDTO>> GetOrganismByIdAsync(string organismId);
        Task<Response<bool>> UpdateOrganismAsync(OrganismDTO organism);
        Task<Response<bool>> DeleteReasonLowByIdAsync(ReasonLowOrganismDTO reasonLowOrganismDTO);
        Task<Response<bool>> DeleteReasonLowPassToByIdAsync(ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO);
        Task<Response<IEnumerable<OrganismTypeDTO>>> GetAllOrganismTypeAsync();
        Task<Response<IEnumerable<OrganismSubTypeDTO>>> GetAllOrganismSubTypeAsync();
        Task<Response<IEnumerable<OrganismReasonLowDTO>>> GetAllOrganismReasonLowAsync();
        Task<Response<bool>> DeleteOrganismReasonLowPassToByIdAsync(DeleteOrganismReasonLowDTO deleteOrganismReasonLowDTO);

        #endregion


        #region [ ORGANISM CONTACT METHODS ]
        Task<Response<int>> InsertOrganismContactAsync(OrganismContactDTO organismContactDTO);
        Task<Response<bool>> UpdateOrganismContactAsync(OrganismContactDTO organismContactDTO);
        Task<Response<IEnumerable<GetAllOrganismContactDTO>>> GetAllOrganismContactAsync();
        Task<Response<GetOrganismContactDTO>> GetOrganismContactByIdAsync(string organismContactId);
        Task<Response<IEnumerable<GetOrganismContactDTO>>> GetAllOrganismContactByIdAsync(string organismContactId);
        Task<Response<IEnumerable<GetAllContactTypeDTO>>> GetAllOrganismContactTypeAsync();
        Task<Response<bool>> UpdateSelectPrincipalOrganismContactAsync(SelectPrincipalOrganismContactDTO selectPrincipalOrganismContactDTO);
        Task<Response<bool>> DeleteOrganismContactAsync(string organismContactId);
        #endregion


        #region [ ORGANISM BANK ACCOUNT METHODS ]
        Task<Response<int>> InsertOrganismBankAccountAsync(OrganismBankAccountDTO organismContactDTO);
        Task<Response<bool>> UpdateOrganismBankAccountAsync(OrganismBankAccountDTO organismBankAccountDTO);
        Task<Response<IEnumerable<GetAllBankAccountTypeDTO>>> GetAllOrganismBankAccountTypeAsync();
        Task<Response<IEnumerable<GetAllOrganismBankAccountDTO>>> GetAllOrganismBankAccountAsync();
        Task<Response<GetOrganismBankAccountDTO>> GetOrganismBankAccountByIdAsync(string organismBankAccountId);
        Task<Response<IEnumerable<GetOrganismBankAccountDTO>>> GetAllOrganismBankAccountByIdAsync(string organismBankAccountId);
        Task<Response<bool>> UpdateSelectPrincipalOrganismBankAccountAsync(SelectPrincipalOrganismBankAccountDTO selectPrincipalOrganismBankAccountDTO);
        Task<Response<bool>> DeleteOrganismBankAccountAsync(int organismBankAccountId);
        #endregion


        #region [ ORGANISM OFFICE METHODS ]
        Task<Response<int>> InsertOrganismOfficeAsync(OrganismOfficeDTO organismContactDTO);
        Task<Response<IEnumerable<GetAllOrganismOfficeDTO>>> GetAllOrganismOfficeAsync();
        Task<Response<bool>> UpdateOrganismOfficeGeneralDataAsync(OrganismOfficeDTO organismOfficeDTO);
        Task<Response<IEnumerable<GetOrganismOfficeDTO>>> GetOrganismOfficeByIdAsync(string officeId);
        Task<Response<IEnumerable<GetOrganismOfficeDTO>>> GetAllOrganismOfficeByIdAsync(string organismOfficeId);
        Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeAsync(SelectPrincipalOrganismOfficeDTO selectPrincipalOrganismOfficeDTO);
        Task<Response<int>> DeleteOrganismOfficeAsync(int organismOfficeId);
        #endregion


        #region [ ORGANISM OFFICE CONTACT METHODS ]
        Task<Response<int>> InsertOrganismOfficeContactAsync(OrganismOfficeContactDTO organismOfficeContactDTO);
        Task<Response<IEnumerable<GetAllOrganismOfficeContactsDTO>>> GetAllOrganismOfficeContactAsync();
        Task<Response<bool>> UpdateOrganismOfficeContactAsync(OrganismOfficeContactDTO organismOfficeContactDTO);
        Task<Response<IEnumerable<GetOrganismOfficeContactByIdDTO>>> GetOrganismOfficeContactByIdAsync(string contactId);
        Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeContactAsync(SelectPrincipalOrganismOfficeContactDTO selectPrincipalOrganismOfficeContactDTO);
        Task<Response<IEnumerable<GetOrganismOfficeContactByIdDTO>>> GetAllOrganismOfficeContactOfficeByIdAsync(string organismOfficeContactOfficeById);
        Task<Response<IEnumerable<GetAllOrganismOfficeContactDTO>>> GetAllOrganismOfficeContactByIdAsync(string organismOfficeContactId);
        Task<Response<bool>> DeleteOrganismOfficeContactAsync(string organismOfficeContactId);
        #endregion


        #region [ ORGANISM OFFICE BANK ACCOUNT METHODS ]
        Task<Response<int>> InsertOrganismOfficeBankAccountAsync(OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO);
        Task<Response<IEnumerable<GetAllOrganismOfficeBankAccountDTO>>> GetAllOrganismOfficeBankAccountAsync();
        Task<Response<GetOrganismOfficeBankAccountDTO>> GetOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById);
        Task<Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>> GetAllOrganismOfficeBankAccountByIdAsync(string organismOfficeBankAccountById);
        Task<Response<IEnumerable<GetOrganismOfficeBankAccountDTO>>> GetAllOrganismOfficeBankAccountOfficeByIdAsync(string organismOfficeBankAccountOfficeById);
        Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeBankAccount(SelectPrincipalOrganismOfficeBankAccountDTO selectPrincipalOrganismOfficeBankAccountDTO);
        Task<Response<bool>> UpdateOrganismOfficeBankAccountAsync(OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO);
        Task<Response<bool>> DeleteOrganismOfficeBankAccountAsync(int organismBankAccountId);

        #endregion


        #region [ ORGANISM OFFICE PROCESSOR METHODS ]
        Task<Response<int>> InsertOrganismOfficeProcessorAsync(OrganismOfficeProcessorDTO organismOfficeProcessorDTO);
        Task<Response<IEnumerable<GetAllOrganismOfficeProcessorDTO>>> GetAllOrganismOfficeProcessorAsync();
        Task<Response<GetOrganismOfficeProcessorDTO>> GetOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId);
        Task<Response<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>> GetAllOrganismOfficeProcessorByIdAsync(string organismOfficeProcessorId);
        Task<Response<IEnumerable<GetAllOrganismOfficeProcessorIdDTO>>> GetAllOrganismOfficeProcessorOfficeByIdAsync(string organismOfficeProcessorOfficeById);
        Task<Response<bool>> UpdateSelectPrincipalOrganismOfficeProcessorAsync(SelectPrincipalOrganismOfficeProcessorDTO selectPrincipalOrganismOfficeProcessorDTO);
        Task<Response<bool>> UpdateOrganismOfficeProcessorAsync(OrganismOfficeProcessorDTO organismOfficeProcessorDTO);
        Task<Response<bool>> DeleteOrganismOfficeProcessorAsync(string organismOfficeProcessorId);

        #endregion


        #region [ ORGANISM REPRESENTATIVE METHODS ]
        Task<Response<IEnumerable<GetAllOrganismRepresentativeDTO>>> GetOrganismRepresentativeByIdAsync(string organismRepresentativeId);
        Task<Response<int>> InsertOrganismRepresentativeAsync(OrganismRepresentativeDTO organismRepresentativeDTO);
        Task<Response<bool>> DeleteOrganismRepresentativeAsync(string organismRepresentativeId);
        Task<Response<bool>> UpdateOrganismRepresentativeAsync(OrganismRepresentativeDTO organismContactDTO);
        Task<Response<GetOrganismGeneralsDataDTO>> GetOrganismGeneralsDataByIdAsync(string organismId);

        #endregion


        #region [ ORGANISM REPRESENTED METHODS ]
        Task<Response<int>> InsertOrganismRepresentedAsync(OrganismRepresentedDTO organismRepresentedDTO);
        Task<Response<IEnumerable<GetAllOrganismRepresentedDTO>>> GetOrganismRepresentedByIdAsync(string organismRepresentativeId);
        Task<Response<bool>> DeleteOrganismRepresentedAsync(string organismRepresentedId);

        #endregion


        #region [ DOCUMENT TYPE ]
        Task<Response<IEnumerable<DocumentTypeDTO>>> GetAllDocumentTypeAsync();
        #endregion


        #region [ COUNTRY METHODS ]
        Task<Response<IEnumerable<CountryDTO>>> GetAllCountryAsync();
        Task<Response<IEnumerable<CountryByRegionDTO>>> GetCountryByRegionIdAsync(string countryByRegionId);
        Task<Response<IEnumerable<PhoneCodeByCountryDTO>>> GetAllPhoneCodeByCountryIdAsync();
        #endregion


        #region [ REGION METHODS ]
        Task<Response<IEnumerable<RegionDTO>>> GetAllRegionAsync();
        Task<Response<RegionDTO>> GetRegionByIdAsync(string regionId);
        #endregion


        #region [AUTONOMOUS COMMUNITY]
        Task<Response<IEnumerable<AutonomousCommunityDTO>>> GetAllAutonomousCommunityAsync();
        #endregion

        #region [ PROVINCE SPAIN]
        Task<Response<IEnumerable<ProvinceSpainDTO>>> GetAllProvinceSpainAsync();
        #endregion


        #region [ CITY METHODS ]
        Task<Response<IEnumerable<CityDTO>>> GetAllCityAsync();
        Task<Response<CityDTO>> GetCityByIdAsync(string cityId);
        Task<Response<IEnumerable<CityByRegionByCountryDTO>>> GetCityByRegionByCountryAsync(string countryId, string regionId);
        #endregion


        #region [ AUTHENTICATE METHODS ]
        Response<LoginDTO> Authenticate(LoginDTO loginDTO);
        #endregion


        #region [ FORGET PASSWORD METHODS ]
        Response<ValidateEmailUserDTO> ForgetPassword(ValidateEmailUserDTO validateUserEmailDTO);
        Task<Response<ValidateEmailDTO>> GetEmailAsync(string email);
        Response<ValidateVerificationCodeDTO> ForgetPasswordVerificationCode(ValidateVerificationCodeDTO validateCodeVerificationDTO);
        Task<Response<bool>> UpdateUserPasswordAsync(ChangeUserPasswordDTO changeUserPasswordDTO);
        #endregion

        #endregion

    }
    #endregion
}



