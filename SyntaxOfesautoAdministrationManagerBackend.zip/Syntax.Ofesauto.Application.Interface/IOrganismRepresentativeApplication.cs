﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Application.Interface
{
    public interface IOrganismRepresentativeApplication : IGenericApplication<OrganismRepresentativeDTO>
    {
        Task<Response<List<OrganismRepresentativeDTO>>> AddListOrganismRepresentative(List<OrganismRepresentativeDTO> organismRepresentativeDTOs);
        Task<Response<List<GetOrganismToRepresentedDTO>>> GetOrganismToRepresented(int organismId);
        Task<Response<List<OrganismRepresentativeDTO>>> GetRepresentative(OrganismRepresentativeDTO pre);
    }
}
