﻿using Syntax.Ofesauto.AdministrationManager.Application.DTO;

namespace Syntax.Ofesauto.AdministrationManager.Application.Interface
{
    public interface IOrganismContactApplication : IGenericApplication<OrganismContactDTO>
    {
    }
}
