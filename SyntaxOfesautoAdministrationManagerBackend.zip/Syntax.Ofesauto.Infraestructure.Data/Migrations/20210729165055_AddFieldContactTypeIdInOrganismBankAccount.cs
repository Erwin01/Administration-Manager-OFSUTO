﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data.Migrations
{
	public partial class AddFieldContactTypeIdInOrganismBankAccount : Migration
	{
		protected override void Up(MigrationBuilder migrationBuilder)
		{


			var sqlInsertOrganismBankAccount = @"ALTER PROCEDURE [dbo].[InsertOrganismBankAccount]
												(
													@OrganismId int,
													@BankAccountId int,
													@BankAccountTypeId tinyint,
													@BankAccountName nvarchar(50),
													@CountryId int,
													@BankAccountNumber nvarchar(15),
													@BankAccountSwift nvarchar(15),
													@CreateDate datetime,
													@UpdateDate datetime,
													@BankAccountPrincipal bit
												)
												AS
												BEGIN

													INSERT INTO [dbo].[OrganismBankAccount]
													(OrganismId,
													BankAccountTypeId,
													BankAccountName,
													CountryId,
													BankAccountNumber,
													BankAccountSwift,
													CreateDate,
													UpdateDate,
													BankAccountPrincipal
													)

													VALUES(@OrganismId, @BankAccountTypeId, @BankAccountName, @CountryId, @BankAccountNumber, @BankAccountSwift, @CreateDate, @UpdateDate, @BankAccountPrincipal)
												END";

			migrationBuilder.Sql(sqlInsertOrganismBankAccount);


			var sqlUpdateOrganismBankAccount = @"ALTER PROCEDURE [dbo].[UpdateOrganismBankAccount]
												(
													@OrganismId int,
													@BankAccountId int,
													@BankAccountTypeId tinyint,
													--@ContactTypeId int,
													@BankAccountName nvarchar(50),
													@CountryId int,
													@BankAccountNumber nvarchar(15),
													@BankAccountSwift nvarchar(15),
													--@CreateDate datetime,
													@UpdateDate datetime
													--@BankAccountPrincipal bit

												)
												AS
												BEGIN
													UPDATE [dbo].[OrganismBankAccount]
													SET	
													--OrganismId = @OrganismId,
													BankAccountTypeId = @BankAccountTypeId,
													--ContactTypeId = @ContactTypeId,
													BankAccountName = @BankAccountName,
													CountryId = @CountryId,
													BankAccountNumber = @BankAccountNumber,
													BankAccountSwift = @BankAccountSwift,
													--CreateDate = @CreateDate,
													UpdateDate = Getdate()
													--BankAccountPrincipal = @BankAccountPrincipal

													WHERE BankAccountId = @BankAccountId
												END";

			migrationBuilder.Sql(sqlUpdateOrganismBankAccount);

			


			var sqlGetOrganismBankAccountById = @"ALTER PROCEDURE [dbo].[GetOrganismBankAccountById]
												(
													@BankAccountId As int
												)
												AS
												BEGIN
													SELECT oba.BankAccountId,
														   oba.OrganismId,
														   bat.ContactTypeName BankAccountTypeName,
														   bat.ContactTypeDescription BankAccountTypeDescription,
														   oba.bankAccountName,
														   --ct.ContactTypeName,
														   oba.CountryId,
														   c.CountryName,
														   oba.BankAccountSwift,
														   oba.BankAccountNumber,
														   oba.BankAccountPrincipal
													FROM   OrganismBankAccount oba
														   left JOIN
														   ContactType bat ON oba.BankAccountTypeId = bat.ContactTypeId
														   left JOIN
														   Country c ON oba.CountryId = c.CountryId

													WHERE  oba.BankAccountId = @BankAccountId
												END";

			migrationBuilder.Sql(sqlGetOrganismBankAccountById);



			var sqlGetAllOrganismBankAccount = @"ALTER PROCEDURE [dbo].[GetAllOrganismBankAccount]
						AS
						BEGIN
							SELECT oba.BankAccountId,
								   oba.OrganismId,
								   bat.ContactTypeName BankAccountTypeName,
								   bat.ContactTypeDescription BankAccountTypeDescription,
								   oba.CountryId,
								   oba.BankAccountName,
								   c.CountryName,
								   oba.BankAccountSwift,
								   oba.BankAccountNumber,
								   oba.BankAccountPrincipal
							FROM   OrganismBankAccount oba
								   left JOIN ContactType bat ON oba.BankAccountTypeId = bat.ContactTypeId
								   INNER JOIN
								   Country c ON oba.CountryId = c.CountryId
						  ORDER BY BankAccountId DESC
						END";

			migrationBuilder.Sql(sqlGetAllOrganismBankAccount);


		}

		protected override void Down(MigrationBuilder migrationBuilder)
		{


			



		}
	}
}
