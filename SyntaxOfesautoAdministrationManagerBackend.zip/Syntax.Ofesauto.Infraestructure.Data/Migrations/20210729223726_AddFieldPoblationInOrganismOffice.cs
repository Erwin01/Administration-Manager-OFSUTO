﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data.Migrations
{
	public partial class AddFieldPoblationInOrganismOffice : Migration
	{
		protected override void Up(MigrationBuilder migrationBuilder)
		{

			migrationBuilder.AddColumn<string>(
						 name: "Population",
						 table: "OrganismOffice",
						 type: "nvarchar(150)",
						 nullable: false,
						 defaultValue: 0);


			var sqlInsertOrganismOffice = @"ALTER PROCEDURE [dbo].[InsertOrganismOffice]
											(
												@OrganismId int,
												@OfficeId int,
												@CountryId int,
												@RegionId int,
												@CityId int,
												@Population nvarchar(150),
												@OfficeAddress nvarchar(50),
												@OfficePostalCode nvarchar(15),
												@IsRepresentation bit,
												@OfficeHightDate datetime,
												@OfficeLowDate datetime,
												@CreateDate datetime,
												@UpdateDate datetime
											)
											AS
											BEGIN

												INSERT INTO [dbo].[OrganismOffice]
												(OrganismId,
												CountryId, 
												RegionId, 
												CityId,
												Population,
												OfficeAddress, 
												OfficePostalCode,
												IsRepresentation,
												OfficeHightDate,
												OfficeLowDate,
												CreateDate, 
												UpdateDate)

												VALUES(@OrganismId, @CountryId, @RegionId, @CityId, @Population, @OfficeAddress, @OfficePostalCode, @IsRepresentation, @OfficeHightDate, @OfficeLowDate, @CreateDate, @UpdateDate)
											END";

			migrationBuilder.Sql(sqlInsertOrganismOffice);


			var sqlUpdateOrganism = @"ALTER PROCEDURE [dbo].[UpdateOrganismOffice]
									(
										@OrganismId int,
										@OfficeId int,
										@CountryId int,
										@RegionId int,
										@CityId int,
										@Population nvarchar(150),
										@OfficeAddress nvarchar(50),
										@OfficePostalCode nvarchar(15),
										@IsRepresentation bit
										--@OfficeHightDate datetime,
										--@OfficeLowDate datetime,
										--@CreateDate datetime,
									)
									AS
									BEGIN
										UPDATE [dbo].[OrganismOffice]
										SET	
											OrganismId = @OrganismId,
											CountryId = @CountryId, 
											RegionId = @RegionId, 
											CityId = @CityId,
											Population = @Population,
											OfficeAddress = @OfficeAddress, 
											OfficePostalCode = @OfficePostalCode,
											IsRepresentation = @IsRepresentation,
											--OfficeHightDate = @OfficeHightDate,
											--OfficeLowDate = @OfficeLowDate,
											--CreateDate = @CreateDate, 
											UpdateDate = getdate()

										WHERE OfficeId = @OfficeId
									END";

			migrationBuilder.Sql(sqlUpdateOrganism);


			var sqlGetAllOrganismOffice = @"ALTER PROCEDURE [dbo].[GetAllOrganismOffice]
											AS
											BEGIN
												SELECT oo.OrganismId, 
														oo.OfficeId,
														oo.OfficeAddress,
														c.CountryName,
														r.RegionName,
														cn.CityName,
														oo.Population
												FROM   OrganismOffice oo
														INNER JOIN Country c ON oo.CountryId = c.CountryId 
														INNER JOIN Region r ON oo.RegionId = r.RegionId 
														INNER JOIN City cn ON oo.CityId = cn.CityId
												ORDER BY OfficeId DESC
											END";

			migrationBuilder.Sql(sqlGetAllOrganismOffice);


			var sqlGetAllOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetAllOrganismOfficeById]
											(
												@OrganismId AS int
											)
											AS
											BEGIN
												SELECT oo.OrganismId,
													   oo.OfficeId,
													   oo.OfficeHightDate,
													   c.CountryName,
													   r.RegionName,
													   ci.CityName,
													   oo.Population,
													   oo.OfficeAddress,
													   oo.OfficePostalCode,
													   orl.OrganismReasonLowName,
													   oo.OfficeLowDate,
													   oo.OfficePrincipal
												FROM   OrganismOffice oo
													   LEFT JOIN 
													   Country c ON oo.CountryId = c.CountryId
													   LEFT JOIN 
													   Region r ON oo.RegionId = r.RegionId
													   LEFT JOIN 
													   City ci ON oo.CityId = ci.CityId
													   LEFT JOIN 
													   OrganismReasonLow orl ON oo.OrganismReasonLowId = orl.OrganismReasonLowId
												WHERE  oo.OrganismId = @OrganismId
											  ORDER BY OfficeId DESC
											END";

			migrationBuilder.Sql(sqlGetAllOrganismOfficeById);


			var sqlGetOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetOrganismOfficeById]
											(
												@OfficeId As int
											)
											AS
											BEGIN
												SELECT o.OfficeId,
													   o.OrganismId,
													   o.OfficeHightDate,
													   c.CountryName,
													   r.RegionName,
													   ci.CityName,
													   o.Population,
													   o.OfficeAddress,
													   o.OfficePostalCode,
													   orl.OrganismReasonLowName,
													   o.OfficeLowDate,
													   o.CityId,
													   o.CountryId,
													   o.RegionId
												FROM   OrganismOffice o
													   left JOIN Country c ON o.CountryId = c.CountryId
													   left JOIN Region r ON o.RegionId = r.RegionId
													   left JOIN City ci ON o.CityId = ci.CityId
													   LEFT JOIN OrganismReasonLow orl ON o.OrganismReasonLowId = orl.OrganismReasonLowId
												WHERE  o.OfficeId = @OfficeId
											END";

			migrationBuilder.Sql(sqlGetOrganismOfficeById);

		}

		protected override void Down(MigrationBuilder migrationBuilder)
		{

			migrationBuilder.DropColumn(
				name: "Population",
				table: "OrganismOffice");



			var sqlInsertOrganismOffice = @"ALTER PROCEDURE [dbo].[InsertOrganismOffice]
											(
												@OrganismId int,
												@OfficeId int,
												@CountryId int,
												@RegionId int,
												@CityId int,
												@OfficeAddress nvarchar(50),
												@OfficePostalCode nvarchar(15),
												@IsRepresentation bit,
												@OfficeHightDate datetime,
												@OfficeLowDate datetime,
												@CreateDate datetime,
												@UpdateDate datetime
											)
											AS
											BEGIN

												INSERT INTO [dbo].[OrganismOffice]
												(OrganismId,
												CountryId, 
												RegionId, 
												CityId,
												OfficeAddress, 
												OfficePostalCode,
												IsRepresentation,
												OfficeHightDate,
												OfficeLowDate,
												CreateDate, 
												UpdateDate)

												VALUES(@OrganismId, @CountryId, @RegionId, @CityId, @OfficeAddress, @OfficePostalCode, @IsRepresentation, @OfficeHightDate, @OfficeLowDate, @CreateDate, @UpdateDate)
											END";

			migrationBuilder.Sql(sqlInsertOrganismOffice);


			var sqlUpdateOrganismOffice = @"ALTER PROCEDURE [dbo].[UpdateOrganismOffice]
											(
												@OrganismId int,
												@OfficeId int,
												@CountryId int,
												@RegionId int,
												@CityId int,
												@OfficeAddress nvarchar(50),
												@OfficePostalCode nvarchar(15),
												@IsRepresentation bit
												--@OfficeHightDate datetime,
												--@OfficeLowDate datetime,
												--@CreateDate datetime,
											)
											AS
											BEGIN
												UPDATE [dbo].[OrganismOffice]
												SET	
													OrganismId = @OrganismId,
													CountryId = @CountryId, 
													RegionId = @RegionId, 
													CityId = @CityId,
													OfficeAddress = @OfficeAddress, 
													OfficePostalCode = @OfficePostalCode,
													IsRepresentation = @IsRepresentation,
													--OfficeHightDate = @OfficeHightDate,
													--OfficeLowDate = @OfficeLowDate,
													--CreateDate = @CreateDate, 
													UpdateDate = getdate()

												WHERE OfficeId = @OfficeId
											END";

			migrationBuilder.Sql(sqlUpdateOrganismOffice);


			var sqlGetAllOrganismOffice = @"ALTER PROCEDURE [dbo].[GetAllOrganismOffice]
											AS
											BEGIN
												SELECT oo.OrganismId, 
														oo.OfficeId,
														oo.OfficeAddress,
														c.CountryName,
														r.RegionName,
														cn.CityName
												FROM   OrganismOffice oo
														INNER JOIN Country c ON oo.CountryId = c.CountryId 
														INNER JOIN Region r ON oo.RegionId = r.RegionId 
														INNER JOIN City cn ON oo.CityId = cn.CityId
												ORDER BY Of";

			migrationBuilder.Sql(sqlGetAllOrganismOffice);


			var sqlGetAllOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetAllOrganismOffice]
											AS
											BEGIN
												SELECT oo.OrganismId, 
														oo.OfficeId,
														oo.OfficeAddress,
														c.CountryName,
														r.RegionName,
														cn.CityName
												FROM   OrganismOffice oo
														INNER JOIN Country c ON oo.CountryId = c.CountryId 
														INNER JOIN Region r ON oo.RegionId = r.RegionId 
														INNER JOIN City cn ON oo.CityId = cn.CityId
												ORDER BY Of";

			migrationBuilder.Sql(sqlGetAllOrganismOfficeById);


			var sqlGetOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetOrganismOfficeById]
											(
												@OfficeId As int
											)
											AS
											BEGIN
												SELECT o.OfficeId,
													   o.OrganismId,
													   o.OfficeHightDate,
													   c.CountryName,
													   r.RegionName,
													   ci.CityName,
													   o.OfficeAddress,
													   o.OfficePostalCode,
													   orl.OrganismReasonLowName,
													   o.OfficeLowDate,
													   o.CityId,
													   o.CountryId,
													   o.RegionId
												FROM   OrganismOffice o
													   left JOIN Country c ON o.CountryId = c.CountryId
													   left JOIN Region r ON o.RegionId = r.RegionId
													   left JOIN City ci ON o.CityId = ci.CityId
													   LEFT JOIN OrganismReasonLow orl ON o.OrganismReasonLowId = orl.OrganismReasonLowId
												WHERE  o.OfficeId = @OfficeId
											END";

			migrationBuilder.Sql(sqlGetOrganismOfficeById);
		}
	}
}
