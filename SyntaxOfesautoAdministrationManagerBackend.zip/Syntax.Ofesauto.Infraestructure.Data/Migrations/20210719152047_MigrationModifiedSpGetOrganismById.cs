﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data.Migrations
{
    public partial class MigrationModifiedSpGetOrganismById : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var sql = @"ALTER PROCEDURE [dbo].[GetOrganismById]
						(
							@OrganismId AS int
						)
						AS
						BEGIN

							SELECT o.OrganismId,
								   o.OrganismHightDate,
								   ot.OrganismTypeName,
								   ost.OrganismSubTypeName,
								   o.OrganismCode,
								   OrganismName, 
								   OrganismLastName,
								   dt.DocumentTypeName,
								   o.OrganismCIF,
								   o.OrganismAddress,
								   o.OrganismPostalCode,
								   c.CountryName,
								   r.RegionName,
								   ci.CityName,
								   o.Poblation,
								   o.OrganismWebSite,
								   orl.OrganismReasonLowName,
								   o.OrganismLowDate,
								   o.CityId,
								   o.CountryId,
								   o.RegionId,
								   o.OrganismTypeId,
								   o.DocumentTypeId,
								   o.OrganismSubTypeId
							FROM   Organism o
								   INNER JOIN OrganismType ot ON o.OrganismTypeId = ot.OrganismTypeId
								   LEFT JOIN OrganismSubType ost ON o.OrganismSubTypeId = ost.OrganismSubTypeId
								   INNER JOIN DocumentType dt ON o.DocumentTypeId = dt.DocumentTypeId
								   INNER JOIN Country c ON o.CountryId = c.CountryId
								   LEFT JOIN Region r ON o.RegionId = r.RegionId
								   LEFT JOIN City ci ON o.CityId = ci.CityId
								   LEFT JOIN OrganismReasonLow orl ON o.OrganismReasonLowId = orl.OrganismReasonLowId
							WHERE OrganismId = @OrganismId
					END";

			migrationBuilder.Sql(sql);

		}

        protected override void Down(MigrationBuilder migrationBuilder)
        {
			var sql = @"ALTER PROCEDURE [dbo].[GetOrganismById]
						(
							@OrganismId AS int
						)
						AS
						BEGIN

							SELECT o.OrganismId,
								   o.OrganismHightDate,
								   ot.OrganismTypeName,
								   ost.OrganismSubTypeName,
								   o.OrganismCode,
								   OrganismName, 
								   OrganismLastName,
								   dt.DocumentTypeName,
								   o.OrganismCIF,
								   o.OrganismAddress,
								   o.OrganismPostalCode,
								   c.CountryName,
								   r.RegionName,
								   ci.CityName,
								   o.Poblation,
								   o.OrganismWebSite,
								   orl.OrganismReasonLowName,
								   o.OrganismLowDate,
								   o.CityId,
								   o.CountryId,
								   o.RegionId,
								   o.OrganismTypeId,
								   o.DocumentTypeId,
								   o.OrganismSubTypeId
							FROM   Organism o
								   INNER JOIN OrganismType ot ON o.OrganismTypeId = ot.OrganismTypeId
								   LEFT JOIN OrganismSubType ost ON o.OrganismSubTypeId = ost.OrganismSubTypeId
								   INNER JOIN DocumentType dt ON o.DocumentTypeId = dt.DocumentTypeId
								   INNER JOIN Country c ON o.CountryId = c.CountryId
								   INNER JOIN Region r ON o.RegionId = r.RegionId
								   INNER JOIN City ci ON o.CityId = ci.CityId
								   LEFT JOIN OrganismReasonLow orl ON o.OrganismReasonLowId = orl.OrganismReasonLowId
							WHERE OrganismId = @OrganismId
					END";

			migrationBuilder.Sql(sql);
		}
    }
}
