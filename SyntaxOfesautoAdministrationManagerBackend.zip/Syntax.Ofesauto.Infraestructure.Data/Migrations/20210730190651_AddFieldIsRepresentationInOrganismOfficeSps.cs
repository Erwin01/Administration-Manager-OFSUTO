﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data.Migrations
{
	public partial class AddFieldIsRepresentationInOrganismOfficeSps : Migration
	{
		protected override void Up(MigrationBuilder migrationBuilder)
		{


			var sqlGetAllOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetAllOrganismOfficeById]
											(
												@OrganismId AS int
											)
											AS
											BEGIN
												SELECT oo.OrganismId,
													   oo.OfficeId,
													   oo.OfficeHightDate,
													   c.CountryName,
													   r.RegionName,
													   ci.CityName,
													   oo.Population,
													   oo.OfficeAddress,
													   oo.OfficePostalCode,
													   orl.OrganismReasonLowName,
													   oo.OfficeLowDate,
													   oo.OfficePrincipal,
													   oo.IsRepresentation
												FROM   OrganismOffice oo
													   LEFT JOIN 
													   Country c ON oo.CountryId = c.CountryId
													   LEFT JOIN 
													   Region r ON oo.RegionId = r.RegionId
													   LEFT JOIN 
													   City ci ON oo.CityId = ci.CityId
													   LEFT JOIN 
													   OrganismReasonLow orl ON oo.OrganismReasonLowId = orl.OrganismReasonLowId
												WHERE  oo.OrganismId = @OrganismId
											  ORDER BY OfficeId DESC
											END";

			migrationBuilder.Sql(sqlGetAllOrganismOfficeById);



			var sqlGetOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetOrganismOfficeById]
											(
												@OfficeId As int
											)
											AS
											BEGIN
												SELECT o.OfficeId,
													   o.OrganismId,
													   o.OfficeHightDate,
													   c.CountryName,
													   r.RegionName,
													   ci.CityName,
													   o.Population,
													   o.OfficeAddress,
													   o.OfficePostalCode,
													   orl.OrganismReasonLowName,
													   o.OfficeLowDate,
													   o.CityId,
													   o.CountryId,
													   o.RegionId,
													   o.IsRepresentation
												FROM   OrganismOffice o
													   left JOIN Country c ON o.CountryId = c.CountryId
													   left JOIN Region r ON o.RegionId = r.RegionId
													   left JOIN City ci ON o.CityId = ci.CityId
													   LEFT JOIN OrganismReasonLow orl ON o.OrganismReasonLowId = orl.OrganismReasonLowId
												WHERE  o.OfficeId = @OfficeId
											END";

			migrationBuilder.Sql(sqlGetOrganismOfficeById);


			var sqlGetAllOrganismOffice = @"ALTER PROCEDURE [dbo].[GetAllOrganismOffice]
											AS
											BEGIN
												SELECT oo.OrganismId, 
														oo.OfficeId,
														oo.OfficeAddress,
														c.CountryName,
														r.RegionName,
														cn.CityName,
														oo.Population,
														oo.IsRepresentation
												FROM   OrganismOffice oo
														INNER JOIN Country c ON oo.CountryId = c.CountryId 
														INNER JOIN Region r ON oo.RegionId = r.RegionId 
														INNER JOIN City cn ON oo.CityId = cn.CityId
												ORDER BY OfficeId DESC
											END";

			migrationBuilder.Sql(sqlGetAllOrganismOffice);


		}

		protected override void Down(MigrationBuilder migrationBuilder)
		{

			var sqlGetAllOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetAllOrganismOfficeById]
											(
												@OrganismId AS int
											)
											AS
											BEGIN
												SELECT oo.OrganismId,
													   oo.OfficeId,
													   oo.OfficeHightDate,
													   c.CountryName,
													   r.RegionName,
													   ci.CityName,
													   oo.Population,
													   oo.OfficeAddress,
													   oo.OfficePostalCode,
													   orl.OrganismReasonLowName,
													   oo.OfficeLowDate,
													   oo.OfficePrincipal
												FROM   OrganismOffice oo
													   LEFT JOIN 
													   Country c ON oo.CountryId = c.CountryId
													   LEFT JOIN 
													   Region r ON oo.RegionId = r.RegionId
													   LEFT JOIN 
													   City ci ON oo.CityId = ci.CityId
													   LEFT JOIN 
													   OrganismReasonLow orl ON oo.OrganismReasonLowId = orl.OrganismReasonLowId
												WHERE  oo.OrganismId = @OrganismId
											  ORDER BY OfficeId DESC
											END";

			migrationBuilder.Sql(sqlGetAllOrganismOfficeById);


			var sqlGetOrganismOfficeById = @"ALTER PROCEDURE [dbo].[GetOrganismOfficeById]
											(
												@OfficeId As int
											)
											AS
											BEGIN
												SELECT o.OfficeId,
													   o.OrganismId,
													   o.OfficeHightDate,
													   c.CountryName,
													   r.RegionName,
													   ci.CityName,
													   o.Population,
													   o.OfficeAddress,
													   o.OfficePostalCode,
													   orl.OrganismReasonLowName,
													   o.OfficeLowDate,
													   o.CityId,
													   o.CountryId,
													   o.RegionId
												FROM   OrganismOffice o
													   left JOIN Country c ON o.CountryId = c.CountryId
													   left JOIN Region r ON o.RegionId = r.RegionId
													   left JOIN City ci ON o.CityId = ci.CityId
													   LEFT JOIN OrganismReasonLow orl ON o.OrganismReasonLowId = orl.OrganismReasonLowId
												WHERE  o.OfficeId = @OfficeId
											END";

			migrationBuilder.Sql(sqlGetOrganismOfficeById);



			var sqlGetAllOrganismOffice = @"ALTER PROCEDURE [dbo].[GetAllOrganismOffice]
											AS
											BEGIN
												SELECT oo.OrganismId, 
														oo.OfficeId,
														oo.OfficeAddress,
														c.CountryName,
														r.RegionName,
														cn.CityName,
														oo.Population
												FROM   OrganismOffice oo
														INNER JOIN Country c ON oo.CountryId = c.CountryId 
														INNER JOIN Region r ON oo.RegionId = r.RegionId 
														INNER JOIN City cn ON oo.CityId = cn.CityId
												ORDER BY OfficeId DESC
											END";

			migrationBuilder.Sql(sqlGetAllOrganismOffice);

		}
	}
}
