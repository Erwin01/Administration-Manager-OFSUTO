﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data.Migrations
{
    public partial class alterspGetOrganismParam : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
			var sql = @"ALTER PROCEDURE [dbo].[GetOrganismParam]
	                    -- Add the parameters for the stored procedure here
	                    @Countries nvarchar(100),
	                    @OrgaismTypes nvarchar(50),
	                    @status nvarchar(5)
                    AS
                    BEGIN
	                    -- SET NOCOUNT ON added to prevent extra result sets from
	                    -- interfering with SELECT statements.
	                    SET NOCOUNT ON;

                        -- Insert statements for procedure here
	                    SELECT o.OrganismId, 
								o.OrganismCode,
	                           o.OrganismName, 
		                       o.OrganismLastName,
		                       o.DocumentType DocumentTypeName,
		                       c.CountryName,
		                       o.Poblation,
		                       ot.OrganismTypeName, 
		                       o.OrganismCIF,
		                       op.OfesautoStateName
	                    FROM   Organism o
		  
		                       INNER JOIN Country c ON o.CountryId = c.CountryId 
		                       INNER JOIN OrganismType ot ON o.OrganismTypeId = ot.OrganismTypeId 
		                       INNER JOIN  OfesautoProcesState op ON o.OfesautoStateId = op.OfesautoStateId
		                       where (c.CountryId in (SELECT Parse(value as int)  
							FROM STRING_SPLIT(@Countries, ',')) or @Countries ='0') 
							and (o.OrganismTypeId in (SELECT Parse(value as int)  
							FROM STRING_SPLIT(@OrgaismTypes, ',')) or @OrgaismTypes ='0') and (o.OfesautoStateId in (SELECT Parse(value as int)  
							FROM STRING_SPLIT(@status, ',')) or (@status ='0'))
                      ORDER BY OrganismId Desc
                    END";

			migrationBuilder.Sql(sql);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
          
        }
    }
}
