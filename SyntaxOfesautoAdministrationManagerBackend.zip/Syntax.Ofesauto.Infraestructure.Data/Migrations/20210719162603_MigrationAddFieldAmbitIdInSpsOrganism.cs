﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data.Migrations
{
	public partial class MigrationAddFieldAmbitIdInSpsOrganism : Migration
	{
		protected override void Up(MigrationBuilder migrationBuilder)
		{

			//var sqlInsertOrganism = @"ALTER PROCEDURE [dbo].[InsertOrganism]
			//						(
			//							@OrganismId int,
			//							@OrganismTypeId int,
			//							@CountryId int,
			//							@AmbitId int,
			//							@RegionId int,
			//							@CityId int,
			//							@Poblation nvarchar(50),
			//							@OrganismName nvarchar(50),
			//							@OrganismLastName nvarchar(50),
			//							@OrganismAddress nvarchar(50),
			//							@DocumentTypeId int,
			//							@OrganismPostalCode nvarchar(15),
			//							@OrganismCIF nvarchar(15),
			//							@OrganismWebSite nvarchar(15),
			//							@OrganismCode nvarchar(15),
			//							@OrganismReasonLowId tinyint,
			//							@OrganismLowDate datetime,
			//							--@OrganismIdPassTo nvarchar(15),
			//							@OrganismHightDate datetime,
			//							@OfesautoStateId tinyint,
			//							@OrganismSubTypeId tinyint,
			//							@CreateDate datetime,
			//							@UpdateDate datetime
			//						)
			//						AS
			//						BEGIN

			//							INSERT INTO [dbo].[Organism]
			//							(OrganismTypeId, 
			//							CountryId,
			//							AmbitId,
			//							RegionId, 
			//							CityId,
			//							Poblation,
			//							OrganismName, 
			//							OrganismLastName,
			//							DocumentTypeId,
			//							OrganismAddress, 
			//							OrganismPostalCode, 
			//							OrganismCIF, 
			//							OrganismWebSite, 
			//							OrganismCode,
			//							OrganismReasonLowId,
			//							OrganismLowDate, 
			//							--OrganismIdPassTo, 
			//							OrganismHightDate, 
			//							OrganismSubTypeId,
			//							OfesautoStateId,
			//							CreateDate, 
			//							UpdateDate)

			//							VALUES(@OrganismTypeId, @CountryId, @AmbitId, @RegionId, @CityId, @Poblation, @OrganismName, @OrganismLastName, @DocumentTypeId, @OrganismAddress, @OrganismPostalCode, @OrganismCIF, @OrganismWebSite, @OrganismCode, @OrganismReasonLowId, @OrganismLowDate, @OrganismHightDate, @OrganismSubTypeId, @OfesautoStateId, @CreateDate, @UpdateDate)
			//						END";

			//migrationBuilder.Sql(sqlInsertOrganism);


			//var queryUpdateOrganism = @"ALTER PROCEDURE [dbo].[UpdateOrganism]
			//						 (
			//							@OrganismId int,
			//							@OrganismTypeId tinyint,
			//							@CountryId int,
			//							@AmbitId int,
			//							@RegionId int,
			//							@CityId int,
			//							@Poblation nvarchar(50),
			//							@OrganismName nvarchar(50),
			//							@OrganismLastName nvarchar(50),
			//							@OrganismAddress nvarchar(50),
			//							@DocumentTypeId int,
			//							@OrganismPostalCode nvarchar(15),
			//							@OrganismCIF nvarchar(15),
			//							@OrganismWebSite nvarchar(15),
			//							@OrganismCode nvarchar(15),
			//							@OrganismReasonLowId tinyint,
			//							@OrganismLowDate datetime,
			//							--@OrganismIdPassTo nvarchar(15),
			//							@OrganismHightDate datetime,
			//							@OrganismSubTypeId tinyint,
			//							--@CreateDate datetime,
			//							@UpdateDate datetime
			//						 )
			//						AS
			//						BEGIN
			//							UPDATE [dbo].[Organism]
			//							SET	
			//								OrganismTypeId = @OrganismTypeId,
			//								CountryId = @CountryId,
			//								AmbitId = @AmbitId,
			//								RegionId = @RegionId,
			//								CityId = @CityId,
			//								Poblation = @Poblation,
			//								OrganismName = @OrganismName,
			//								OrganismLastName = @OrganismLastName,
			//								OrganismAddress = @OrganismAddress,
			//								DocumentTypeId = @DocumentTypeId,
			//								OrganismPostalCode = @OrganismPostalCode,
			//								OrganismCIF = @OrganismCIF,
			//								OrganismWebSite = @OrganismWebSite,
			//								OrganismCode = @OrganismCode,
			//								OrganismReasonLowId = @OrganismReasonLowId,
			//								OrganismLowDate = @OrganismLowDate,
			//								--OrganismIdPassTo = @OrganismIdPassTo,
			//								OrganismHightDate = @OrganismHightDate,
			//								OrganismSubTypeId = @OrganismSubTypeId,
			//								--CreateDate = @CreateDate,
			//								UpdateDate = @UpdateDate

			//							WHERE OrganismId = @OrganismId
			//						END";

			//migrationBuilder.Sql(queryUpdateOrganism);



			//var sqlGetAllOrganism = @"ALTER PROCEDURE [dbo].[GetAllOrganisms]
			//						AS
			//						BEGIN
			//							SELECT  o.OrganismId, 
			//									o.OrganismName, 
			//									o.OrganismLastName,
			//									dt.DocumentTypeName,
			//									c.CountryName,
			//									o.AmbitId,
			//									o.Poblation,
			//									ot.OrganismTypeName, 
			//									o.OrganismCIF,
			//									op.OfesautoStateName
			//							FROM    Organism o
			//									INNER JOIN
			//									DocumentType dt ON o.DocumentTypeId = dt.DocumentTypeId
			//									INNER JOIN
			//									Country c ON o.CountryId = c.CountryId 
			//									INNER JOIN 
			//									OrganismType ot ON o.OrganismTypeId = ot.OrganismTypeId 
			//									INNER JOIN 
			//									OfesautoProcesState op ON o.OfesautoStateId = op.OfesautoStateId
			//						   ORDER BY OrganismId Desc
			//						END";

			//migrationBuilder.Sql(sqlGetAllOrganism);


			//var sqlGetOrganismById = @"ALTER PROCEDURE [dbo].[GetOrganismById]
			//						(
			//							@OrganismId AS int
			//						)
			//						AS
			//						BEGIN
			//							SELECT  o.OrganismId,
			//									o.OrganismHightDate,
			//									ot.OrganismTypeName,
			//									ost.OrganismSubTypeName,
			//									o.OrganismCode,
			//									OrganismName, 
			//									OrganismLastName,
			//									dt.DocumentTypeName,
			//									o.OrganismCIF,
			//									o.OrganismAddress,
			//									o.OrganismPostalCode,
			//									c.CountryName,
			//									c.CountryName,
			//									r.RegionName,
			//									ci.CityName,
			//									o.Poblation,
			//									o.OrganismWebSite,
			//									orl.OrganismReasonLowName,
			//									o.OrganismLowDate,
			//									o.CityId,
			//									o.CountryId,
			//									o.RegionId,
			//									o.OrganismTypeId,
			//									o.DocumentTypeId,
			//									o.OrganismSubTypeId
			//							FROM   Organism o
			//									INNER JOIN OrganismType ot ON o.OrganismTypeId = ot.OrganismTypeId
			//									LEFT JOIN OrganismSubType ost ON o.OrganismSubTypeId = ost.OrganismSubTypeId
			//									INNER JOIN DocumentType dt ON o.DocumentTypeId = dt.DocumentTypeId
			//									INNER JOIN Country c ON o.CountryId = c.CountryId
			//									LEFT JOIN Region r ON o.RegionId = r.RegionId
			//									LEFT JOIN City ci ON o.CityId = ci.CityId
			//									LEFT JOIN OrganismReasonLow orl ON o.OrganismReasonLowId = orl.OrganismReasonLowId
			//							WHERE  OrganismId = @OrganismId
			//						END";

			//migrationBuilder.Sql(sqlGetOrganismById);

		}

		protected override void Down(MigrationBuilder migrationBuilder)
		{

			//var sql = @"ALTER PROCEDURE [dbo].[GetAllOrganisms]
			//			AS
			//			BEGIN
			//				SELECT o.OrganismId, 
			//						o.OrganismName, 
			//						o.OrganismLastName,
			//						dt.DocumentTypeName,
			//						c.CountryName,
			//						o.Poblation,
			//						ot.OrganismTypeName, 
			//						o.OrganismCIF,
			//						op.OfesautoStateName
			//				FROM    Organism o
			//						INNER JOIN
			//						DocumentType dt ON o.DocumentTypeId = dt.DocumentTypeId
			//						INNER JOIN
			//						Country c ON o.CountryId = c.CountryId
			//						INNER JOIN
			//						OrganismType ot ON o.OrganismTypeId = ot.OrganismTypeId
			//						INNER JOIN
			//						OfesautoProcesState op ON o.OfesautoStateId = op.OfesautoStateId
			//				ORDER BY OrganismId Desc
			//			END";

			//migrationBuilder.Sql(sql);


			//var sqlUpdateOrganism = @"ALTER PROCEDURE [dbo].[UpdateOrganism]
			//						(
			//							@OrganismId int,
			//							@OrganismTypeId tinyint,
			//							@CountryId int,
			//							@RegionId int,
			//							@CityId int,
			//							@Poblation nvarchar(50),
			//							@OrganismName nvarchar(50),
			//							@OrganismLastName nvarchar(50),
			//							@OrganismAddress nvarchar(50),
			//							@DocumentTypeId int,
			//							@OrganismPostalCode nvarchar(15),
			//							@OrganismCIF nvarchar(15),
			//							@OrganismWebSite nvarchar(15),
			//							@OrganismCode nvarchar(15),
			//							@OrganismReasonLowId tinyint,
			//							@OrganismLowDate datetime,
			//							--@OrganismIdPassTo nvarchar(15),
			//							@OrganismHightDate datetime,
			//							@OrganismSubTypeId tinyint,
			//							--@CreateDate datetime,
			//							@UpdateDate datetime
			//						)
			//						AS
			//						BEGIN
			//							UPDATE [dbo].[Organism]
			//							SET	
			//								OrganismTypeId = @OrganismTypeId,
			//								CountryId = @CountryId,
			//								RegionId = @RegionId,
			//								CityId = @CityId,
			//								Poblation = @Poblation,
			//								OrganismName = @OrganismName,
			//								OrganismLastName = @OrganismLastName,
			//								OrganismAddress = @OrganismAddress,
			//								DocumentTypeId = @DocumentTypeId,
			//								OrganismPostalCode = @OrganismPostalCode,
			//								OrganismCIF = @OrganismCIF,
			//								OrganismWebSite = @OrganismWebSite,
			//								OrganismCode = @OrganismCode,
			//								OrganismReasonLowId = @OrganismReasonLowId,
			//								OrganismLowDate = @OrganismLowDate,
			//								--OrganismIdPassTo = @OrganismIdPassTo,
			//								OrganismHightDate = @OrganismHightDate,
			//								OrganismSubTypeId = @OrganismSubTypeId,
			//								--CreateDate = @CreateDate,
			//								UpdateDate = @UpdateDate

			//							WHERE OrganismId = @OrganismId
									
			//						END";

			//migrationBuilder.Sql(sqlUpdateOrganism);


			//var sqlGetAllOrganism = @"ALTER PROCEDURE [dbo].[GetAllOrganisms]
			//						AS
			//						BEGIN
			//							SELECT o.OrganismId, 
			//								   o.OrganismName, 
			//								   o.OrganismLastName,
			//								   dt.DocumentTypeName,
			//								   c.CountryName,
			//								   o.Poblation,
			//								   ot.OrganismTypeName, 
			//								   o.OrganismCIF,
			//								   op.OfesautoStateName
			//							FROM   Organism o
			//								   INNER JOIN
			//								   DocumentType dt ON o.DocumentTypeId = dt.DocumentTypeId
			//								   INNER JOIN
			//								   Country c ON o.CountryId = c.CountryId 
			//								   INNER JOIN 
			//								   OrganismType ot ON o.OrganismTypeId = ot.OrganismTypeId 
			//								   INNER JOIN 
			//								   OfesautoProcesState op ON o.OfesautoStateId = op.OfesautoStateId
			//						  ORDER BY OrganismId Desc";

			//migrationBuilder.Sql(sqlGetAllOrganism);


			//var sqlGetOrganismById = "";


		}
	}
}
