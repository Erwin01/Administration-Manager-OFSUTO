﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data.Migrations
{
	public partial class MigrationModifiedSpUpdateOrganismContact : Migration
	{
		protected override void Up(MigrationBuilder migrationBuilder)
		{
			
			
			var sqlUpdateOrganismContact = @"ALTER PROCEDURE [dbo].[UpdateOrganismContact]
											(
												@OrganismId int,
												@ContactId int,
												@ContactTypeId tinyint,
												@ContactName nvarchar(50),
												@ContactLastname nvarchar(50),
												@ContactPhone nvarchar(15),
												@ContactFax nvarchar(15),
												@ContactEmail nvarchar(50),
												--@ContactPrincipal bit,
												--@CreateDate datetime,
												@UpdateDate datetime
											)
											AS
											BEGIN
												UPDATE [dbo].[OrganismContact]
												SET	
												OrganismId = @OrganismId,
												ContactTypeId = @ContactTypeId,
												ContactName = @ContactName,
												ContactLastname = @ContactLastname,
												ContactPhone = @ContactPhone,
												ContactFax = @ContactFax,
												ContactEmail = @ContactEmail,
												--ContactPrincipal = @ContactPrincipal,
												--CreateDate = @CreateDate,
												UpdateDate = @UpdateDate

												WHERE ContactId = @ContactId
											END";

			migrationBuilder.Sql(sqlUpdateOrganismContact);


			var sqlUpdateOrganismOfficeContact = @"ALTER PROCEDURE [dbo].[UpdateOrganismOfficeContact]
												(
													@OrganismId int,
													@OfficeId tinyint,
													@ContactId tinyint,
													@ContactTypeId tinyint,
													@ContactName nvarchar(50),
													@ContactLastname nvarchar(50),
													@ContactPhone nvarchar(15),
													@ContactFax nvarchar(15),
													@ContactEmail nvarchar(50),
													--@OfficeContactPrincipal bit,
													--@CreateDate datetime,
													@UpdateDate datetime
												)
												AS
												BEGIN
													UPDATE [dbo].[OrganismOfficeContact]
													SET	
													OrganismId = @OrganismId,
													OfficeId = @OfficeId,
													--ContactId = @ContactId,
													ContactTypeId = @ContactTypeId,
													ContactName = @ContactName,
													ContactLastname = @ContactLastname,
													ContactPhone = @ContactPhone,
													ContactFax = @ContactFax,
													ContactEmail = @ContactEmail,
													--OfficeContactPrincipal = @OfficeContactPrincipal,
													--CreateDate = @CreateDate,
													UpdateDate = @UpdateDate

													WHERE ContactId = @ContactId
												END";

			migrationBuilder.Sql(sqlUpdateOrganismOfficeContact);


			var sqlGetOrganismOfficeContactById = @"ALTER PROCEDURE [dbo].[GetOrganismOfficeContactById]
													(
														@ContactId As int
													)
													AS
													BEGIN
														SELECT 
																ooc.ContactId,
																ooc.OrganismId,
																ooc.OfficeId,
																ooc.ContactName,
																ooc.ContactLastname,
																ct.ContactTypeName,
																ooc.ContactPhone,
																ooc.ContactFax,
																ooc.ContactEmail,
																ooc.OfficeContactPrincipal
														FROM    OrganismOfficeContact ooc
																INNER JOIN 
																ContactType ct ON ooc.ContactTypeId = ct.ContactTypeId
														WHERE   ooc.ContactId = @ContactId
													END";

			migrationBuilder.Sql(sqlGetOrganismOfficeContactById);

		}

		protected override void Down(MigrationBuilder migrationBuilder)
		{
			migrationBuilder.DropColumn(
				name: "OfesautoStateId",
				table: "Organism");


			var sqlUpdateOrganismContact = @"ALTER PROCEDURE [dbo].[UpdateOrganismContact]
											(
												@OrganismId int,
												@ContactId int,
												@ContactTypeId tinyint,
												@ContactName nvarchar(50),
												@ContactLastname nvarchar(50),
												@ContactPhone nvarchar(15),
												@ContactFax nvarchar(15),
												@ContactEmail nvarchar(50),
												@ContactPrincipal bit,
												@CreateDate datetime,
												@UpdateDate datetime
											)
											AS
											BEGIN
												UPDATE [dbo].[OrganismContact]
												SET	
												OrganismId = @OrganismId,
												ContactTypeId = @ContactTypeId,
												ContactName = @ContactName,
												ContactLastname = @ContactLastname,
												ContactPhone = @ContactPhone,
												ContactFax = @ContactFax,
												ContactEmail = @ContactEmail,
												ContactPrincipal = @ContactPrincipal,
												--CreateDate = @CreateDate,
												UpdateDate = @UpdateDate

												WHERE ContactId = @ContactId
											END";

			migrationBuilder.Sql(sqlUpdateOrganismContact);


			var sqlUpdateOrganismOfficeContact = @"ALTER PROCEDURE [dbo].[UpdateOrganismOfficeContact]
												(
													@OrganismId int,
													@OfficeId tinyint,
													@ContactId tinyint,
													@ContactTypeId tinyint,
													@ContactName nvarchar(50),
													@ContactLastname nvarchar(50),
													@ContactPhone nvarchar(15),
													@ContactFax nvarchar(15),
													@ContactEmail nvarchar(50),
													@OfficeContactPrincipal bit,
													--@CreateDate datetime,
													@UpdateDate datetime
												)
												AS
												BEGIN
													UPDATE [dbo].[OrganismOfficeContact]
													SET	
													OrganismId = @OrganismId,
													OfficeId = @OfficeId,
													--ContactId = @ContactId,
													ContactTypeId = @ContactTypeId,
													ContactName = @ContactName,
													ContactLastname = @ContactLastname,
													ContactPhone = @ContactPhone,
													ContactFax = @ContactFax,
													ContactEmail = @ContactEmail,
													OfficeContactPrincipal = @OfficeContactPrincipal,
													--CreateDate = @CreateDate,
													UpdateDate = @UpdateDate

													WHERE ContactId = @ContactId
												END";

			migrationBuilder.Sql(sqlUpdateOrganismOfficeContact);


			var sqlGetOrganismOfficeContactById = @"ALTER PROCEDURE [dbo].[GetOrganismOfficeContactById]
													(
														@ContactId As int
													)
													AS
													BEGIN
														SELECT 
																ooc.ContactId,
																ooc.OrganismId,
																ooc.OfficeId,
																ooc.ContactName,
																ooc.ContactLastname,
																ct.ContactTypeName,
																ooc.ContactPhone,
																ooc.ContactFax,
																ooc.ContactEmail
														FROM    OrganismOfficeContact ooc
																INNER JOIN 
																ContactType ct ON ooc.ContactTypeId = ct.ContactTypeId
														WHERE   ooc.ContactId = @ContactId
													END";

			migrationBuilder.Sql(sqlGetOrganismOfficeContactById);

		}
	}
}
