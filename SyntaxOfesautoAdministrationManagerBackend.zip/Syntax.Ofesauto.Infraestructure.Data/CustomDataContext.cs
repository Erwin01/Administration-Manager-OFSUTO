﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;

namespace Syntax.Ofesauto.AdministrationManager.Infraestructure.Data
{
    public class CustomDataContext : DbContext
    {
        public CustomDataContext(DbContextOptions options) : base(options)
        {
        }

       

        public DbSet<Organism> Organism { get; set; }

        public DbSet<OrganismRepresentative> OrganismRepresentation { get; set; }
        public DbSet<GetOrganismToRepresented> GetOrganismToRepresented { get; set; }
        public DbSet<GetAllOrganism> GetAllOrganism { get; set; }
    }
}
