﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region MyRegion
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OrganismSubTypeDTO
    {

        public int OrganismSubTypeId { get; set; }

        [Display(Name = "Organism SubType Name")]
        public string OrganismSubTypeName { get; set; }

        [Display(Name = "Organism SubType Description")]
        public string OrganismSubTypeDescription { get; set; }

    }
    #endregion
}
