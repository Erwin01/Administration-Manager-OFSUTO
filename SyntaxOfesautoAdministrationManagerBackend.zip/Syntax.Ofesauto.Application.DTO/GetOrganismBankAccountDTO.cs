﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ORGANISM BANK ACCOUNT BY ID DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetOrganismBankAccountDTO
    {

        public int BankAccountId { get; set; }

        public int OrganismId { get; set; }
        
        public string ContactTypeName { get; set; }
        
        public string BankAccountName { get; set; }
        
        public int BankAccountTypeId { get; set; }
        
        public string BankAccountTypeName { get; set; }

        public string BankAccountTypeDescription { get; set; }
        
        public string CountryName { get; set; }
        
        public int CountryId { get; set; }

        [Display(Name = "Bank Account Swift")]
        public string BankAccountSwift { get; set; }

        [Display(Name = "Bank Account Number")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Bank Account Principal")]
        public bool BankAccountPrincipal { get; set; }
    }
    #endregion
}
