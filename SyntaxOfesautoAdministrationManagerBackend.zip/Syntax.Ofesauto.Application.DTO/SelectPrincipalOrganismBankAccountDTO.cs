﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ SELECT PRINCIPAL ORGANISM BANK ACCOUNT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    /// 
    public class SelectPrincipalOrganismBankAccountDTO
    {

        public int BankAccountId { get; set; }

        public int OrganismId { get; set; }

        public bool BankAccountPrincipal { get; set; }

    }
    #endregion
}
