﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    public class OrganismReasonLowDTO
    {

        #region [ORGANISM REASON DTO ]
        /// <summary>
        /// Method that allows placing only the attributes that are going to be exposed
        /// </summary>
        ///  
        public int OrganismReasonLowId { get; set; }

        [Display(Name = "Organism Reason Low Name")]
        public string OrganismReasonLowName { get; set; }

        [Display(Name = "Organism Reason Low Description")]
        public string OrganismReasonLowDescription { get; set; }

    }
    #endregion

}
