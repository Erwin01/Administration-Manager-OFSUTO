﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ACTIONS HISTORY DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class ActionsHistoryDTO
    {

        public int ActionId { get; set; }
        public int DeclareVehicleAccidentId { get; set; }
        public int StateId { get; set; }
        public string Observations { get; set; }
        public int AttachmentId { get; set; }
        public int UserId { get; set; }
        public int ClaimProcessorId { get; set; }
        public DateTime ActionDate { get; set; }
        public int ActionTypeId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
    }
    #endregion

}
