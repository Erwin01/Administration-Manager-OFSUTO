﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ PROVINCE DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class ProvinceSpainDTO
    {

        public int ProvinceId { get; set; }

        [Display(Name = "Province Name")]
        public string ProvinceName { get; set; }

    }
    #endregion

}
