﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ORGANISM OFFICE PROCESSOR DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OrganismOfficeProcessorDTO
    {

        public int OrganismId { get; set; }
        public int OfficeId { get; set; }
        public int OfficeProcessorId { get; set; }
        public int ContactTypeId { get; set; }
        public string OfficeProcessorName { get; set; }
        public string OfficeProcessorLastName { get; set; }
        public string OfficeProcessorPhone { get; set; }
        public string OfficeProcessorFax { get; set; }
        public string OfficeProcessorEmail { get; set; }

    }
    #endregion
}