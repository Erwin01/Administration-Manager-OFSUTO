﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ VIEW ORGANISM DTO ]
    /// <summary>
    /// Method that allows placing the attributes of the entity
    /// </summary>
    public class ViewOrganismDTO
    {

        public int OrganismId { get; set; }
        public int CityId { get; set; }
        public int CountryId { get; set; }
        public int RegionId { get; set; }
        public string Poblation { get; set; }
        public int OrganismTypeId { get; set; }
        public int DocumentTypeId { get; set; }
        public int OrganismSubTypeId { get; set; }
        public string OrganismTypeName { get; set; }
        public string OrganismSubTypeName { get; set; }
        public string OrganismCode { get; set; }
        public string OrganismName { get; set; }
        public string OrganismLastName { get; set; }
        public string DocumentTypeName { get; set; }
        public string OrganismCIF { get; set; }
        public string OrganismAddress { get; set; }
        public string OrganismPostalCode { get; set; }
        public string CountryName { get; set; }
        public string RegionName { get; set; }
        public string CityName { get; set; }
        public string OrganismWebSite { get; set; }
        public string OrganismReasonLowName { get; set; }
        public string OrganismLowDate { get; set; }
        public string AmbitName { get; set; }


    }
    #endregion
}
