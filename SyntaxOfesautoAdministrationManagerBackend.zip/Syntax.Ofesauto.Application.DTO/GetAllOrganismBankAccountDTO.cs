﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ GET ALL ORGANISM BANK ACCOUNT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetAllOrganismBankAccountDTO
    {


        public int BankAccountId { get; set; }

        public int OrganismId { get; set; }

        [Display(Name = "Contact Type Name")]
        public string ContactTypeName { get; set; }

        [Display(Name = "Bank Account Type Name")]
        public string BankAccountTypeName { get; set; }

        [Display(Name = "Bank Account Type Description")]
        public string BankAccountTypeDescription { get; set; }

        [Display(Name = "Bank Account Name")]
        public string BankAccountName { get; set; }

        [Display(Name = "Country Name")]
        public string CountryName { get; set; }

        public int CountryId { get; set; }

        [Display(Name = "Bank Account Swift")]
        public string BankAccountSwift { get; set; }

        [Display(Name = "Bank Account Number")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Bank Account Principal")]
        public bool BankAccountPrincipal { get; set; }

    }
    #endregion
}
