﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    #region [ GET ORGANISM GENERALS DATA DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>

    public class GetOrganismGeneralsDataDTO
    {

        public int OrganismId { get; set; }
        public string OrganismName { get; set; }
        public string OrganismLastName { get; set; }
        public string DocumentTypeName { get; set; }
        public string OrganismCIF { get; set; }
        public string CountryName { get; set; }
        public string RegionName { get; set; }
        public string CityName { get; set; }
        public string OrganismAddress { get; set; }
        public string OrganismPostalCode { get; set; }

    }
    #endregion
}
