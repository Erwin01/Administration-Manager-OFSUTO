﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    #region [ ORGANISM OFFICE CONTACT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class SelectPrincipalOrganismOfficeContactDTO
    {

        public int ContactId { get; set; }

        public int OfficeId { get; set; }

        public bool OfficeContactPrincipal { get; set; }

    }
    #endregion
}
