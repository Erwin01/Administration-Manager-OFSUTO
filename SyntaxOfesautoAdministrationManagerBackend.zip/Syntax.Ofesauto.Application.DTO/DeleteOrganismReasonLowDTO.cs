﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ DELETE ORGANISM REASON LOW DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class DeleteOrganismReasonLowDTO
    {

        public int OrganismId { get; set; }
        public int OrganismReasonLowId { get; set; }
        public int OrganismIdPassTo { get; set; }
        //public DateTime OrganismLowDate { get; set; }
        //public DateTime ContactLowDate { get; set; }
        //public DateTime BankAccountLowDate { get; set; }
        //public DateTime OfficeLowDate { get; set; }
        //public DateTime OfficeContactLowDate { get; set; }
        //public DateTime OfficeBankAccountLowDate { get; set; }
        //public DateTime OfficeProcessorLowDate { get; set; }

    }
    #endregion
}