﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{


    #region [ SELECT PRINCIPAL ORGANISM CONTACT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    /// 
    public class SelectPrincipalOrganismContactDTO
    {

        public int ContactId { get; set; }

        public int OrganismId { get; set; }

        public bool ContactPrincipal { get; set; }

    }
    #endregion

}

