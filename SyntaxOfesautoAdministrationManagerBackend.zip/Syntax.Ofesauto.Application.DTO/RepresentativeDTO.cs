﻿using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    public class RepresentativeDTO
    {

        public int RepresentationId { get; set; }

        public int RepresentativeOrganismId { get; set; }

        public int RepresentedOrganismId { get; set; }

        public List<OrganismRepresentative> OrganismRepresentative { get; set; }
    }
}
