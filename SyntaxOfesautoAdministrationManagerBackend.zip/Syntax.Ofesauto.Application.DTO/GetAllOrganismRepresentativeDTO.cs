﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ GET ALL ORGANISM REPRESENTATIVE DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetAllOrganismRepresentativeDTO
    {

        public int RepresentationId { get; set; }
        public int CountryId { get; set; }
        public string CountryName { get; set; }

        public string OrganismName { get; set; }

        public DateTime RepresentationStartDate { get; set; }

        public DateTime? RepresentationFinishDate { get; set; }

        public int OrganismId { get; set; }

        public bool IsRepresentation { get; set; }
    }
    #endregion
}
