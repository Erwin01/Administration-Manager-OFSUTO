﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ORGANISM REPRESENTED DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OrganismRepresentedDTO
    {

        //public int RepresentationId { get; set; }

        public int RepresentedOrganismId { get; set; }

        public int RepresentativeOrganismId { get; set; }

        //public DateTime RepresentationStartDate { get; set; }

        //public DateTime RepresentationFinishDate { get; set; }

    }
    #endregion
}
