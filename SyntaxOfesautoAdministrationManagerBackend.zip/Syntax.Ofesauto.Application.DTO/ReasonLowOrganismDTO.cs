﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ REASON LOW ORGANISM DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class ReasonLowOrganismDTO
    {

        public int OrganismId { get; set; }
        
        public int OrganisReasonLowId { get; set; }
        
        //public int OfesautoStateId { get; set; }


    }
    #endregion

}
