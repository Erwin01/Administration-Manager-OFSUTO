﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ORGANISM OFFICE BANK ACCOUNT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OrganismOfficeBankAccountDTO
    {

        public int OrganismId { get; set; }

        public int OfficeId { get; set; }

        public int BankAccountId { get; set; }

        public string CountryName { get; set; }

        [Display(Name = "Bank Account Name")]
        public string BankAccountName { get; set; }

        public int BankAccountTypeId { get; set; }

        public int CountryId { get; set; }

        [Display(Name = "Bank Account Number")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Bank Account Swift")]
        public string BankAccountSwift { get; set; }

        //public int? OrganismReasonLowId { get; set; }

        //public DateTime OfficeBankAccountLowDate { get; set; }

        //[Display(Name = "Office Bank Account Principal")]
        //public bool? OfficeBankAccountPrincipal { get; set; }

        //[Display(Name = "Created Date")]
        //[DataType(DataType.DateTime)]
        //[DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        //public DateTime CreateDate { get; set; }

        //[Display(Name = "Updated Date")]
        //[DataType(DataType.DateTime)]
        //[DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        //public DateTime UpdateteDate { get; set; }

    }
    #endregion
}
