﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    public class ParamOrganismDTO
    {
        public string Countries { get; set; } = "1";
        public string OrgaismTypes { get; set; } = "1";
        public string status { get; set; } = "1";
    }
}
