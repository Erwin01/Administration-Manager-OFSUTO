﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ GET ALL ORGANISM ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetAllOrganismDTO
    {

        public int OrganismId { get; set; }
        public string OrganismName { get; set; }
        public string OrganismLastName { get; set; }
        public string DocumentTypeName { get; set; }
        public string OrganismCode { get; set; }
        //public int CountryId { get; set; }
        public string CountryName { get; set; }
        //public string AmbitName { get; set; }
        public string Poblation { get; set; }
        public string OrganismTypeName { get; set; }
        public string OrganismCIF { get; set; }
        public string OfesautoStateName { get; set; }

    }
    #endregion

}
