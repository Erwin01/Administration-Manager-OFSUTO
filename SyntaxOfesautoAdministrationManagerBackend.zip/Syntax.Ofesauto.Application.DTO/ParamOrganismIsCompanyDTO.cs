﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    public class ParamOrganismIsCompanyDTO
    {
        [Required]
        public int CountryId { get; set; }
        [Required]
        public int OrganismId { get; set; }
    }
}
