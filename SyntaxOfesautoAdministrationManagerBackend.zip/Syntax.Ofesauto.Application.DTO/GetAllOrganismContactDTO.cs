﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{


    #region [ GET ALL ORGANISM CONTACT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetAllOrganismContactDTO
    {


        public int ContactId { get; set; }

        public int OrganismId { get; set; }

        [Display(Name = "Contact Name")]
        public string ContactName { get; set; }

        [Display(Name = "Contact LastName")]
        public string ContactLastName { get; set; }

        [Display(Name = "Contact Type Name")]
        public string ContactTypeName { get; set; }

        [Display(Name = "Contact Phone")]
        public string ContactPhone { get; set; }

        [Display(Name = "Contact Fax")]
        public string ContactFax { get; set; }

        [Display(Name = "Contact Email")]
        public string ContactEmail { get; set; }

        [Display(Name = "Contact Principal")]
        public bool ContactPrincipal { get; set; }
    }
    #endregion
}
