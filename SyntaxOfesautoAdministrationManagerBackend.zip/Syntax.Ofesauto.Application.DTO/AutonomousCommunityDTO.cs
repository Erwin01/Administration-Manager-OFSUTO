﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{


    #region [ AUTONOMOUS COMMUNITY DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class AutonomousCommunityDTO
    {

        public int AutonomousCommunityId { get; set; }

        [Display(Name = "Autonomous Community")]
        public string AutonomousCommunityName { get; set; }

    }
    #endregion

}
