﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ GET ALL ORGANISM BANK ACCOUNT TYPE DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetAllBankAccountTypeDTO
    {

        public int BankAccountTypeId { get; set; }

        [Display(Name = "Bank Account Type Name")]
        public string BankAccountTypeName { get; set; }

        [Display(Name = "Bank Account Type Description")]
        public string BankAccountTypeDescription { get; set; }
    }
    #endregion

}
