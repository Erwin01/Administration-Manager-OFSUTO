﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{


    #region [ GET ALL CONTACT TYPE DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetAllContactTypeDTO
    {


        public int ContactTypeId { get; set; }

        [Display(Name = "Contact Type Name")]
        public string ContactTypeName { get; set; }

        [Display(Name = "Contact Type Description")]
        public string ContactTypeDescription { get; set; }
    }
    #endregion
}
