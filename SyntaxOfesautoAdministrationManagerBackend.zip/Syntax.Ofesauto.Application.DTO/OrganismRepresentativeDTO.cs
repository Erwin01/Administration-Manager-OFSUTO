﻿using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using System;
using System.Collections.Generic;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

  
    public class OrganismRepresentativeDTO
    {

        public int RepresentationId { get; set; }

        public int RepresentativeOrganismId { get; set; }

        public int RepresentedOrganismId { get; set; }
        public DateTime RepresentationStartDate { get; set; } = DateTime.Now;
        public DateTime? RepresentationFinishDate { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime UpdateDate { get; set; } = DateTime.Now;
        
    }
    

}
