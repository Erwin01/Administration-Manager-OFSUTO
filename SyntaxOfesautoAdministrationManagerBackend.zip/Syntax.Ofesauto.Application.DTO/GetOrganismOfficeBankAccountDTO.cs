﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ GET ORGANISM OFFICE BANK ACCOUNT BY ID DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetOrganismOfficeBankAccountDTO
    {

        public int OrganismId { get; set; }

        public int OfficeId { get; set; }
        public int CountryId { get; set; }
        public int BankAccountTypeId { get; set; }
        public int BankAccountId { get; set; }

        [Display(Name = "Bank Account Name")]
        public string BankAccountName { get; set; }

        public string BankAccountTypeName { get; set; }

        public string CountryName { get; set; }

        [Display(Name = "Bank Account Swift")]
        public string BankAccountSwift { get; set; }

        [Display(Name = "Bank Account Number")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Organism Reason Low Name")]
        public string OrganismReasonLowName { get; set; }

        [Display(Name = "Office Bank Account Low Date")]
        public string OfficeBankAccountLowDate { get; set; }

        [Display(Name = "Office Bank Account Principal")]
        public bool OfficeBankAccountPrincipal { get; set; }
    }
    #endregion
}
