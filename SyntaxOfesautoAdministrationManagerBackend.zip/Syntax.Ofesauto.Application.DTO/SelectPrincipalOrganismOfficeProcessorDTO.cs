﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    #region [ SELECT PRINCIPAL ORGANISM OFFICE PROCESSOR DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class SelectPrincipalOrganismOfficeProcessorDTO
    {

        public int OfficeProcessorId { get; set; }

        public int OfficeId { get; set; }

        public bool OfficeProcessorPrincipal { get; set; }

    }
    #endregion
}
