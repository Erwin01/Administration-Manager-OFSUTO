﻿using System;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ORGANISM OFFICCE DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OrganismOfficeDTO
    {

        public int OrganismId { get; set; }
        public int OfficeId { get; set; }
        public int CountryId { get; set; }
        public int? RegionId { get; set; }
        public int? CityId { get; set; }
        public string Population { get; set; }
        public string OfficeAddress { get; set; }
        public string OfficePostalCode { get; set; }
        public DateTime OfficeHightDate { get; set; }
        //public DateTime OfficeLowDate { get; set; }
        //public DateTime CreateDate { get; set; }
        //public DateTime UpdateDate { get; set; }
        public bool IsRepresentation { get; set; }

    }
    #endregion
}
