﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ORGANISM BANK ACCOUNT DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OrganismBankAccountDTO
    {

        public int OrganismId { get; set; }

        public int BankAccountId { get; set; }

        public string BankAccountName { get; set; }

        public int BankAccountTypeId { get; set; }

        //public int ContactTypeId { get; set; }

        public int CountryId { get; set; }

        [Display(Name = "Bank Account Number")]
        public string BankAccountNumber { get; set; }

        [Display(Name = "Bank Account Swift")]
        public string BankAccountSwift { get; set; }

        //public byte? OrganismReasonLowId { get; set; }

    }
    #endregion
}
