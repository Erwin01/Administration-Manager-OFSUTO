﻿namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    public class ReasonLowOrganismPassToDTO
    {

        #region [ REASON LOW ORGANISM PASS TO DTO ]
        /// <summary>
        /// Method that allows placing only the attributes that are going to be exposed
        /// </summary>
        public int OrganismId { get; set; }
        public int OrganismIdPassTo { get; set; }

    }
    #endregion
}
