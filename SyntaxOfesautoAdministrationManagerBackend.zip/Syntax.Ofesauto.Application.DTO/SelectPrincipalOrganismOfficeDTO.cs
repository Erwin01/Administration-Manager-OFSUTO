﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    public class SelectPrincipalOrganismOfficeDTO
    {
        public int OfficeId { get; set; }

        [Display(Name = "Office Principal")]
        public bool OfficePrincipal { get; set; }
    }
}
