﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{

    #region [ ACTIONS HISTORY DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class GetAllOrganismOfficeDTO
    {

        public int OrganismId { get; set; }

        public int OfficeId { get; set; }
        public int CityId { get; set; }
        public int CountryId { get; set; }
        public int RegionId { get; set; }
        public string Population { get; set; }

        [Display(Name = "Office Address")]
        public string OfficeAddress { get; set; }

        [Display(Name = "Country Name")]
        public string CountryName { get; set; }

        [Display(Name = "Region Name")]
        public string RegionName { get; set; }

        [Display(Name = "City Name")]
        public string CityName { get; set; }

        [Display(Name = "Office Contact Principal")]
        public bool OfficeContactPrincipal { get; set; }
        public bool IsRepresentation { get; set; }


    }
    #endregion
}
