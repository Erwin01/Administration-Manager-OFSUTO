﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.AdministrationManager.Application.DTO
{
    public class OrganismTypeDTO
    {

        #region [ORGANISM TYPE DTO ]
        /// <summary>
        /// Method that allows placing only the attributes that are going to be exposed
        /// </summary>
        public int OrganismTypeId { get; set; }

        [Display(Name = "Organism Type Name")]
        public string OrganismTypeName { get; set; }
        public bool IsCompany { get; set; }
        public string OrganismTypeDescription { get; set; }


    }
    #endregion|
}
