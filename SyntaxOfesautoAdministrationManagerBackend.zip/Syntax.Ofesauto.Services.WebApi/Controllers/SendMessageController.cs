﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.Security.Services.WebApi.Email;

namespace Syntax.Ofesauto.Security.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/FileOrPhoto")]
    [ApiController]
    public class SendMessageController : ControllerBase
    {

        private readonly IEmailSender _emailSender;

        public SendMessageController(IEmailSender emailSender)
        {
            _emailSender = emailSender;
        }

    }
}
