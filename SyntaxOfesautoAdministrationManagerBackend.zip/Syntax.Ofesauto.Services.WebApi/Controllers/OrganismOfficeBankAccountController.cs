﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismOfficeBankAccountController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismOfficeBankAccountController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismOfficeBankAccount([FromBody] OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO)
        {
            if (organismOfficeBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismOfficeBankAccountAsync(organismOfficeBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismOfficeBankAccountAsync()
        {

            var response = await _organismApplication.GetAllOrganismOfficeBankAccountAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismOfficeBankAccountId}")]
        public async Task<IActionResult> GetOrganismOfficeBankAccountById(string organismOfficeBankAccountId)
        {

            if (string.IsNullOrEmpty(organismOfficeBankAccountId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismOfficeBankAccountByIdAsync(organismOfficeBankAccountId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Bank Account not exits!");
            }
        }


        [HttpGet("{organismOfficeBankAccountId}")]
        public async Task<IActionResult> GetAllOrganismOfficeBankAccountById(string organismOfficeBankAccountId)
        {

            if (string.IsNullOrEmpty(organismOfficeBankAccountId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeBankAccountByIdAsync(organismOfficeBankAccountId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Bank Account not exits!");
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismOfficeBankAccount([FromBody] SelectPrincipalOrganismOfficeBankAccountDTO selectPrincipalOrganismOfficeBankAccountDTO)
        {
            if (selectPrincipalOrganismOfficeBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismOfficeBankAccount(selectPrincipalOrganismOfficeBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateOrganismOfficeBankAccount([FromBody] OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO)
        {
            if (organismOfficeBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismOfficeBankAccountAsync(organismOfficeBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        //[HttpDelete("{OrganismOfficeContactId}")]
        //public async Task<IActionResult> DeleteOrganismOfficeContact(string OrganismOfficeContactId)
        //{
        //    if (string.IsNullOrEmpty(OrganismOfficeContactId))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteOrganismOfficeContactAsync(OrganismOfficeContactId);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest("Organism Contact has already been deleted!");
        //    }
        //}







        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowById([FromBody] ReasonLowOrganismDTO reasonLowOrganismDTO)
        //{
        //    if (reasonLowOrganismDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteReasonLowByIdAsync(reasonLowOrganismDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowPassToById([FromBody] ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        //{
        //    if (reasonLowOrganismPassToDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassToDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}

    }
}
