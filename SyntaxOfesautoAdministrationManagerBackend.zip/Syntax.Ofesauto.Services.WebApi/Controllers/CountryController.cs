﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Security.Services.WebApi.Controllers
{

    [Route("/AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class CountryController : Controller
    {

        private readonly IOrganismApplication _userApplication;

        #region [ CONSTRUCTOR ]
        public CountryController(IOrganismApplication userApplication)
        {
            _userApplication = userApplication;

        }
        #endregion


        [HttpGet]
        public async Task<IActionResult> GetAllCountryAsync()
        {

            var response = await _userApplication.GetAllCountryAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }



        [HttpGet]
        public async Task<IActionResult> GetAllPhoneCodeByCountryIdAsync()
        {

            var response = await _userApplication.GetAllPhoneCodeByCountryIdAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);

            }
        }
    }
}
