﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{

    [Route("/AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class DocumentTypeController : Controller
    {

        private readonly IOrganismApplication _userApplication;

        #region [ CONSTRUCTOR ]
        public DocumentTypeController(IOrganismApplication userApplication)
        {
            _userApplication = userApplication;

        }
        #endregion


        [HttpGet]
        public async Task<IActionResult> GetAllDocumentTypeAsync()
        {

            var response = await _userApplication.GetAllDocumentTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }

    }
}
