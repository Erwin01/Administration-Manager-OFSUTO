﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Services.WebApi.Helpers;
using Syntax.Ofesauto.Security.Transversal.Common;

namespace Syntax.Ofesauto.Security.Api.Controllers
{

    //[Authorize]
    [Route("/Security/[controller]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class LoginController : Controller
    {

        private readonly IConnectionFactory _connectionFactory;
        private readonly IOrganismApplication _userApplication;
        private readonly AppSettings _appSettings;
        private readonly IEmailSender _emailSender;

        public LoginController(IOrganismApplication userApplication, IEmailSender emailSender, IOptions<AppSettings> options, IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
            _userApplication = userApplication;
            _appSettings = options.Value;
            _emailSender = emailSender;
        }


        /// <summary>
        /// Authenticate User Registered
        /// </summary>
        /// <param name="authDTO"></param>
        /// <returns> Token </returns>
        //[HttpPost("Authenticate")]
        //public IActionResult Login([FromBody] LoginDTO authDTO)
        //{
        //    var response = _userApplication.Authenticate(authDTO);

        //    if (response.IsSuccess)
        //    {
        //        if (response.Data != null)
        //        {
        //            //Create token
        //            response.Data.Password = TokenCreation(response);

        //            return Ok(response);
        //        }
        //        else
        //        {
        //            return NotFound(response.Message);
        //        }
        //    }

        //    return BadRequest(response.Message);
        //}



        ///// <summary>
        ///// Validate Only Email
        ///// </summary>
        ///// <param name="validateEmail"></param>
        ///// <returns> Email User </returns>
        //[HttpGet("ValidateEmail")]
        //public async Task<IActionResult> GetEmailAsync(string email)
        //{
        //    if (string.IsNullOrEmpty(email))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }
        //    var response = await _userApplication.GetEmailAsync(email);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}





        //#region [ CREATE TOKEN ]
        ///// <summary>
        ///// Method Create Token Of Authentication
        ///// </summary>
        ///// <param name="loginDto"></param>
        ///// <returns> Token </returns>
        //private string TokenCreation(Response<LoginDTO> loginDto)
        //{
        //    var tokenHandler = new JwtSecurityTokenHandler();
        //    var key = Encoding.ASCII.GetBytes(_appSettings.ToString());
        //    int expiryToken = 15;

        //    var tokendescriptor = new SecurityTokenDescriptor
        //    {
        //        Subject = new ClaimsIdentity(new Claim[]
        //        {
        //            new Claim(ClaimTypes.NameIdentifier, loginDto.Data.Email.ToString())

        //        }),
        //        Expires = DateTime.UtcNow.AddMinutes(expiryToken),
        //        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
        //        Issuer = _appSettings.Issuer,
        //        Audience = _appSettings.Audience
        //    };

        //    var token = tokenHandler.CreateToken(tokendescriptor);
        //    var tokenString = tokenHandler.WriteToken(token);

        //    return tokenString;
        //}
        //#endregion

    }
}
