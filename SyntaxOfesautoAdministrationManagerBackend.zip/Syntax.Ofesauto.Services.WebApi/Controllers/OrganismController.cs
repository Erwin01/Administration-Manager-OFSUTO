﻿using Dapper;
using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Transversal.Common;

using System;
using System.Data;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IEmailSender _emailSender;
        public readonly string emailToClaiment = "eparales@syntax.es";
        public readonly string emailToProcessor = "testofesauto@gmail.com";
        private readonly IOrganismApplication _organism_Application;
        private readonly IOrganism_Application _organismApplication;
        private readonly IConnectionFactory _connectionFactory;


        #region [ CONSTRUCTOR ]
        public OrganismController(IOrganism_Application organismApplication, IOrganismApplication organismApplicationd, IEmailSender emailSender, IConnectionFactory connectionFactory)
        {
            _organismApplication = organismApplication;
            _emailSender = emailSender;
            _connectionFactory = connectionFactory;
            _organism_Application = organismApplicationd;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismAsync([FromBody] OrganismDTO organismDTO)
        {
            if (organismDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.Add(organismDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismAsync()
        {

            var response = await _organism_Application.GetAllOrganismAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpPut]
        public async Task<IActionResult> UpdateOrganismAsync([FromBody] OrganismDTO organismDTO)
        {
            if (organismDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.Update(organismDTO, organismDTO.OrganismId);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetOrganismByIdAsync(string organismId)
        {

            var response = await _organism_Application.GetOrganismByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism not exits!");
            }
        }

        //Delete
        [HttpPut]
        public async Task<IActionResult> DeleteReasonLow([FromBody] ReasonLowOrganismDTO reasonLowOrganismDTO)
        {
            if (reasonLowOrganismDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organism_Application.DeleteReasonLowByIdAsync(reasonLowOrganismDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        //PassTo
        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowPassTo([FromBody] ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        //{
        //    if (reasonLowOrganismPassToDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organism_Application.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassToDTO);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismTypeAsync()
        {

            var response = await _organism_Application.GetAllOrganismTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismSubTypeAsync()
        {

            var response = await _organism_Application.GetAllOrganismSubTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismReasonLowAsync()
        {

            var response = await _organism_Application.GetAllOrganismReasonLowAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }

        //Delete PassTo
        [HttpPut]
        public async Task<IActionResult> DeleteOrganismReasonLowPassToByIdAsync([FromBody] DeleteOrganismReasonLowDTO deleteOrganismReasonLowDTO)
        {
            if (deleteOrganismReasonLowDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organism_Application.DeleteOrganismReasonLowPassToByIdAsync(deleteOrganismReasonLowDTO);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
