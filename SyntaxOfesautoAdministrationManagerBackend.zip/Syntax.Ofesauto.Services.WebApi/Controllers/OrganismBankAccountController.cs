﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismBankAccountController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismBankAccountController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismBankAccount([FromBody] OrganismBankAccountDTO organismBankAccountDTO)
        {
            if (organismBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismBankAccountAsync(organismBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateOrganismBankAccount([FromBody] OrganismBankAccountDTO organismBankAccountDTO)
        {
            if (organismBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismBankAccountAsync(organismBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllBankAccountType()
        {

            var response = await _organismApplication.GetAllOrganismBankAccountTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismBankAccount()
        {

            var response = await _organismApplication.GetAllOrganismBankAccountAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("{organismBankAccountId}")]
        public async Task<IActionResult> GetOrganismBankAccountById(string organismBankAccountId)
        {

            if (string.IsNullOrEmpty(organismBankAccountId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismBankAccountByIdAsync(organismBankAccountId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism bank account not exits!");
            }
        }


        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetAllOrganismBankAccountById(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismBankAccountByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism bank account not exits!");
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismBankAccount([FromBody] SelectPrincipalOrganismBankAccountDTO selectPrincipalOrganismBankAccountDTO)
        {
            if (selectPrincipalOrganismBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismBankAccountAsync(selectPrincipalOrganismBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        //[HttpDelete("{organismBankAccountId}")]
        //public async Task<IActionResult> DeleteOrganismBankAccount(string organismBankAccountId)
        //{
        //    if (string.IsNullOrEmpty(organismBankAccountId))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteOrganismContactAsync(organismBankAccountId);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest("Organism bank account has already been deleted!");
        //    }
        //}

    }
}
