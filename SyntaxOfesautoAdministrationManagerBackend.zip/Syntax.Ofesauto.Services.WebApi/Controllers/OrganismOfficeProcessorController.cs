﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismOfficeProcessorController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismOfficeProcessorController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismOfficeProcessor([FromBody] OrganismOfficeProcessorDTO organismOfficeProcessorDTO)
        {
            if (organismOfficeProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismOfficeProcessorAsync(organismOfficeProcessorDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismOfficeProcessor()
        {

            var response = await _organismApplication.GetAllOrganismOfficeProcessorAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("{organismOfficeProcessorId}")]
        public async Task<IActionResult> GetOrganismOfficeProcessorById(string organismOfficeProcessorId)
        {

            if (string.IsNullOrEmpty(organismOfficeProcessorId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismOfficeProcessorByIdAsync(organismOfficeProcessorId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("User not exits!");
            }
        }


        [HttpGet("{organismOfficeProcessorId}")]
        public async Task<IActionResult> GetAllOrganismOfficeProcessorById(string organismOfficeProcessorId)
        {

            if (string.IsNullOrEmpty(organismOfficeProcessorId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeProcessorByIdAsync(organismOfficeProcessorId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("User not exits!");
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismOfficeProcessorAsync([FromBody] SelectPrincipalOrganismOfficeProcessorDTO selectPrincipalOrganismOfficeProcessorDTO)
        {
            if (selectPrincipalOrganismOfficeProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismOfficeProcessorAsync(selectPrincipalOrganismOfficeProcessorDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateOrganismOfficeProcessor([FromBody] OrganismOfficeProcessorDTO organismOfficeProcessorDTO)
        {
            if (organismOfficeProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismOfficeProcessorAsync(organismOfficeProcessorDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        //[HttpDelete("{OrganismOfficeId}")]
        //public async Task<IActionResult> DeleteOrganismOffice(string organismOfficeId)
        //{
        //    if (string.IsNullOrEmpty(organismOfficeId))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteOrganismOfficeAsync(organismOfficeId);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest("Organism Contact has already been deleted!");
        //    }
        //}




        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowById([FromBody] ReasonLowOrganismDTO reasonLowOrganismDTO)
        //{
        //    if (reasonLowOrganismDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteReasonLowByIdAsync(reasonLowOrganismDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowPassToById([FromBody] ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        //{
        //    if (reasonLowOrganismPassToDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassToDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismTypeAsync()
        //{

        //    var response = await _organismApplication.GetAllOrganismTypeAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismSubTypeAsync()
        //{

        //    var response = await _organismApplication.GetAllOrganismSubTypeAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismReasonLowAsync()
        //{

        //    var response = await _organismApplication.GetAllOrganismReasonLowAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}
    }
}
