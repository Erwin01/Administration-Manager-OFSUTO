﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismOfficeGeneralDataController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismOfficeGeneralDataController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismOfficeAsync([FromBody] OrganismOfficeDTO organismOfficeDTO)
        {
            if (organismOfficeDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismOfficeAsync(organismOfficeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismOfficeAsync()
        {

            var response = await _organismApplication.GetAllOrganismOfficeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateOrganismOfficeContact([FromBody] OrganismOfficeDTO organismOfficeDTO)
        {
            if (organismOfficeDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismOfficeContactAsync(organismOfficeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismOfficeId}")]
        public async Task<IActionResult> GetOrganismByIdAsync(string organismOfficeId)
        {

            if (string.IsNullOrEmpty(organismOfficeId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismOfficeByIdAsync(organismOfficeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office not exits!");
            }
        }

        [HttpGet("{organimsOfficeId}")]
        public async Task<IActionResult> GetAllOrganismByIdAsync(string organimsOfficeId)
        {

            if (string.IsNullOrEmpty(organimsOfficeId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeByIdAsync(organimsOfficeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office not exits!");
            }
        }

        [HttpDelete("{OrganismOfficeId}")]
        public async Task<IActionResult> DeleteOrganismOffice(string organismOfficeId)
        {
            if (string.IsNullOrEmpty(organismOfficeId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.DeleteOrganismOfficeAsync(organismOfficeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Contact has already been deleted!");
            }
        }


        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowById([FromBody] ReasonLowOrganismDTO reasonLowOrganismDTO)
        //{
        //    if (reasonLowOrganismDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteReasonLowByIdAsync(reasonLowOrganismDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowPassToById([FromBody] ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        //{
        //    if (reasonLowOrganismPassToDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassToDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismTypeAsync()
        //{

        //    var response = await _organismApplication.GetAllOrganismTypeAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismSubTypeAsync()
        //{

        //    var response = await _organismApplication.GetAllOrganismSubTypeAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismReasonLowAsync()
        //{

        //    var response = await _organismApplication.GetAllOrganismReasonLowAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}
    }
}
