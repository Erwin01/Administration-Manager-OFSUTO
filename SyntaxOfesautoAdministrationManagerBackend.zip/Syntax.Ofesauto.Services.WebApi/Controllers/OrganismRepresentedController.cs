﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismRepresentedController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;
        //private readonly IOrganism_Application _organismApplication;

        #region [ CONSTRUCTOR ]
        public OrganismRepresentedController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismRepresented([FromBody] OrganismRepresentedDTO organismRepresentedDTO)
        {
            if (organismRepresentedDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismRepresentedAsync(organismRepresentedDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetOrganismRepresented(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismRepresentedByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Representing not exits!");
            }
        }


        //[HttpDelete("{organismRepresentativeId}")]
        //public async Task<IActionResult> DeleteOrganismRepresentation(string organismRepresentativeId)
        //{
        //    if (string.IsNullOrEmpty(organismRepresentativeId))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteOrganismRepresentativeAsync(organismRepresentativeId);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest("Organism Contact has already been deleted!");
        //    }
        //}



        //[HttpPut]
        //public async Task<IActionResult> UpdateOrganismAsync([FromBody] OrganismRepresentativeDTO organismRepresentativeDTO)
        //{
        //    if (organismRepresentativeDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");
        //    }

        //    var response = await _organismApplication.UpdateOrganismRepresentativeAsync(organismRepresentativeDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}



        //[HttpGet("{organismId}")]
        //public async Task<IActionResult> GetOrganismGeneralsDataById(string organismId)
        //{

        //    if (string.IsNullOrEmpty(organismId))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.GetOrganismGeneralsDataByIdAsync(organismId);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest("Organism not exits!");
        //    }
        //}
    }
}
