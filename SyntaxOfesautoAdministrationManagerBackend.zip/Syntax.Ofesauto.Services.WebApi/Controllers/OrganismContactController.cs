﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismContactController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IEmailSender _emailSender;
        public readonly string emailToClaiment = "eparales@syntax.es";
        public readonly string emailToProcessor = "testofesauto@gmail.com";
        private readonly IOrganismApplication _organismApplication;
        private readonly IOrganismContactApplication _organismContactApplication;
        private readonly IConnectionFactory _connectionFactory;


        #region [ CONSTRUCTOR ]
        public OrganismContactController(IOrganismApplication organismApplication, IEmailSender emailSender, IConnectionFactory connectionFactory, IOrganismContactApplication organismContactApplication)
        {
            _organismApplication = organismApplication;
            _emailSender = emailSender;
            _connectionFactory = connectionFactory;
            _organismContactApplication = organismContactApplication;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismContact([FromBody] OrganismContactDTO organismContactDTO)
        {
            if (organismContactDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismContactApplication.Add(organismContactDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateOrganismContact([FromBody] OrganismContactDTO organismContact)
        {
            if (organismContact == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismContactAsync(organismContact);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismContact()
        {

            var response = await _organismApplication.GetAllOrganismContactAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("{organismContactId}")]
        public async Task<IActionResult> GetOrganismContactById(string organismContactId)
        {

            if (string.IsNullOrEmpty(organismContactId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismContactByIdAsync(organismContactId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism contact not exits!");
            }
        }

        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetAllOrganismContactById(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.GetAllOrganismContactByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism contact not exits!");
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismContactAsync([FromBody] SelectPrincipalOrganismContactDTO selectPrincipalOrganismContactDTO)
        {
            if (selectPrincipalOrganismContactDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismContactAsync(selectPrincipalOrganismContactDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        //[HttpDelete("{OrganismId}")]
        //public async Task<IActionResult> DeleteOrganismContact(string organismId)
        //{
        //    if (string.IsNullOrEmpty(organismId))
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismApplication.DeleteOrganismContactAsync(organismId);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest("Organism Contact has already been deleted!");
        //    }
        //}



        [HttpGet]
        public async Task<IActionResult> GetAllOrganismContactType()
        {

            var response = await _organismApplication.GetAllOrganismContactTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }
    }
}
