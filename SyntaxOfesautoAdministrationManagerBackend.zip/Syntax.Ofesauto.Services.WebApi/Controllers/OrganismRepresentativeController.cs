﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.WebApi.Controllers
{
    [Route("AdministrationManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismRepresentativeController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;
        //private readonly IOrganism_Application _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismRepresentativeController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismRepresentative([FromBody] OrganismRepresentativeDTO organismRepresentativeDTO)
        {
            if (organismRepresentativeDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismRepresentativeAsync(organismRepresentativeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetOrganismRepresentative(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismRepresentativeByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Representing not exits!");
            }
        }


        [HttpDelete("{representativeId}")]
        public async Task<IActionResult> DeleteOrganismRepresentation(string representativeId)
        {
            if (string.IsNullOrEmpty(representativeId))
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.DeleteOrganismRepresentativeAsync(representativeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Contact has already been deleted!");
            }
        }



        [HttpPut]
        public async Task<IActionResult> UpdateOrganismAsync([FromBody] OrganismRepresentativeDTO organismRepresentativeDTO)
        {
            if (organismRepresentativeDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.UpdateOrganismRepresentativeAsync(organismRepresentativeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetOrganismGeneralsDataById(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismGeneralsDataByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism not exits!");
            }
        }


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismRepresentative()
        //{

        //    var response = await _organism_Application.GetAllOrganismRepresentativeAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}



        //PassTo
        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowPassTo([FromBody] ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        //{
        //    if (reasonLowOrganismPassToDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organism_Application.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassToDTO);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismTypeAsync()
        //{

        //    var response = await _organism_Application.GetAllOrganismTypeAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismSubTypeAsync()
        //{

        //    var response = await _organism_Application.GetAllOrganismSubTypeAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        //[HttpGet]
        //public async Task<IActionResult> GetAllOrganismReasonLowAsync()
        //{

        //    var response = await _organism_Application.GetAllOrganismReasonLowAsync();

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }

        //}


        //[HttpPut]
        //public async Task<IActionResult> DeleteOrganismReasonLowPassToByIdAsync([FromBody] DeleteOrganismReasonLowDTO deleteOrganismReasonLowDTO)
        //{
        //    if (deleteOrganismReasonLowDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organism_Application.DeleteOrganismReasonLowPassToByIdAsync(deleteOrganismReasonLowDTO);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}
    }
}
