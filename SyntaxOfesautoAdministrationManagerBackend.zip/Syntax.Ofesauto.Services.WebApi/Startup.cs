using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Application.Main;
using Syntax.Ofesauto.AdministrationManager.Domain.Core;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Repository;
using Syntax.Ofesauto.AdministrationManager.Transversal.Logging;
using Syntax.Ofesauto.AdministrationManager.Transversal.Mapper;
using Syntax.Ofesauto.Security.Services.WebApi.Email;
using Syntax.Ofesauto.Security.Services.WebApi.Helpers;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.Services.WebApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            // Others services
            #region [ OTHERS SERVICES ]
            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            });
            services.AddControllers();
            services.AddApiVersioning();
            #endregion


            // Auto mapper configurations
            #region [ AUTO MAPPER ]
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            #endregion


            // Dependences injection
            #region [ DEPENDENCES INJECTION ]
            var appSettingsSection = Configuration.GetSection("Config");
            services.AddDbContext<CustomDataContext>(c => c.UseSqlServer(Configuration.GetConnectionString("Ofesauto")));
            services.AddTransient(typeof(IRepository<>), typeof(Repository<>));
            services.Configure<AppSettings>(appSettingsSection);
            services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IConnectionFactory, ConnectionFactory>();
            services.AddScoped<IOrganismApplication, OrganismApplication>();
            services.AddScoped<IOrganismDomain, OrganismDomain>();
            services.AddScoped<IOrganismContactApplication, OrganismContactApplication>();
            services.AddTransient<IOrganism_Domain, Organism_Domain>();
            services.AddTransient<IOrganism_Application, Organism_Application>();
            services.AddTransient<IOrganismContactDomain, OrganismContactDomain>();
            services.AddScoped<IOrganismRepository, OrganismRepository>();
            services.AddScoped(typeof(IAppLogger<>), typeof(LoggerAdapter<>));

            #endregion


            // Configuration service E-mail
            #region [ CONFIGURATION E-MAIL ]
            var emailConfig = Configuration.GetSection("EmailConfiguration").Get<EmailConfiguration>();
            services.AddSingleton(emailConfig);
            services.AddScoped<IEmailSender, EmailSender>();

            services.Configure<FormOptions>(o =>
            {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });
            #endregion


            // Api versioning
            #region [ API VERSIONING ]
            services.AddApiVersioning(version =>
            {
                version.AssumeDefaultVersionWhenUnspecified = true;
                version.DefaultApiVersion = new ApiVersion(1, 0);
            });
            #endregion


            //Register the Swagger generator, defining 1 or more Swagger documents
            #region [ SWAGGER DOCUMENTATION MANAGER ]
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Syntax Ofesauto Api - Administration Manager",
                    Version = "v1",
                    Description = "OFICINA ESPA�OLA DE ASEGURADORAS DE AUTOMOVIL",
                    TermsOfService = new Uri("https://www.ofesauto.es/"),
                    Contact = new OpenApiContact
                    {
                        Name = "Syntax Group",
                        Email = "info@syntax.es",
                        Url = new Uri("https://www.syntax.es/")
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Syntax Group",
                        Url = new Uri("https://www.syntax.es/soluciones/")
                    }

                });


                c.ResolveConflictingActions(a => a.First());
                c.OperationFilter<ApplyVersionsSwagger>();
                c.DocumentFilter<ReplaceVersionWithExactValueInPath>();


                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = ConfigurationPath.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlFile);

            });
            #endregion


            //Services of authentication using Jason Web Token
            #region [ AUTHENTICATION JWT ]
            var appsetings = appSettingsSection.Get<AppSettings>();

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            //Events in token
            .AddJwtBearer(x =>
            {
                x.Events = new JwtBearerEvents
                {
                    OnTokenValidated = context =>
                    {
                        var userId = int.Parse(context.Principal.Identity.Name);
                        return Task.CompletedTask;
                    },
                    //Exception in the moment of authentication
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                        {
                            context.Response.Headers.Add("Token-Expired", "true");

                        }

                        return Task.CompletedTask;
                    },
                };

                x.RequireHttpsMetadata = false;
                x.SaveToken = false;

                //Validation of token
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };
            });
            #endregion

        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                // Save log in file .txt
                #region [ LOGGER FILE ]
                loggerFactory.AddFile("Log-{Date}.Txt");
                #endregion

                

                // Cors
                #region [ CORS ]
                app.UseCors(options =>
                {

                    options.WithOrigins("http://localhost:3000");
                    options.AllowAnyMethod();
                    options.AllowAnyHeader();

                });
                #endregion

                app.UseAuthentication();

                app.UseRouting();

                app.UseAuthorization();

                app.UseEndpoints(endpoints =>
                {
                    endpoints.MapControllers();
                });
            }

            // Swagger endpoints
            #region [ SWAGGER ENDPOINTS ]
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Syntax Ofesauto Api - Administration Manager");

            });

            #endregion
        }
    }
}
