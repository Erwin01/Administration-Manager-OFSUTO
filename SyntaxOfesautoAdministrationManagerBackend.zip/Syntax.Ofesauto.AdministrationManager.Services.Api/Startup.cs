using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Application.Main;
using Syntax.Ofesauto.AdministrationManager.Domain.Core;
using Syntax.Ofesauto.AdministrationManager.Domain.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Data;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Interface;
using Syntax.Ofesauto.AdministrationManager.Infraestructure.Repository;
using Syntax.Ofesauto.AdministrationManager.Transversal.Logging;
using Syntax.Ofesauto.AdministrationManager.Transversal.Mapper;
using Syntax.Ofesauto.Security.Services.Api.Helpers;
using Syntax.Ofesauto.Security.Transversal.Common;
using System;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddCors();
            services.AddApiVersioning();

            // Dependences injection
            #region [ DEPENDENCES INJECTION ]
            var appSettingsSection = Configuration.GetSection("Config");
            services.AddDbContext<CustomDataContext>(c => c.UseSqlServer(Configuration.GetConnectionString("Ofesauto")));
            services.AddTransient(typeof(IRepository<>), typeof(Repository<>));
            services.Configure<AppSettings>(appSettingsSection);
            services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IConnectionFactory, ConnectionFactory>();
            services.AddScoped<IOrganismApplication, OrganismApplication>();
            services.AddScoped<IOrganismDomain, OrganismDomain>();
            services.AddScoped<IOrganismContactApplication, OrganismContactApplication>();
            services.AddTransient<IOrganismContactDomain, OrganismContactDomain>();
            services.AddScoped<IOrganismRepository, OrganismRepository>();
            services.AddTransient<IOrganismEFDomain, OrganismEFDomain>();
            services.AddScoped<IOrganismEFApplication, OrganismEFApplication>();

            services.AddScoped<IOrganismRepresentativeApplication, OrganismRepresentativeApplication>();
            services.AddScoped<IOrganismRepresentativeDomain, OrganismRepresentativeDomain>();

            services.AddScoped(typeof(IAppLogger<>), typeof(LoggerAdapter<>));
            #endregion

            // Auto mapper configurations
            #region [ AUTO MAPPER ]
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            #endregion

            // Api versioning
            #region [ API VERSIONING ]
            services.AddApiVersioning(version =>
            {
                version.AssumeDefaultVersionWhenUnspecified = true;
                version.DefaultApiVersion = new ApiVersion(1, 0);
            });
            #endregion

            //Register the Swagger generator, defining 1 or more Swagger documents
            #region [ SWAGGER DOCUMENTATION MANAGER ]
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Syntax Ofesauto Api - Administration Manager",
                    Version = "v1",
                    Description = "OFICINA ESPA�OLA DE ASEGURADORAS DE AUTOMOVIL",
                    TermsOfService = new Uri("https://www.ofesauto.es/"),
                    Contact = new OpenApiContact
                    {
                        Name = "Syntax Group",
                        Email = "info@syntax.es",
                        Url = new Uri("https://www.syntax.es/")
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Syntax Group",
                        Url = new Uri("https://www.syntax.es/soluciones/")
                    }

                });

            });
            #endregion

            services.AddControllers();
            //services.AddSwaggerGen(c =>
            //{
            //    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Syntax.Ofesauto.AdministrationManager.Services.Api", Version = "v1" });
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //app.UseSwagger();
                //app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Syntax.Ofesauto.AdministrationManager.Services.Api v1"));
            }

            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Syntax.Ofesauto.AdministrationManager.Services.Api v1"));

            // Save log in file .txt
            #region [ LOGGER FILE ]
            loggerFactory.AddFile("Logs/Log-{Date}.Txt");
            #endregion

            // Cors
            //#region [ CORS ]
            //app.UseCors(c => c.SetIsOriginAllowed(x => _ = true).AllowAnyMethod().AllowAnyHeader().AllowCredentials());

            #region [ CORS ]
            app.UseCors(options =>
            {

                options.WithOrigins("http://localhost:3000", "http://admin-manager.ofesauto.es");
                options.AllowAnyMethod();
                options.AllowAnyHeader();

            });
            #endregion


          
            app.UseHttpsRedirection();
            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
