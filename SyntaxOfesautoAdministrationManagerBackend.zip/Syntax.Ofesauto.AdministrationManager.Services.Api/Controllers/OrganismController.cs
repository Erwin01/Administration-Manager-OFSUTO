﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    //[ApiVersion("1")]
    //[ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;
        private readonly IOrganismRepresentativeApplication _organismRepresentedApplicationEF;
        private readonly IOrganismEFApplication _organismEFApplication;
        //private readonly IOrganism_Application _organism_Application;



        #region [ CONSTRUCTOR ]
        public OrganismController(IOrganismApplication organismApplicationd, IOrganismRepresentativeApplication organismRepresentedApplicationEF,
                                  IOrganismEFApplication organismEFApplication)
        {
            _organismApplication = organismApplicationd;
            _organismRepresentedApplicationEF = organismRepresentedApplicationEF;
            _organismEFApplication = organismEFApplication;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismAsync([FromBody] OrganismDTO organismDTO)
        {
            if (organismDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismEFApplication.Add(organismDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismAsync([FromQuery] ParamOrganismDTO paramsDto)
        {
            var response = await _organismEFApplication.GetOrganismParam(paramsDto);
            // var response = await _organismApplication.GetAllOrganismAsync();
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllOrganismCompany([FromQuery] ParamOrganismIsCompanyDTO param)
        {
            var response = await _organismEFApplication.ListOrganismCompany(param.CountryId,param.OrganismId);
            // var response = await _organismApplication.GetAllOrganismAsync();
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }

        }
        [HttpGet]
        public async Task<IActionResult> GetOrganismToRepresentedByIdOrganism(int OrganismId)
        {

            var response = await _organismRepresentedApplicationEF.GetOrganismToRepresented(OrganismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }

        }
        [HttpGet]
        public async Task<IActionResult> GetAllOrganismsCompanyAsync()
        {

            var response = await _organismApplication.GetAllOrganismsCompanyAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpPost]
        public async Task<IActionResult> UpdateOrganismAsync([FromBody] OrganismDTO organismDTO)
        {
            if (organismDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismEFApplication.Update(organismDTO,organismDTO.OrganismId);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetOrganismByIdAsync(int organismId)
        {

            var response = await _organismEFApplication.GetById(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism not exits!");
            }
        }

        //Delete
        [HttpPost]
        public async Task<IActionResult> DeleteReasonLow([FromBody] ReasonLowOrganismDTO reasonLowOrganismDTO)
        {
            if (reasonLowOrganismDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.DeleteReasonLowByIdAsync(reasonLowOrganismDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        //PassTo
        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowPassTo([FromBody] ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        //{
        //    if (reasonLowOrganismPassToDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organism_Application.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassToDTO);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismTypeAsync()
        {

            var response = await _organismApplication.GetAllOrganismTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismSubTypeAsync()
        {

            var response = await _organismApplication.GetAllOrganismSubTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismReasonLowAsync()
        {

            var response = await _organismApplication.GetAllOrganismReasonLowAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }

        //Delete PassTo
        [HttpPost]
        public async Task<IActionResult> DeleteOrganismReasonLowPassToByIdAsync([FromBody] DeleteOrganismReasonLowDTO deleteOrganismReasonLowDTO)
        {
            if (deleteOrganismReasonLowDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.DeleteOrganismReasonLowPassToByIdAsync(deleteOrganismReasonLowDTO);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
