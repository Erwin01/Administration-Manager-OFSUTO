﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class OrganismOfficeBankAccountController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismOfficeBankAccountController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismOfficeBankAccount([FromBody] OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO)
        {
            if (organismOfficeBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismOfficeBankAccountAsync(organismOfficeBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismOfficeBankAccountAsync()
        {

            var response = await _organismApplication.GetAllOrganismOfficeBankAccountAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{bankAccountId}")]
        public async Task<IActionResult> GetOrganismOfficeBankAccountById(string bankAccountId)
        {

            if (string.IsNullOrEmpty(bankAccountId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismOfficeBankAccountByIdAsync(bankAccountId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Bank Account not exits!");
            }
        }


        [HttpGet("{organismOfficeBankAccountId}")]
        public async Task<IActionResult> GetAllOrganismOfficeBankAccountById(string organismOfficeBankAccountId)
        {

            if (string.IsNullOrEmpty(organismOfficeBankAccountId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeBankAccountByIdAsync(organismOfficeBankAccountId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Bank Account not exits!");
            }
        }


        [HttpGet("{officeBankAccountOfficeById}")]
        public async Task<IActionResult> GetAllOrganismOfficeBankAccountOfficeByIdAsync(string officeBankAccountOfficeById)
        {

            if (string.IsNullOrEmpty(officeBankAccountOfficeById))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeBankAccountOfficeByIdAsync(officeBankAccountOfficeById);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Bank Account not exits!");
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismOfficeBankAccount([FromBody] SelectPrincipalOrganismOfficeBankAccountDTO selectPrincipalOrganismOfficeBankAccountDTO)
        {
            if (selectPrincipalOrganismOfficeBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismOfficeBankAccount(selectPrincipalOrganismOfficeBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateOrganismOfficeBankAccount([FromBody] OrganismOfficeBankAccountDTO organismOfficeBankAccountDTO)
        {
            if (organismOfficeBankAccountDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismOfficeBankAccountAsync(organismOfficeBankAccountDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> DeleteOrganismOfficeBankAccount(int OrganismOfficeBankAccountId)
        {
            if (OrganismOfficeBankAccountId==0)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.DeleteOrganismOfficeBankAccountAsync(OrganismOfficeBankAccountId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }

    }
}
