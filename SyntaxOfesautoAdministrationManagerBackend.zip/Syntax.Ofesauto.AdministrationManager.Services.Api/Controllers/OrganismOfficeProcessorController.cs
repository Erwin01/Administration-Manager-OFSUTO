﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class OrganismOfficeProcessorController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismOfficeProcessorController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismOfficeProcessor([FromBody] OrganismOfficeProcessorDTO organismOfficeProcessorDTO)
        {
            if (organismOfficeProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismOfficeProcessorAsync(organismOfficeProcessorDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismOfficeProcessor()
        {

            var response = await _organismApplication.GetAllOrganismOfficeProcessorAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("{officeProcessorId}")]
        public async Task<IActionResult> GetOrganismOfficeProcessorById(string officeProcessorId)
        {

            if (string.IsNullOrEmpty(officeProcessorId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismOfficeProcessorByIdAsync(officeProcessorId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism office processor not exits!");
            }
        }


        [HttpGet("{organismOfficeProcessorId}")]
        public async Task<IActionResult> GetAllOrganismOfficeProcessorById(string organismOfficeProcessorId)
        {

            if (string.IsNullOrEmpty(organismOfficeProcessorId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeProcessorByIdAsync(organismOfficeProcessorId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism office processor not exists!");
            }
        }


        [HttpGet("{officeProcessorOfficeId}")]
        public async Task<IActionResult> GetAllOrganismOfficeProcessorOfficeByIdAsync(string officeProcessorOfficeId)
        {

            if (string.IsNullOrEmpty(officeProcessorOfficeId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeProcessorOfficeByIdAsync(officeProcessorOfficeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }



        [HttpPost]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismOfficeProcessorAsync([FromBody] SelectPrincipalOrganismOfficeProcessorDTO selectPrincipalOrganismOfficeProcessorDTO)
        {
            if (selectPrincipalOrganismOfficeProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismOfficeProcessorAsync(selectPrincipalOrganismOfficeProcessorDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateOrganismOfficeProcessor([FromBody] OrganismOfficeProcessorDTO organismOfficeProcessorDTO)
        {
            if (organismOfficeProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismOfficeProcessorAsync(organismOfficeProcessorDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete("{organismOfficeProcessorId}")]
        public async Task<IActionResult> DeleteOrganismOfficeProcessor(string organismOfficeProcessorId)
        {
            if (string.IsNullOrEmpty(organismOfficeProcessorId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.DeleteOrganismOfficeProcessorAsync(organismOfficeProcessorId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism office processor has already been deleted!");
            }
        }

    }
}
