﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.Security.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class OrganismRepresentativeController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;
        private readonly IOrganismRepresentativeApplication _organismRepresentativeApplication;


        #region [ CONSTRUCTOR ]
        public OrganismRepresentativeController(IOrganismApplication organismApplication, IOrganismRepresentativeApplication organismRepresentativeApplication)
        {
            _organismApplication = organismApplication;
            _organismRepresentativeApplication = organismRepresentativeApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismRepresentative([FromBody] OrganismRepresentativeDTO organismRepresentativeDTO)
        {
            if (organismRepresentativeDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismRepresentativeAsync(organismRepresentativeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> InsertListOrganismRepresentative([FromBody] List<OrganismRepresentativeDTO> organismRepresentativeDTO)
        {
            if (organismRepresentativeDTO.Count <= 0)
            {
                return BadRequest("Fields cannot be empty");

            }


            var response = await _organismRepresentativeApplication.AddListOrganismRepresentative(organismRepresentativeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response);
            }


        }
        //[HttpPost]
        //public async Task<IActionResult> InsertListOrganismRepresented([FromBody] List<OrganismRepresentativeDTO> organismRepresentativeDTO)
        //{
        //    if (organismRepresentativeDTO.Count<=0)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organismRepresentativeApplication.AddListOrganismRepresentative(organismRepresentativeDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);

        //    }
        //    else
        //    {
        //        return BadRequest(response);
        //    }
        //}





        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetOrganismRepresentative(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismRepresentativeByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Representing not exits!");
            }
        }


        [HttpDelete("{representationId}")]
        public async Task<IActionResult> DeleteOrganismRepresentation(string representationId)
        {
            if (string.IsNullOrEmpty(representationId))
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.DeleteOrganismRepresentativeAsync(representationId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism has already been deleted!");
            }
        }



        [HttpPost]
        public async Task<IActionResult> UpdateOrganismRepresentativeAsync([FromBody] OrganismRepresentativeDTO organismRepresentativeDTO)
        {
            if (organismRepresentativeDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.UpdateOrganismRepresentativeAsync(organismRepresentativeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetOrganismGeneralsDataById(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismGeneralsDataByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism not exits!");
            }
        }



        //PassTo
        //[HttpPut]
        //public async Task<IActionResult> DeleteReasonLowPassTo([FromBody] ReasonLowOrganismPassToDTO reasonLowOrganismPassToDTO)
        //{
        //    if (reasonLowOrganismPassToDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _organism_Application.DeleteReasonLowPassToByIdAsync(reasonLowOrganismPassToDTO);

        //    if (response.IsSuccess)
        //    {
        //        return Ok(response);
        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //} 



    }
}
