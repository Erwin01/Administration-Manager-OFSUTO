﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class ProvinceSpainController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public ProvinceSpainController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion       


        [HttpGet]
        public async Task<IActionResult> GetAllProvinceSpain()
        {

            var response = await _organismApplication.GetAllProvinceSpainAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }

    }
}
