﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class OrganismOfficeContactController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismOfficeContactController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismOfficeContactAsync([FromBody] OrganismOfficeContactDTO organismOfficeContactDTO)
        {
            if (organismOfficeContactDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismOfficeContactAsync(organismOfficeContactDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismOfficeContactAsync()
        {

            var response = await _organismApplication.GetAllOrganismOfficeContactAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpPost]
        public async Task<IActionResult> UpdateOrganismOfficeContact([FromBody] OrganismOfficeContactDTO organismOfficeContactDTO)
        {
            if (organismOfficeContactDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismOfficeContactAsync(organismOfficeContactDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{contactId}")]
        public async Task<IActionResult> GetOrganismOfficeContactByIdAsync(string contactId)
        {

            if (string.IsNullOrEmpty(contactId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismOfficeContactByIdAsync(contactId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Contact not exits!");
            }
        }


        [HttpGet("{organismOfficeContactId}")]
        public async Task<IActionResult> GetAllOrganismOfficeContactByIdAsync(string organismOfficeContactId)
        {

            if (string.IsNullOrEmpty(organismOfficeContactId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeContactByIdAsync(organismOfficeContactId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Contact not exits!");
            }
        }


        [HttpGet("{officeContactOfficeId}")]
        public async Task<IActionResult> GetAllOrganismOfficeContactOfficeByIdAsync(string officeContactOfficeId)
        {

            if (string.IsNullOrEmpty(officeContactOfficeId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeContactOfficeByIdAsync(officeContactOfficeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office Contact not exits!");
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismOfficeContact([FromBody] SelectPrincipalOrganismOfficeContactDTO selectPrincipalOrganismOfficeContactDTO)
        {
            if (selectPrincipalOrganismOfficeContactDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismOfficeContactAsync(selectPrincipalOrganismOfficeContactDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> DeleteOrganismOfficeContact(string OrganismOfficeContactId)
        {
            if (string.IsNullOrEmpty(OrganismOfficeContactId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.DeleteOrganismOfficeContactAsync(OrganismOfficeContactId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Contact has already been deleted!");
            }
        }

    }
}
