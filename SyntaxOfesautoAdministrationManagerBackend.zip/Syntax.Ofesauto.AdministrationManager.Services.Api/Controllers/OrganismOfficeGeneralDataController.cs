﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class OrganismOfficeGeneralDataController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;


        #region [ CONSTRUCTOR ]
        public OrganismOfficeGeneralDataController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismOfficeAsync([FromBody] OrganismOfficeDTO organismOfficeDTO)
        {
            if (organismOfficeDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismOfficeAsync(organismOfficeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismOfficeAsync()
        {

            var response = await _organismApplication.GetAllOrganismOfficeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateOrganismOfficeGeneralData([FromBody] OrganismOfficeDTO organismOfficeDTO)
        {
            if (organismOfficeDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismOfficeGeneralDataAsync(organismOfficeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet("{officeId}")]
        public async Task<IActionResult> GetOrganismOfficeByIdAsync(string officeId)
        {

            if (string.IsNullOrEmpty(officeId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismOfficeByIdAsync(officeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office not exits!");
            }
        }

        [HttpGet("{organimsOfficeId}")]
        public async Task<IActionResult> GetAllOrganismOfficeByIdAsync(string organimsOfficeId)
        {

            if (string.IsNullOrEmpty(organimsOfficeId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetAllOrganismOfficeByIdAsync(organimsOfficeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Office not exits!");
            }
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteOrganismOffice(int organismOfficeId)
        {

            var response = await _organismApplication.DeleteOrganismOfficeAsync(organismOfficeId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("This office organism has already been eliminated or not exists!");
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismOffice([FromBody] SelectPrincipalOrganismOfficeDTO selectPrincipalOrganismOfficeDTO)
        {
            if (selectPrincipalOrganismOfficeDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismOfficeAsync(selectPrincipalOrganismOfficeDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest("This office organism has already been eliminated or not exists!");
            }
        }
    }
}
