﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.AdministrationManager.Services.Api.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class OrganismContactController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IOrganismApplication _organismApplication;
        //private readonly IOrganismContactApplication _organismContactApplication;

        #region [ CONSTRUCTOR ]
        public OrganismContactController(IOrganismApplication organismApplication)
        {
            _organismApplication = organismApplication;

        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertOrganismContact([FromBody] OrganismContactDTO organismContactDTO)
        {
            if (organismContactDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.InsertOrganismContactAsync(organismContactDTO);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateOrganismContact([FromBody] OrganismContactDTO organismContact)
        {
            if (organismContact == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateOrganismContactAsync(organismContact);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GetAllOrganismContact()
        {

            var response = await _organismApplication.GetAllOrganismContactAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet("{organismContactId}")]
        public async Task<IActionResult> GetOrganismContactById(string organismContactId)
        {

            if (string.IsNullOrEmpty(organismContactId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.GetOrganismContactByIdAsync(organismContactId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism contact not exits!");
            }
        }

        [HttpGet("{organismId}")]
        public async Task<IActionResult> GetAllOrganismContactById(string organismId)
        {

            if (string.IsNullOrEmpty(organismId))
            {
                return BadRequest("Fields cannot be empty");
            }

            var response = await _organismApplication.GetAllOrganismContactByIdAsync(organismId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism contact not exits!");
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateSelectPrincipalOrganismContactAsync([FromBody] SelectPrincipalOrganismContactDTO selectPrincipalOrganismContactDTO)
        {
            if (selectPrincipalOrganismContactDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.UpdateSelectPrincipalOrganismContactAsync(selectPrincipalOrganismContactDTO);

            if (response.IsSuccess)
            {

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllOrganismContactType()
        {

            var response = await _organismApplication.GetAllOrganismContactTypeAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpDelete("{organismContactId}")]
        public async Task<IActionResult> DeleteOrganismContact(string organismContactId)
        {
            if (string.IsNullOrEmpty(organismContactId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _organismApplication.DeleteOrganismContactAsync(organismContactId);

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest("Organism Contact has already been deleted!");
            }
        }

    }
}
