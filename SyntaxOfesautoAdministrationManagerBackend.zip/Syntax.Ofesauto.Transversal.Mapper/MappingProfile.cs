﻿using AutoMapper;
using Syntax.Ofesauto.AdministrationManager.Application.DTO;
using Syntax.Ofesauto.AdministrationManager.Domain.Entity;
using Syntax.Ofesauto.Security.Application.DTO;
using Syntax.Ofesauto.Security.Domain.Entity;


namespace Syntax.Ofesauto.AdministrationManager.Transversal.Mapper
{

    /// <summary>
    /// Method that allows mapping automatically between data objects and business entities.
    /// </summary>
    /// 
    public class MappingProfile : Profile
    {

        #region [ CONSTRUCTOR ]
        public MappingProfile()
        {
            CreateMap<User, UserDTO>().ReverseMap();
            CreateMap<Login, LoginDTO>().ReverseMap();
            CreateMap<Country, CountryDTO>().ReverseMap();
            CreateMap<Region, RegionDTO>().ReverseMap();
            CreateMap<City, CityDTO>().ReverseMap();
            CreateMap<CountryByRegion, CountryByRegionDTO>().ReverseMap();
            CreateMap<CityByRegionByCountry, CityByRegionByCountryDTO>().ReverseMap();
            CreateMap<DocumentType, DocumentTypeDTO>().ReverseMap();
            CreateMap<ValidateEmailUser, ValidateEmailUserDTO>().ReverseMap();
            CreateMap<ValidateEmail, ValidateEmailDTO>().ReverseMap();
            CreateMap<ValidateVerificationCode, ValidateVerificationCodeDTO>().ReverseMap();
            CreateMap<UserInsertVerificationCode, UserInsertVerificationCodeDTO>().ReverseMap();
            CreateMap<ChangeUserPassword, ChangeUserPasswordDTO>().ReverseMap();
            CreateMap<Organism, OrganismDTO>().ReverseMap();
            CreateMap<GetAllOrganism, GetAllOrganismDTO>().ReverseMap();
            CreateMap<PhoneCodeByCountry, PhoneCodeByCountryDTO>().ReverseMap();
            CreateMap<OrganismType, OrganismTypeDTO>().ReverseMap();
            CreateMap<OrganismSubType, OrganismSubTypeDTO>().ReverseMap();
            CreateMap<OrganismReasonLow, OrganismReasonLowDTO>().ReverseMap();
            CreateMap<ReasonLowOrganism, ReasonLowOrganismDTO>().ReverseMap();
            CreateMap<OrganismContact, OrganismContactDTO>().ReverseMap();
            CreateMap<GetAllOrganismContact, GetAllOrganismContactDTO>().ReverseMap();
            CreateMap<SelectPrincipalOrganismContac, SelectPrincipalOrganismContactDTO>().ReverseMap();
            CreateMap<ViewOrganism, ViewOrganismDTO>().ReverseMap();
            CreateMap<OrganismBankAccount, OrganismBankAccountDTO>().ReverseMap();
            CreateMap<GetAllContactType, GetAllContactTypeDTO>().ReverseMap();
            CreateMap<GetAllBankAccountType, GetAllBankAccountTypeDTO>().ReverseMap();
            CreateMap<GetOrganismBankAccount, GetOrganismBankAccountDTO>().ReverseMap();
            CreateMap<GetAllOrganismBankAccount, GetAllOrganismBankAccountDTO>().ReverseMap();
            CreateMap<GetOrganismContact, GetOrganismContactDTO>().ReverseMap();
            CreateMap<SelectPrincipalOrganismBankAccount, SelectPrincipalOrganismContactDTO>().ReverseMap();
            CreateMap<OrganismOffice, OrganismOfficeDTO>().ReverseMap();
            CreateMap<GetAllOrganismOffice, GetAllOrganismOfficeDTO>().ReverseMap();
            CreateMap<OrganismOfficeContact, OrganismOfficeContactDTO>().ReverseMap();
            CreateMap<GetAllOrganismOfficeContact, GetAllOrganismOfficeContactDTO>().ReverseMap();
            CreateMap<OrganismOfficeContact, OrganismOfficeContactDTO>().ReverseMap();
            CreateMap<GetOrganismOffice, GetOrganismOfficeDTO>().ReverseMap();
            CreateMap<GetOrganismOfficeContactById, GetOrganismOfficeContactByIdDTO>().ReverseMap();
            CreateMap<SelectPrincipalOrganismOfficeContact, SelectPrincipalOrganismOfficeContactDTO>().ReverseMap();
            CreateMap<OrganismOfficeBankAccount, OrganismOfficeBankAccountDTO>().ReverseMap();
            CreateMap<GetAllOrganismOfficeBankAccount, GetAllOrganismOfficeBankAccountDTO>().ReverseMap();
            CreateMap<GetOrganismOfficeBankAccount, GetOrganismOfficeBankAccountDTO>().ReverseMap();
            CreateMap<SelectPrincipalOrganismOfficeBankAccount, SelectPrincipalOrganismOfficeBankAccountDTO>().ReverseMap();
            CreateMap<OrganismOfficeProcessor, OrganismOfficeProcessorDTO>().ReverseMap();
            CreateMap<GetAllOrganismOfficeProcessor, GetAllOrganismOfficeProcessorDTO>().ReverseMap();
            CreateMap<GetOrganismOfficeProcessor, GetOrganismOfficeProcessorDTO>().ReverseMap();
            CreateMap<SelectPrincipalOrganismOfficeProcessor, SelectPrincipalOrganismOfficeProcessorDTO>().ReverseMap();
            CreateMap<DeleteOrganismReasonLow, DeleteOrganismReasonLowDTO>().ReverseMap();
            CreateMap<GetAllOrganismRepresentative, GetAllOrganismRepresentativeDTO>().ReverseMap();
            CreateMap<OrganismRepresentative, OrganismRepresentativeDTO>().ReverseMap();
            CreateMap<GetOrganismGeneralsData, GetOrganismGeneralsDataDTO>().ReverseMap();
            CreateMap<OrganismRepresented, OrganismRepresentedDTO>().ReverseMap();
            CreateMap<GetAllOrganismRepresented, GetAllOrganismRepresentedDTO>().ReverseMap();
            CreateMap<GetAllOrganismOfficeProcessorId, GetAllOrganismOfficeProcessorIdDTO>().ReverseMap();
            CreateMap<GetAllOrganismOfficeContacts, GetAllOrganismOfficeContactsDTO>().ReverseMap();
            CreateMap<SelectPrincipalOrganismOffice, SelectPrincipalOrganismOfficeDTO>().ReverseMap();
            CreateMap<AutonomousCommunity, AutonomousCommunityDTO>().ReverseMap();
            CreateMap<ProvinceSpain, ProvinceSpainDTO>().ReverseMap();


            CreateMap<User, UserDTO>().ReverseMap()
                .ForMember(destination => destination.UserId, source => source.MapFrom(src => src.UserId))
                .ForMember(destination => destination.UserTypeId, source => source.MapFrom(src => src.UserTypeId))
                .ForMember(destination => destination.UserName, source => source.MapFrom(src => src.UserName))
                .ForMember(destination => destination.LastName, source => source.MapFrom(src => src.LastName))
                .ForMember(destination => destination.DocumentTypeId, source => source.MapFrom(src => src.DocumentTypeId))
                .ForMember(destination => destination.UserIdNumber, source => source.MapFrom(src => src.UserIdNumber))
                .ForMember(destination => destination.UserAddress, source => source.MapFrom(src => src.UserAddress))
                .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
                .ForMember(destination => destination.RegionId, source => source.MapFrom(src => src.RegionId))
                .ForMember(destination => destination.CityId, source => source.MapFrom(src => src.CityId))
                .ForMember(destination => destination.PostalCode, source => source.MapFrom(src => src.PostalCode))
                .ForMember(destination => destination.PhoneCodeId, source => source.MapFrom(src => src.PhoneCodeId))
                .ForMember(destination => destination.PhoneNumber, source => source.MapFrom(src => src.PhoneNumber))
                .ForMember(destination => destination.Email, source => source.MapFrom(src => src.Email))
                .ForMember(destination => destination.Password, source => source.MapFrom(src => src.Password))
                .ForMember(destination => destination.Photo, source => source.MapFrom(src => src.Photo))
                .ForMember(destination => destination.CreatedDate, source => source.MapFrom(src => src.CreatedDate))
                .ForMember(destination => destination.UpdatedDate, source => source.MapFrom(src => src.UpdatedDate));


            CreateMap<Login, LoginDTO>().ReverseMap()
               .ForMember(destination => destination.Email, source => source.MapFrom(src => src.Email))
               .ForMember(destination => destination.Password, source => source.MapFrom(src => src.Password));


            CreateMap<Country, CountryDTO>().ReverseMap()
               .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
               .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName));


            CreateMap<Region, RegionDTO>().ReverseMap()
               .ForMember(destination => destination.RegionId, source => source.MapFrom(src => src.RegionId))
               .ForMember(destination => destination.RegionName, source => source.MapFrom(src => src.RegionName));


            CreateMap<City, CityDTO>().ReverseMap()
               .ForMember(destination => destination.CityId, source => source.MapFrom(src => src.CityId))
               .ForMember(destination => destination.CityName, source => source.MapFrom(src => src.CityName));


            CreateMap<CountryByRegion, CountryByRegion>().ReverseMap()
               .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
               .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
               .ForMember(destination => destination.PhoneCodeId, source => source.MapFrom(src => src.PhoneCodeId))
               .ForMember(destination => destination.RegionId, source => source.MapFrom(src => src.RegionId))
               .ForMember(destination => destination.RegionName, source => source.MapFrom(src => src.RegionName));


            CreateMap<CityByRegionByCountry, CityByRegionByCountryDTO>().ReverseMap()
               .ForMember(destination => destination.CityId, source => source.MapFrom(src => src.CityId))
               .ForMember(destination => destination.CityName, source => source.MapFrom(src => src.CityName));


            CreateMap<DocumentType, DocumentTypeDTO>().ReverseMap()
               .ForMember(destination => destination.DocumentTypeId, source => source.MapFrom(src => src.DocumentTypeId))
               .ForMember(destination => destination.DocumentTypeName, source => source.MapFrom(src => src.DocumentTypeName));


            CreateMap<ValidateEmailUser, ValidateEmailUserDTO>().ReverseMap()
               .ForMember(destination => destination.Email, source => source.MapFrom(src => src.Email));


            CreateMap<ValidateEmail, ValidateEmailDTO>().ReverseMap()
               .ForMember(destination => destination.Email, source => source.MapFrom(src => src.Email));


            CreateMap<ValidateVerificationCode, ValidateVerificationCodeDTO>().ReverseMap()
               .ForMember(destination => destination.CodeVerification, source => source.MapFrom(src => src.CodeVerification));


            CreateMap<UserInsertVerificationCode, UserInsertVerificationCodeDTO>().ReverseMap()
               .ForMember(destination => destination.UserId, source => source.MapFrom(src => src.UserId))
               .ForMember(destination => destination.VerificationCode, source => source.MapFrom(src => src.VerificationCode));


            CreateMap<ChangeUserPassword, ChangeUserPasswordDTO>().ReverseMap()
               .ForMember(destination => destination.Password, source => source.MapFrom(src => src.Password));


            CreateMap<PhoneCodeByCountry, PhoneCodeByCountryDTO>().ReverseMap()
               .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
               .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
               .ForMember(destination => destination.PhoneCodeId, source => source.MapFrom(src => src.PhoneCodeId));


            CreateMap<OrganismType, OrganismTypeDTO>().ReverseMap()
               .ForMember(destination => destination.OrganismTypeId, source => source.MapFrom(src => src.OrganismTypeId))
               .ForMember(destination => destination.OrganismTypeName, source => source.MapFrom(src => src.OrganismTypeName))
               .ForMember(destination => destination.OrganismTypeDescription, source => source.MapFrom(src => src.OrganismTypeDescription));


            CreateMap<OrganismSubType, OrganismSubTypeDTO>().ReverseMap()
               .ForMember(destination => destination.OrganismSubTypeId, source => source.MapFrom(src => src.OrganismSubTypeId))
               .ForMember(destination => destination.OrganismSubTypeName, source => source.MapFrom(src => src.OrganismSubTypeName));


            CreateMap<OrganismReasonLow, OrganismReasonLowDTO>().ReverseMap()
               .ForMember(destination => destination.OrganismReasonLowId, source => source.MapFrom(src => src.OrganismReasonLowId))
               .ForMember(destination => destination.OrganismReasonLowName, source => source.MapFrom(src => src.OrganismReasonLowName))
               .ForMember(destination => destination.OrganismReasonLowDescription, source => source.MapFrom(src => src.OrganismReasonLowDescription));


            CreateMap<Organism, OrganismDTO>().ReverseMap()
               .ForMember(destination => destination.OrganismTypeId, source => source.MapFrom(src => src.OrganismTypeId))
               .ForMember(destination => destination.OrganismSubTypeId, source => source.MapFrom(src => src.OrganismSubTypeId))
               .ForMember(destination => destination.OrganismCode, source => source.MapFrom(src => src.OrganismCode))
               .ForMember(destination => destination.OrganismName, source => source.MapFrom(src => src.OrganismName))
               .ForMember(destination => destination.OrganismLastName, source => source.MapFrom(src => src.OrganismLastName))
               .ForMember(destination => destination.DocumentType, source => source.MapFrom(src => src.DocumentType))
               .ForMember(destination => destination.OrganismCIF, source => source.MapFrom(src => src.OrganismCIF))
               .ForMember(destination => destination.OrganismAddress, source => source.MapFrom(src => src.OrganismAddress))
               .ForMember(destination => destination.OrganismPostalCode, source => source.MapFrom(src => src.OrganismPostalCode))
               .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
               .ForMember(destination => destination.RegionId, source => source.MapFrom(src => src.RegionId))
               .ForMember(destination => destination.CityId, source => source.MapFrom(src => src.CityId))
               .ForMember(destination => destination.OrganismWebSite, source => source.MapFrom(src => src.OrganismWebSite));


            CreateMap<GetAllOrganism, GetAllOrganismDTO>().ReverseMap()
               .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
               .ForMember(destination => destination.OrganismName, source => source.MapFrom(src => src.OrganismName))
               .ForMember(destination => destination.OrganismLastName, source => source.MapFrom(src => src.OrganismLastName))
               .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
               .ForMember(destination => destination.OrganismTypeName, source => source.MapFrom(src => src.OrganismTypeName))
               .ForMember(destination => destination.OrganismCIF, source => source.MapFrom(src => src.OrganismCIF))
               .ForMember(destination => destination.OfesautoStateName, source => source.MapFrom(src => src.OfesautoStateName));


            CreateMap<ReasonLowOrganism, ReasonLowOrganismDTO>().ReverseMap()
              .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
              .ForMember(destination => destination.OrganisReasonLowId, source => source.MapFrom(src => src.OrganisReasonLowId));


            CreateMap<ReasonLowOrganismPassTo, ReasonLowOrganismPassToDTO>().ReverseMap()
              .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
              .ForMember(destination => destination.OrganismIdPassTo, source => source.MapFrom(src => src.OrganismIdPassTo));


            CreateMap<OrganismContact, OrganismContactDTO>().ReverseMap()
              .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
              .ForMember(destination => destination.ContactId, source => source.MapFrom(src => src.ContactId))
              .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
              .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
              .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
              .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
              .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail));


            CreateMap<GetAllOrganismContact, GetAllOrganismContactDTO>().ReverseMap()
             .ForMember(destination => destination.ContactPrincipal, source => source.MapFrom(src => src.ContactPrincipal))
             .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
             .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
             .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
             .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
             .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail));


            CreateMap<SelectPrincipalOrganismContac, SelectPrincipalOrganismContactDTO>().ReverseMap()
             .ForMember(destination => destination.ContactId, source => source.MapFrom(src => src.ContactId));
             //.ForMember(destination => destination.ContactPrincipal, source => source.MapFrom(src => src.ContactPrincipal));


            CreateMap<ViewOrganism, ViewOrganismDTO>().ReverseMap()
              .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
              .ForMember(destination => destination.OrganismTypeName, source => source.MapFrom(src => src.OrganismTypeName))
              .ForMember(destination => destination.OrganismSubTypeName, source => source.MapFrom(src => src.OrganismSubTypeName))
              .ForMember(destination => destination.OrganismCode, source => source.MapFrom(src => src.OrganismCode))
              .ForMember(destination => destination.OrganismName, source => source.MapFrom(src => src.OrganismName))
              .ForMember(destination => destination.OrganismLastName, source => source.MapFrom(src => src.OrganismLastName))
              .ForMember(destination => destination.DocumentTypeName, source => source.MapFrom(src => src.OrganismCIF))
              .ForMember(destination => destination.OrganismAddress, source => source.MapFrom(src => src.OrganismAddress))
              .ForMember(destination => destination.OrganismPostalCode, source => source.MapFrom(src => src.OrganismPostalCode))
              .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
              .ForMember(destination => destination.RegionName, source => source.MapFrom(src => src.RegionName))
              .ForMember(destination => destination.CityName, source => source.MapFrom(src => src.CityName))
              .ForMember(destination => destination.OrganismWebSite, source => source.MapFrom(src => src.OrganismWebSite))
              .ForMember(destination => destination.OrganismReasonLowName, source => source.MapFrom(src => src.OrganismReasonLowName))
              .ForMember(destination => destination.OrganismLowDate, source => source.MapFrom(src => src.OrganismLowDate));



            CreateMap<OrganismBankAccount, OrganismBankAccountDTO>().ReverseMap()
               .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
               .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
               .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
               .ForMember(destination => destination.BankAccountNumber, source => source.MapFrom(src => src.BankAccountNumber))
               .ForMember(destination => destination.BankAccountSwift, source => source.MapFrom(src => src.BankAccountSwift));


            CreateMap<GetAllContactType, GetAllContactTypeDTO>().ReverseMap()
              .ForMember(destination => destination.ContactTypeId, source => source.MapFrom(src => src.ContactTypeId))
              .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName));


            CreateMap<GetAllBankAccountType, GetAllBankAccountTypeDTO>().ReverseMap()
              .ForMember(destination => destination.BankAccountTypeId, source => source.MapFrom(src => src.BankAccountTypeId))
              .ForMember(destination => destination.BankAccountTypeName, source => source.MapFrom(src => src.BankAccountTypeName))
              .ForMember(destination => destination.BankAccountTypeDescription, source => source.MapFrom(src => src.BankAccountTypeDescription));


            CreateMap<GetOrganismBankAccount, GetOrganismBankAccountDTO>().ReverseMap()
              .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
              .ForMember(destination => destination.BankAccountTypeName, source => source.MapFrom(src => src.BankAccountTypeName))
              .ForMember(destination => destination.BankAccountTypeDescription, source => source.MapFrom(src => src.BankAccountTypeDescription))
              .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
              .ForMember(destination => destination.BankAccountSwift, source => source.MapFrom(src => src.BankAccountSwift))
              .ForMember(destination => destination.BankAccountNumber, source => source.MapFrom(src => src.BankAccountNumber))
              .ForMember(destination => destination.BankAccountPrincipal, source => source.MapFrom(src => src.BankAccountPrincipal));


            CreateMap<GetAllOrganismBankAccount, GetAllOrganismBankAccountDTO>().ReverseMap()
              .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
              .ForMember(destination => destination.BankAccountTypeName, source => source.MapFrom(src => src.BankAccountTypeName))
              .ForMember(destination => destination.BankAccountTypeDescription, source => source.MapFrom(src => src.BankAccountTypeDescription))
              .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
              .ForMember(destination => destination.BankAccountSwift, source => source.MapFrom(src => src.BankAccountSwift))
              .ForMember(destination => destination.BankAccountNumber, source => source.MapFrom(src => src.BankAccountNumber))
              .ForMember(destination => destination.BankAccountPrincipal, source => source.MapFrom(src => src.BankAccountPrincipal));


            CreateMap<GetOrganismContact, GetOrganismContactDTO>().ReverseMap()
              .ForMember(destination => destination.ContactId, source => source.MapFrom(src => src.ContactId))
              .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
              .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
              .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName))
              .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
              .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
              .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail))
              .ForMember(destination => destination.ContactPrincipal, source => source.MapFrom(src => src.ContactPrincipal));


            CreateMap<SelectPrincipalOrganismBankAccount, SelectPrincipalOrganismBankAccountDTO>().ReverseMap()
             .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId));


            CreateMap<OrganismOffice, OrganismOfficeDTO>().ReverseMap()
              .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.CountryId))
              .ForMember(destination => destination.RegionId, source => source.MapFrom(src => src.RegionId))
              .ForMember(destination => destination.CityId, source => source.MapFrom(src => src.CityId))
              .ForMember(destination => destination.OfficeAddress, source => source.MapFrom(src => src.OfficeAddress))
              .ForMember(destination => destination.OfficePostalCode, source => source.MapFrom(src => src.OfficePostalCode))
              .ForMember(destination => destination.OfficeHightDate, source => source.MapFrom(src => src.OfficeHightDate));


            CreateMap<GetAllOrganismOffice, GetAllOrganismOfficeDTO>().ReverseMap()
              .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
              .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
              .ForMember(destination => destination.RegionName, source => source.MapFrom(src => src.RegionName))
              .ForMember(destination => destination.CityName, source => source.MapFrom(src => src.CityName))
              .ForMember(destination => destination.OfficeContactPrincipal, source => source.MapFrom(src => src.OfficeContactPrincipal));


            CreateMap<SelectPrincipalOrganismOffice, SelectPrincipalOrganismOfficeDTO>().ReverseMap()
            .ForMember(destination => destination.OfficeId, source => source.MapFrom(src => src.OfficeId))
            .ForMember(destination => destination.OfficePrincipal, source => source.MapFrom(src => src.OfficePrincipal));


            CreateMap<OrganismOfficeContact, OrganismOfficeContactDTO>().ReverseMap()
             .ForMember(destination => destination.ContactTypeId, source => source.MapFrom(src => src.ContactTypeId))
             .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
             .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
             .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
             .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
             .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail));
             //.ForMember(destination => destination.OfficeContactPrincipal, source => source.MapFrom(src => src.OfficeContactPrincipal));


            CreateMap<GetAllOrganismOfficeContact, GetAllOrganismOfficeContactDTO>().ReverseMap()
             .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
             .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
             .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
             .ForMember(destination => destination.ContactTypeId, source => source.MapFrom(src => src.ContactTypeId))
             .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName))
             .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
             .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
             .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail))
             .ForMember(destination => destination.OfficeContactPrincipal, source => source.MapFrom(src => src.OfficeContactPrincipal));


            CreateMap<OrganismOfficeContact, OrganismOfficeContactDTO>().ReverseMap()
              .ForMember(destination => destination.ContactTypeId, source => source.MapFrom(src => src.ContactTypeId))
              .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
              .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
              .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
              .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
              .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail));


            CreateMap<GetOrganismOffice, GetOrganismOfficeDTO>().ReverseMap()
              .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
              .ForMember(destination => destination.OfficeHightDate, source => source.MapFrom(src => src.OfficeHightDate))
              .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
              .ForMember(destination => destination.RegionName, source => source.MapFrom(src => src.RegionName))
              .ForMember(destination => destination.CityName, source => source.MapFrom(src => src.CityName))
              .ForMember(destination => destination.OfficeAddress, source => source.MapFrom(src => src.OfficeAddress))
              .ForMember(destination => destination.OfficePostalCode, source => source.MapFrom(src => src.OfficePostalCode))
              .ForMember(destination => destination.OrganismReasonLowName, source => source.MapFrom(src => src.OrganismReasonLowName))
              .ForMember(destination => destination.OfficeLowDate, source => source.MapFrom(src => src.OfficeLowDate));

            CreateMap<GetOrganismOfficeContactById, GetOrganismOfficeContactByIdDTO>().ReverseMap()
              .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
              .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
              .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName))
              .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
              .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
              .ForMember(destination => destination.OfficeContactPrincipal, source => source.MapFrom(src => src.OfficeContactPrincipal))
              .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail));


            CreateMap<GetAllOrganismOfficeContacts, GetAllOrganismOfficeContactsDTO>().ReverseMap()
             .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
             .ForMember(destination => destination.OfficeId, source => source.MapFrom(src => src.OfficeId))
             .ForMember(destination => destination.ContactId, source => source.MapFrom(src => src.ContactId))
             .ForMember(destination => destination.ContactName, source => source.MapFrom(src => src.ContactName))
             .ForMember(destination => destination.ContactLastName, source => source.MapFrom(src => src.ContactLastName))
             .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName))
             .ForMember(destination => destination.ContactPhone, source => source.MapFrom(src => src.ContactPhone))
             .ForMember(destination => destination.ContactFax, source => source.MapFrom(src => src.ContactFax))
             .ForMember(destination => destination.ContactEmail, source => source.MapFrom(src => src.ContactEmail))
             .ForMember(destination => destination.OfficeContactPrincipal, source => source.MapFrom(src => src.OfficeContactPrincipal));


            CreateMap<SelectPrincipalOrganismOfficeContact, SelectPrincipalOrganismOfficeContactDTO>().ReverseMap()
              .ForMember(destination => destination.ContactId, source => source.MapFrom(src => src.ContactId));


            CreateMap<OrganismOfficeBankAccount, OrganismOfficeBankAccountDTO>().ReverseMap()
              .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
              .ForMember(destination => destination.BankAccountName, source => source.MapFrom(src => src.BankAccountName))
              .ForMember(destination => destination.BankAccountTypeId, source => source.MapFrom(src => src.BankAccountTypeId))
              .ForMember(destination => destination.CountryId, source => source.MapFrom(src => src.BankAccountTypeId))
              .ForMember(destination => destination.BankAccountNumber, source => source.MapFrom(src => src.BankAccountNumber))
              .ForMember(destination => destination.BankAccountSwift, source => source.MapFrom(src => src.BankAccountSwift));


            CreateMap<GetAllOrganismOfficeBankAccount, GetAllOrganismOfficeBankAccountDTO>().ReverseMap()
             .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
             .ForMember(destination => destination.BankAccountName, source => source.MapFrom(src => src.BankAccountName))
             .ForMember(destination => destination.BankAccountTypeName, source => source.MapFrom(src => src.BankAccountTypeName))
             .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
             .ForMember(destination => destination.BankAccountSwift, source => source.MapFrom(src => src.BankAccountSwift))
             .ForMember(destination => destination.BankAccountNumber, source => source.MapFrom(src => src.BankAccountNumber))
             .ForMember(destination => destination.OrganismReasonLowName, source => source.MapFrom(src => src.OrganismReasonLowName))
             .ForMember(destination => destination.OfficeBankAccountLowDate, source => source.MapFrom(src => src.OfficeBankAccountLowDate))
             .ForMember(destination => destination.OfficeBankAccountPrincipal, source => source.MapFrom(src => src.OfficeBankAccountPrincipal));


            CreateMap<GetOrganismOfficeBankAccount, GetOrganismOfficeBankAccountDTO>().ReverseMap()
                .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
                .ForMember(destination => destination.BankAccountName, source => source.MapFrom(src => src.BankAccountName))
                .ForMember(destination => destination.BankAccountTypeName, source => source.MapFrom(src => src.BankAccountTypeName))
                .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
                .ForMember(destination => destination.BankAccountSwift, source => source.MapFrom(src => src.BankAccountSwift))
                .ForMember(destination => destination.OfficeBankAccountPrincipal, source => source.MapFrom(src => src.OfficeBankAccountPrincipal))
                .ForMember(destination => destination.BankAccountNumber, source => source.MapFrom(src => src.BankAccountNumber));


            CreateMap<SelectPrincipalOrganismOfficeBankAccount, SelectPrincipalOrganismOfficeBankAccountDTO>().ReverseMap()
                .ForMember(destination => destination.BankAccountId, source => source.MapFrom(src => src.BankAccountId))
                .ForMember(destination => destination.OfficeBankAccountPrincipal, source => source.MapFrom(src => src.OfficeBankAccountPrincipal));


            CreateMap<OrganismOfficeProcessor, OrganismOfficeProcessorDTO>().ReverseMap()
                .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
                .ForMember(destination => destination.ContactTypeId, source => source.MapFrom(src => src.ContactTypeId))
                .ForMember(destination => destination.OfficeProcessorName, source => source.MapFrom(src => src.OfficeProcessorName))
                .ForMember(destination => destination.OfficeProcessorLastName, source => source.MapFrom(src => src.OfficeProcessorLastName))
                .ForMember(destination => destination.OfficeProcessorPhone, source => source.MapFrom(src => src.OfficeProcessorPhone))
                .ForMember(destination => destination.OfficeProcessorFax, source => source.MapFrom(src => src.OfficeProcessorFax))
                .ForMember(destination => destination.OfficeProcessorEmail, source => source.MapFrom(src => src.OfficeProcessorEmail));


            CreateMap<GetAllOrganismOfficeProcessor, GetAllOrganismOfficeProcessorDTO>().ReverseMap()
                .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
                .ForMember(destination => destination.OfficeProcessorName, source => source.MapFrom(src => src.OfficeProcessorName))
                .ForMember(destination => destination.OfficeProcessorLastName, source => source.MapFrom(src => src.OfficeProcessorLastName))
                .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName))
                .ForMember(destination => destination.OfficeProcessorPhone, source => source.MapFrom(src => src.OfficeProcessorPhone))
                .ForMember(destination => destination.OfficeProcessorFax, source => source.MapFrom(src => src.OfficeProcessorFax))
                .ForMember(destination => destination.OfficeProcessorEmail, source => source.MapFrom(src => src.OfficeProcessorEmail))
                .ForMember(destination => destination.OrganismReasonLowName, source => source.MapFrom(src => src.OrganismReasonLowName))
                .ForMember(destination => destination.OfficeProcessorLowDate, source => source.MapFrom(src => src.OfficeProcessorLowDate))
                .ForMember(destination => destination.OfficeProcessorPrincipal, source => source.MapFrom(src => src.OfficeProcessorPrincipal));


            CreateMap<GetOrganismOfficeProcessor, GetOrganismOfficeProcessorDTO>().ReverseMap()
                .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
                .ForMember(destination => destination.OfficeProcessorName, source => source.MapFrom(src => src.OfficeProcessorName))
                .ForMember(destination => destination.OfficeProcessorLastName, source => source.MapFrom(src => src.OfficeProcessorLastName))
                .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName))
                .ForMember(destination => destination.OfficeProcessorPhone, source => source.MapFrom(src => src.OfficeProcessorPhone))
                .ForMember(destination => destination.OfficeProcessorFax, source => source.MapFrom(src => src.OfficeProcessorFax))
                .ForMember(destination => destination.OfficeProcessorEmail, source => source.MapFrom(src => src.OfficeProcessorEmail))
                .ForMember(destination => destination.OrganismReasonLowName, source => source.MapFrom(src => src.OrganismReasonLowName))
                .ForMember(destination => destination.OfficeProcessorLowDate, source => source.MapFrom(src => src.OfficeProcessorLowDate))
                .ForMember(destination => destination.OfficeProcessorPrincipal, source => source.MapFrom(src => src.OfficeProcessorPrincipal));


            CreateMap<SelectPrincipalOrganismOfficeProcessor, SelectPrincipalOrganismOfficeProcessorDTO>().ReverseMap()
                .ForMember(destination => destination.OfficeProcessorId, source => source.MapFrom(src => src.OfficeProcessorId))
                .ForMember(destination => destination.OfficeProcessorPrincipal, source => source.MapFrom(src => src.OfficeProcessorPrincipal));


            CreateMap<DeleteOrganismReasonLow, DeleteOrganismReasonLowDTO>().ReverseMap()
                .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
                .ForMember(destination => destination.OrganismReasonLowId, source => source.MapFrom(src => src.OrganismReasonLowId));


            CreateMap<GetAllOrganismRepresentative, GetAllOrganismRepresentativeDTO>().ReverseMap()
                .ForMember(destination => destination.RepresentationId, source => source.MapFrom(src => src.RepresentationId))
                .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
                .ForMember(destination => destination.OrganismName, source => source.MapFrom(src => src.OrganismName))
                .ForMember(destination => destination.RepresentationStartDate, source => source.MapFrom(src => src.RepresentationStartDate));


            CreateMap<OrganismRepresentative, OrganismRepresentativeDTO>().ReverseMap()
                .ForMember(destination => destination.RepresentativeOrganismId, source => source.MapFrom(src => src.RepresentativeOrganismId));


            CreateMap<OrganismRepresented, OrganismRepresentedDTO>().ReverseMap()
               .ForMember(destination => destination.RepresentedOrganismId, source => source.MapFrom(src => src.RepresentedOrganismId))
               .ForMember(destination => destination.RepresentativeOrganismId, source => source.MapFrom(src => src.RepresentativeOrganismId));


            CreateMap<GetOrganismGeneralsData, GetOrganismGeneralsDataDTO>().ReverseMap()
              .ForMember(destination => destination.OrganismId, source => source.MapFrom(src => src.OrganismId))
              .ForMember(destination => destination.OrganismName, source => source.MapFrom(src => src.OrganismName))
              .ForMember(destination => destination.DocumentTypeName, source => source.MapFrom(src => src.DocumentTypeName))
              .ForMember(destination => destination.OrganismCIF, source => source.MapFrom(src => src.OrganismCIF))
              .ForMember(destination => destination.CountryName, source => source.MapFrom(src => src.CountryName))
              .ForMember(destination => destination.RegionName, source => source.MapFrom(src => src.RegionName))
              .ForMember(destination => destination.CityName, source => source.MapFrom(src => src.CityName))
              .ForMember(destination => destination.OrganismAddress, source => source.MapFrom(src => src.OrganismAddress))
              .ForMember(destination => destination.OrganismPostalCode, source => source.MapFrom(src => src.OrganismPostalCode));


            CreateMap<GetAllOrganismOfficeProcessorId, GetAllOrganismOfficeProcessorIdDTO>().ReverseMap()
             .ForMember(destination => destination.OfficeId, source => source.MapFrom(src => src.OfficeId))
             .ForMember(destination => destination.OfficeProcessorName, source => source.MapFrom(src => src.OfficeProcessorName))
             .ForMember(destination => destination.OfficeProcessorLastName, source => source.MapFrom(src => src.OfficeProcessorLastName))
             .ForMember(destination => destination.ContactTypeName, source => source.MapFrom(src => src.ContactTypeName))
             .ForMember(destination => destination.OfficeProcessorPhone, source => source.MapFrom(src => src.OfficeProcessorPhone))
             .ForMember(destination => destination.OfficeProcessorFax, source => source.MapFrom(src => src.OfficeProcessorFax))
             .ForMember(destination => destination.OfficeProcessorEmail, source => source.MapFrom(src => src.OfficeProcessorEmail))
             .ForMember(destination => destination.OrganismReasonLowName, source => source.MapFrom(src => src.OrganismReasonLowName))
             .ForMember(destination => destination.OfficeProcessorLowDate, source => source.MapFrom(src => src.OfficeProcessorLowDate))
             .ForMember(destination => destination.OfficeProcessorPrincipal, source => source.MapFrom(src => src.OfficeProcessorPrincipal));


            CreateMap<AutonomousCommunity, AutonomousCommunityDTO>().ReverseMap()
             .ForMember(destination => destination.AutonomousCommunityId, source => source.MapFrom(src => src.AutonomousCommunityId))
             .ForMember(destination => destination.AutonomousCommunityName, source => source.MapFrom(src => src.AutonomousCommunityName));


            CreateMap<ProvinceSpain, ProvinceSpainDTO>().ReverseMap()
            .ForMember(destination => destination.ProvinceId, source => source.MapFrom(src => src.ProvinceId))
            .ForMember(destination => destination.ProvinceName, source => source.MapFrom(src => src.ProvinceName));

        }
        #endregion

    }

}
