﻿using System.Data;

namespace Syntax.Ofesauto.ClaimsManager.Transversal.Common
{

    /// <summary>
    /// Method to interact with different database engines
    /// </summary>
    /// 
    #region [ INTERFACE CONNECTION DATABASE ]
    public interface IConnectionFactory
    {
        IDbConnection GetConnection { get; }
    }
    #endregion
}
