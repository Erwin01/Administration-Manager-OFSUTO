﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Core
{
    public class UserDomain : IUserDomain
    {
        private readonly IRepository<User> _repository;
        public UserDomain(IRepository<User> repository)
        {
            _repository = repository;
        }
        public async Task<User> Add(User obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<User>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<User> GetById(int id)
        {
            return await  _repository.GetById(id);
        }

        public async Task<List<User>> GetByParam(Func<User, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<User> GetByParamFirst(Func<User, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<User> Update(User obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
