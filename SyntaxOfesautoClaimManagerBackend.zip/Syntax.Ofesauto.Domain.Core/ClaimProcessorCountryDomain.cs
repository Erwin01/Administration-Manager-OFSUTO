﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Core
{
    public class ClaimProcessorCountryDomain : IClaimProcessorCountryDomain
    {
        private readonly IRepository<ClaimProcessorCountry> _repository;
        private readonly CustomDataContext _context;
        public ClaimProcessorCountryDomain(IRepository<ClaimProcessorCountry> repository, CustomDataContext customDataContext)
        {
            _repository = repository;
            _context = customDataContext;
        }
        public async Task<ClaimProcessorCountry> Add(ClaimProcessorCountry obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<ClaimProcessorCountry>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<ClaimProcessorCountry> GetById(int id)
        {
            return await  _repository.GetById(id);
        }

        public async Task<List<ClaimProcessorCountry>> GetByParam(Func<ClaimProcessorCountry, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<ClaimProcessorCountry> GetByParamFirst(Func<ClaimProcessorCountry, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async  Task<List<ResponseClaimsByCountry>> GetListClaimsByCountry()
        {
            return  await _context.ResponseClaimsByCountry.FromSqlInterpolated($"GetClaimsByCountry").ToListAsync();
        }

        public async Task<ClaimProcessorCountry> Update(ClaimProcessorCountry obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
