﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Core
{
    public class ClaimProcessorDomain : IClaimProcessorDomain, IDisposable
    {
        private readonly IRepository<ClaimProcessor> _repository;
        private readonly CustomDataContext _context;
        public ClaimProcessorDomain(IRepository<ClaimProcessor> repository, CustomDataContext customDataContext)
        {
            _repository = repository;
            _context = customDataContext;
        }
        public async Task<ClaimProcessor> Add(ClaimProcessor obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<ClaimProcessor>> GetAll()
        {
            return await _repository.GetAll();
        }

        //public async Task<ClaimProcessor> GetById(int id)
        //{
        //        return await _repository.GetById(id);
        //}
        public async Task<ClaimProcessor> GetById(int id)
        {
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            return await _context.ClaimProcessor.FindAsync(id);
        }
        public async Task<List<ClaimProcessor>> GetByParam(Func<ClaimProcessor, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<ClaimProcessor> GetByParamFirst(Func<ClaimProcessor, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<List<ResponseTrazability>> GetTrazabilityByProccess(int proccessId)
        {
            return await _context.ResponseTrazability.FromSqlInterpolated($"GetTrazabilityByProccess {proccessId}").ToListAsync();
        }

        public async Task<ClaimProcessor> Update(ClaimProcessor obj, int id)
        {
            return await _repository.Update(obj, id);
        }

        #region DISPOSE
        bool is_disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!is_disposed) // only dispose once!
            {
                if (disposing)
                {
                    Console.WriteLine("Not in destructor, OK to reference other objects");
                }
                // perform cleanup for this object
                Console.WriteLine("Disposing...");
            }
            this.is_disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            // tell the GC not to finalize
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
