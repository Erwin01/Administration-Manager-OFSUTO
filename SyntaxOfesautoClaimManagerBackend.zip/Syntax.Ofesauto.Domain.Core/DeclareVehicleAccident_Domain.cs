﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Core
{
    public class DeclareVehicleAccident_Domain : IDeclareVehicleAccident
    {
        private readonly IRepository<DeclareVehicleAccident> _repository;
        public DeclareVehicleAccident_Domain(IRepository<DeclareVehicleAccident> repository)
        {
            _repository = repository;
        }
        public async Task<DeclareVehicleAccident> Add(DeclareVehicleAccident obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<DeclareVehicleAccident>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<DeclareVehicleAccident> GetById(int id)
        {
            return await  _repository.GetById(id);
        }

        public async Task<List<DeclareVehicleAccident>> GetByParam(Func<DeclareVehicleAccident, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<DeclareVehicleAccident> GetByParamFirst(Func<DeclareVehicleAccident, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<DeclareVehicleAccident> Update(DeclareVehicleAccident obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
