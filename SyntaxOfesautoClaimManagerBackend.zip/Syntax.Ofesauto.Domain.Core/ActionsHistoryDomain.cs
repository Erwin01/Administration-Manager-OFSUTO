﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Core
{
    public class ActionsHistoryDomain : IActionsHistoryDomain
    {
        private readonly IRepository<ActionsHistory> _repository;
        public ActionsHistoryDomain(IRepository<ActionsHistory> repository)
        {
            _repository = repository;
        }
        public async Task<ActionsHistory> Add(ActionsHistory obj)
        {
            return await _repository.Add(obj);
        }

        public async Task<bool> Delete(int id)
        {
            return await _repository.Delete(id);
        }

        public async Task<List<ActionsHistory>> GetAll()
        {
            return await _repository.GetAll();
        }

        public async Task<ActionsHistory> GetById(int id)
        {
            return await  _repository.GetById(id);
        }

        public async Task<List<ActionsHistory>> GetByParam(Func<ActionsHistory, bool> pre)
        {
            return await _repository.GetByParam(pre);
        }

        public async Task<ActionsHistory> GetByParamFirst(Func<ActionsHistory, bool> pre)
        {
            return await _repository.GetByParamFirst(pre);
        }

        public async Task<ActionsHistory> Update(ActionsHistory obj, int id)
        {
            return await _repository.Update(obj, id);
        }
    }
}
