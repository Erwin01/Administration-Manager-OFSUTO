﻿using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Text;
namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data
{
    public class CustomDataContext : DbContext 
    {
        public CustomDataContext(DbContextOptions options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CommunicationAttachments>().ToTable("CommunicationAttachments");
          
        }

        public virtual DbSet<DeclareVehicleAccident> DeclareVehicleAccident { get; set; }
        public virtual DbSet<CommunicationAttachments> CommunicationAttachments { get; set; }
        public virtual DbSet<ActionsHistory> ActionsHistory { get; set; }
        public virtual DbSet<CommunicationsHistory> CommunicationsHistory { get; set; }
        public virtual DbSet<ActionType> ActionType { get; set; }
        public virtual DbSet<ClaimProcessor> ClaimProcessor { get; set; }
        public virtual DbSet<ClaimProcessorCountry> ClaimProcessorCountry { get; set; }
        public virtual DbSet<Settings> Settings { get; set; }
        public virtual DbSet<Country> Country { get; set; }
        public virtual DbSet<Insurer> Insurer { get; set; }
        public virtual DbSet<InsurerByCountry> InsurerByCountry { get; set; }
        public virtual DbSet<InvestigationRecord> InvestigationRecord { get; set; }
        public virtual DbSet<Organism> Organism { get; set; }
        public virtual DbSet<StateAccident> StateAccident { get; set; }
        public virtual DbSet<VehicleCategory> VehicleCategory { get; set; }
        public virtual DbSet<VehicleModel> VehicleModel { get; set; }
        public virtual DbSet<IssuesLog> IssuesLog { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<VehicleModelByVehicleBrand> VehicleModelByVehicleBrand { get; set; }
        public virtual DbSet<ResponseRecorByClasification> ResponseRecorByClasification { get; set; }
        public virtual DbSet<ResponseClaimsByCountry> ResponseClaimsByCountry { get; set; }
        public virtual DbSet<ResponseSpDeclareVehicleAccident> ResponseSpDeclareVehicleAccident { get; set; }
        public virtual DbSet<OfesautoProcess> OfesautoProcess { get; set; }
        public virtual DbSet<ResponseTrazability> ResponseTrazability { get; set; }
        public virtual DbSet<ResponsesJson> ResponsesJson { get; set; }
    }
}
