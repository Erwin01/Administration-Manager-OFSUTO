﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data.Migrations
{
    public partial class addSpGetDeclareVehicleAccidentById : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var sql = @"
            IF OBJECT_ID('GetDeclareVehicleAccidentById', 'P') IS NOT NULL
            DROP PROC GetDeclareVehicleAccidentById
            GO
 
            CREATE PROCEDURE GetDeclareVehicleAccidentById 
	              @Id int  
            AS
            BEGIN
	            -- SET NOCOUNT ON added to prevent extra result sets from
	            -- interfering with SELECT statements.
	            SET NOCOUNT ON;

                -- Insert statements for procedure here
	             SELECT [DeclareVehicleAccidentId]
                          ,[UserId]
                          ,[ClaimantFax]
                          ,[ClaimantReference]
                          ,[DocumentTypeId]
                          ,[ApplicationType]
                          ,[AccidentDate]
                          ,[AccidentCountryId]
                          ,[AccidentRegionId]
                          ,[AccidentVersion]
                          ,[ReasonForOpeningId]
                          ,[CauseVehicleCategoryId]
                          ,[CauseVehicleBrandId]
                          ,[CauseVehicleModelId]
                          ,[CauseVehicleRegistration]
                          ,[CauseCountryRegistrationId]
                          ,[CauseInsuranceCompanyId]
                          ,[CauseNumberPolicy]
                          ,[CauseAddress]
                          ,[Comments]
                          ,[StateId]
                          ,[AffectedVehicleBrandId]
                          ,[AffectedVehicleCategoryId]
                          ,[AffectedVehicleModelId]
                          ,[AffectedVehicleRegistration]
                          ,[AffectedCountryRegistrationId]
                          ,[AffectedInsuranceCompanyId]
                          ,[AffectedNumberPolicy]
                          ,[AffectedName]
                          ,[AffectedSurname]
                          ,[AffectedAddress]
                          ,[AffectedCityId]
                          ,[AffectedRegionId]
                          ,[AffectedEmail]
                          ,[AffectedPhoneNumber]
                          ,[AffectedDamageMaterials]
                          ,[AffectedDamagePersonals]
                          ,[AcceptRgpd]
                          ,[OrganismId]
                          ,[ClaimsProcessorId]
                          ,[CreatedDate]
                          ,[UpdateDate]
                          ,[UpdateDate],
	                       ( select  ah.[ActionHistoryId]
                          ,ah.[OfesautoProcessId]
                          ,ah.[StateId]
                          ,[Observations]
                          ,ah.[IdentificationRegister]
                          ,ah.[UserId]
                          ,ah.[ClaimProcessorId]
                          ,ah.[ActionDate]
                          ,ah.[ActionTypeId]
                          ,ah.[CreateDate]
                          --,ah.[UpdateDate]
	                      ,ActionTypeDescription,
		                      (Select 
				                    ca.AttachmentId,
				                    ca.CommunicationsHistoryId,
				                    ca.AttachmentDate,
				                    ca.AttachmentFileName,
				                    ca.AttachmentPath,
				                    ca.CreateDate,
				                    ca.UpdateDate
			                      from CommunicationsHistory ch
			                      join CommunicationAttachments ca on ch.CommunicationId = ca.CommunicationsHistoryId
		                       where ch.ActionHistoryId = ch.ActionHistoryId
		                       FOR JSON AUTO
		                      )	CommunicationAttachments
                      from  ActionsHistory ah 
                      join ActionType as aty on  ah.ActionTypeId = aty.ActionTypeId
                        FOR JSON AUTO
                      ) ActionHistory
                      FROM DeclareVehicleAccident da
                      where (da.DeclareVehicleAccidentId =@Id )
                      FOR JSON AUTO
            END
            GO
            ";

            migrationBuilder.Sql(sql);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            var sql = @"
            IF OBJECT_ID('GetDeclareVehicleAccidentById', 'P') IS NOT NULL
            DROP PROC GetDeclareVehicleAccidentById
            GO";

            migrationBuilder.Sql(sql);
        }
    }
}
