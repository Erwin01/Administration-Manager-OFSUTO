﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data.Migrations
{
    public partial class CreateViewInputPanel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var sql = @"
            CREATE VIEW [dbo].[View_Input_Panel]
            AS
            SELECT d.DeclareVehicleAccidentId, d.AccidentDate, d.CreatedDate, CASE WHEN d .ReasonForOpeningId = 1 THEN 'Solicitud de información' ELSE 'Solicitar indemnización' END + ' - ' + d.AccidentVersion AS AccidentVersion, 
                  CASE WHEN d .ReasonForOpeningId = 1 THEN 'Solicitud de información' ELSE 'Solicitar indemnización' END AS ActionType, d.UserId, d.ClaimsProcessorId, d.ReasonForOpeningId, d.AccidentCountryId, d.AffectedCountryRegistrationId, 
                  u.UserName + ' ' + u.UserLastName + ' ' + dt.DocumentTypeName + ' ' + u.UserNumber AS Claimant, dt.DocumentTypeName, u.UserNumber, c.CountryName AS AccidentCountry, ca.CountryName AS AffectedCountry, 
                  s.StateName AS 'State', cp.ClaimProcessorName AS Proccessor, d.UpdateDate
            FROM     dbo.DeclareVehicleAccident AS d INNER JOIN
                  dbo.[User] AS u ON d.UserId = u.UserId INNER JOIN
                  dbo.Country AS c ON d.AccidentCountryId = c.CountryId INNER JOIN
                  dbo.Country AS ca ON d.AffectedCountryRegistrationId = ca.CountryId INNER JOIN
                  dbo.State AS s ON d.StateId = s.StateId LEFT OUTER JOIN
                  dbo.ClaimProcessor AS cp ON d.ClaimsProcessorId = cp.ClaimProcessorId INNER JOIN
                  dbo.DocumentType AS dt ON u.DocumentId = dt.DocumentTypeId
            GO

            IF OBJECT_ID('GetRecordsHistory', 'P') IS NOT NULL
            DROP PROC GetRecordByClasification
            GO
 
            CREATE PROCEDURE [dbo].[GetRecordsHistory]                
            AS
            BEGIN
               	SELECT  * from View_Input_Panel
            END

            IF OBJECT_ID('GetRecordByClasification', 'P') IS NOT NULL
            DROP PROC GetRecordByClasification
            GO
 
            CREATE PROCEDURE [dbo].[GetRecordByClasification]                
            AS
            BEGIN
               	SELECT  * from View_Input_Panel
	            where ClaimsProcessorId is  null
            END";

            migrationBuilder.Sql(sql);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"DROP PROC View_Input_Panel");
        }
    }
}
