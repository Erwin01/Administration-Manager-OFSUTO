﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data.Migrations
{
    public partial class addtrazabilityView : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var sql = @" CREATE VIEW [dbo].[View_Input_Panel_trazability]
            AS
            select 
	            ah.ActionHistoryId,
	            ah.ActionTypeId,
	            ah.IdentificationRegister,
	            at.ActionTypeName + ' - ' +at.ActionTypeDescription as Reason,
	            ah.OfesautoProcessId,
	            ah.StateId,
	            ah.ActionDate,
	            ah.UserId,
	            at.ActionTypeName ActionType,
	            s.StateName as 'State',
	            CASE u.UserTypeId WHEN 4 THEN 'Reclamante' When  3 THEN 'Tramitador' else 'Ofesauto' END AS MadeBy

            from 

                ActionsHistory ah
                join ActionType at on ah.ActionTypeId = at.ActionTypeId
                join [State] s on ah.StateId = s.StateId
                join [User] u on ah.UserId = u.UserId
                join UserType ut on u.UserTypeId = ut.UserTypeId
            GO

            IF OBJECT_ID('GetTrazabilityByProccess', 'P') IS NOT NULL
                DROP PROC GetTrazabilityByProccess
            GO
 
            create PROCEDURE [dbo].[GetTrazabilityByProccess] 
	            -- Add the parameters for the stored procedure here
	            @Identification int
            AS
            BEGIN
	            -- SET NOCOUNT ON added to prevent extra result sets from
	            -- interfering with SELECT statements.
	            SET NOCOUNT ON;

                -- Insert statements for procedure here
	            SELECT  * from View_Input_Panel_trazability
	            where IdentificationRegister = @Identification
            END
            ";

            migrationBuilder.Sql(sql);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            
        }
    }
}
