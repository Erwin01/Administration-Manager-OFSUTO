﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data.Migrations
{
    public partial class modifiedGetRecordHistorySP : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ResponseSpDeclareVehicleAccident",
                columns: table => new
                {
                    data = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ResponseSpDeclareVehicleAccident");
        }
    }
}
