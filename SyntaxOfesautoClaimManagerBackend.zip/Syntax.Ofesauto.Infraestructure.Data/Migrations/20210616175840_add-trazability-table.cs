﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data.Migrations
{
    public partial class addtrazabilitytable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TypeTrazabilityId",
                table: "ActionsHistory",
                type: "int",
                nullable: true,
                defaultValueSql: "1");

            

            migrationBuilder.CreateTable(
                name: "StateActionHistory",
                columns: table => new
                {
                    StateId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StateName = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    StateNamEnglish = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StateActionHistory", x => x.StateId);
                });
                migrationBuilder.InsertData(
                table: "StateActionHistory",
                columns: new[] { "StateName", "UserId", "CreateDate" },
                values: new object[] { "Enviado", "1" , "06/06/2021"});
            migrationBuilder.InsertData(
               table: "StateActionHistory",
               columns: new[] { "StateName", "UserId", "CreateDate" },
               values: new object[] { "Respondido", "2", "06/06/2021" });
            migrationBuilder.CreateTable(
                name: "TypeTrazability",
                columns: table => new
                {
                    TypeTrazabilityId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    NamEnglish = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TypeTrazability", x => x.TypeTrazabilityId);
                });

            migrationBuilder.InsertData(
                table: "TypeTrazability",
                columns: new[] { "Name", "UserId", "CreateDate" },
                values: new object[] { "Mensaje Enviado", "1", "06/06/2021" });
            migrationBuilder.CreateIndex(
                name: "IX_ActionsHistory_StateId",
                table: "ActionsHistory",
                column: "StateId");

            migrationBuilder.AddForeignKey(
                name: "FK_ActionsHistory_StateActionHistory_StateId",
                table: "ActionsHistory",
                column: "StateId",
                principalTable: "StateActionHistory",
                principalColumn: "StateId",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ActionsHistory_TypeTrazability",
                table: "ActionsHistory",
                column: "TypeTrazabilityId",
                principalTable: "TypeTrazability",
                principalColumn: "TypeTrazabilityId",
                onDelete: ReferentialAction.NoAction);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ActionsHistory_StateActionHistory_StateId",
                table: "ActionsHistory");

            migrationBuilder.DropForeignKey(
                name: "FK_ActionsHistory_TypeTrazability",
                table: "ActionsHistory");


            migrationBuilder.DropTable(
                name: "StateActionHistory");

            migrationBuilder.DropTable(
                name: "TypeTrazability");

          
            migrationBuilder.DropIndex(
                name: "IX_ActionsHistory_StateId",
                table: "ActionsHistory");

            migrationBuilder.DropColumn(
                name: "TypeTrazabilityId",
                table: "ActionsHistory");
        }
    }
}
