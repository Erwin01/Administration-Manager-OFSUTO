﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data.Migrations
{
    public partial class Initialcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.CreateTable(
            //    name: "ActionType",
            //    columns: table => new
            //    {
            //        ActionTypeId = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        ActionTypeName = table.Column<string>(nullable: false),
            //        ActionTypeDescription = table.Column<string>(nullable: false),
            //        CreateDate = table.Column<DateTime>(nullable: false),
            //        UpdateDate = table.Column<DateTime>(nullable: false),
            //        SendCommunication = table.Column<bool>(nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_ActionType", x => x.ActionTypeId);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "DeclareVehicleAccident",
            //    columns: table => new
            //    {
            //        DeclareVehicleAccidentId = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        UserId = table.Column<int>(nullable: false),
            //        ClaimantFax = table.Column<string>(nullable: true),
            //        ClaimantReference = table.Column<string>(nullable: true),
            //        DocumentTypeId = table.Column<int>(nullable: false),
            //        ApplicationType = table.Column<string>(nullable: true),
            //        AccidentDate = table.Column<DateTime>(nullable: false),
            //        AccidentCountryId = table.Column<int>(nullable: false),
            //        AccidentRegionId = table.Column<int>(nullable: false),
            //        AccidentVersion = table.Column<string>(nullable: true),
            //        ReasonForOpeningId = table.Column<int>(nullable: false),
            //        CauseVehicleCategoryId = table.Column<byte>(nullable: false),
            //        CauseVehicleBrandId = table.Column<byte>(nullable: false),
            //        CauseVehicleModelId = table.Column<byte>(nullable: false),
            //        CauseVehicleRegistration = table.Column<string>(nullable: true),
            //        CauseCountryRegistrationId = table.Column<byte>(nullable: false),
            //        CauseInsuranceCompanyId = table.Column<byte>(nullable: false),
            //        CauseNumberPolicy = table.Column<string>(nullable: true),
            //        CauseAddress = table.Column<string>(nullable: true),
            //        Comments = table.Column<string>(nullable: true),
            //        StateId = table.Column<byte>(nullable: false),
            //        AffectedVehicleBrandId = table.Column<byte>(nullable: false),
            //        AffectedVehicleCategoryId = table.Column<byte>(nullable: false),
            //        AffectedVehicleModelId = table.Column<byte>(nullable: false),
            //        AffectedVehicleRegistration = table.Column<string>(nullable: true),
            //        AffectedCountryRegistrationId = table.Column<int>(nullable: false),
            //        AffectedInsuranceCompanyId = table.Column<int>(nullable: false),
            //        AffectedNumberPolicy = table.Column<string>(nullable: true),
            //        AffectedName = table.Column<string>(nullable: true),
            //        AffectedSurname = table.Column<string>(nullable: true),
            //        AffectedAddress = table.Column<string>(nullable: true),
            //        AffectedCityId = table.Column<int>(nullable: false),
            //        AffectedRegionId = table.Column<int>(nullable: false),
            //        AffectedEmail = table.Column<string>(nullable: true),
            //        AffectedPhoneNumber = table.Column<string>(nullable: true),
            //        AffectedDamageMaterials = table.Column<bool>(nullable: false),
            //        AffectedDamagePersonals = table.Column<bool>(nullable: false),
            //        AcceptRgpd = table.Column<bool>(nullable: false),
            //        OrganismId = table.Column<int>(nullable: true),
            //        ClaimsProcessorId = table.Column<int>(nullable: true),
            //        CreatedDate = table.Column<DateTime>(nullable: false),
            //        UpdateDate = table.Column<DateTime>(nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_DeclareVehicleAccident", x => x.DeclareVehicleAccidentId);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "ActionsHistory",
            //    columns: table => new
            //    {
            //        ActionHistoryId = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        OfesautoProcessId = table.Column<int>(nullable: false),
            //        IdentificationRegister = table.Column<int>(nullable: false),
            //        StateId = table.Column<int>(nullable: false),
            //        Observations = table.Column<string>(nullable: true),
            //        UserId = table.Column<int>(nullable: false),
            //        ActionTypeId = table.Column<int>(nullable: false),
            //        ClaimProcessorId = table.Column<int>(nullable: true),
            //        ActionDate = table.Column<DateTime>(nullable: false),
            //        CreateDate = table.Column<DateTime>(nullable: false),
            //        UpdateDate = table.Column<DateTime>(nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_ActionsHistory", x => x.ActionHistoryId);
            //        table.ForeignKey(
            //            name: "FK_ActionsHistory_ActionType_ActionTypeId",
            //            column: x => x.ActionTypeId,
            //            principalTable: "ActionType",
            //            principalColumn: "ActionTypeId",
            //            onDelete: ReferentialAction.Cascade);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "CommunicationsHistory",
            //    columns: table => new
            //    {
            //        CommunicationId = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        ActionHistoryId = table.Column<int>(nullable: false),
            //        CommunicationDate = table.Column<DateTime>(nullable: false),
            //        CommunicationTo = table.Column<string>(nullable: true),
            //        CommunicationSubject = table.Column<string>(nullable: true),
            //        CommunicationText = table.Column<string>(nullable: true),
            //        CommunicationFileNameHtml = table.Column<string>(nullable: true),
            //        CreateDate = table.Column<DateTime>(nullable: false),
            //        UpdateDate = table.Column<DateTime>(nullable: false),
            //        CommunicationFrom = table.Column<string>(nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_CommunicationsHistory", x => x.CommunicationId);
            //        table.ForeignKey(
            //            name: "FK_CommunicationsHistory_ActionsHistory_ActionHistoryId",
            //            column: x => x.ActionHistoryId,
            //            principalTable: "ActionsHistory",
            //            principalColumn: "ActionHistoryId",
            //            onDelete: ReferentialAction.Cascade);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "CommunicationAttachments",
            //    columns: table => new
            //    {
            //        AttachmentId = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        CommunicationsHistoryId = table.Column<int>(nullable: false),
            //        AttachmentDate = table.Column<DateTime>(nullable: false),
            //        AttachmentFileName = table.Column<string>(nullable: true),
            //        AttachmentPath = table.Column<string>(nullable: true),
            //        AttachmentDescription = table.Column<string>(nullable: true),
            //        CreateDate = table.Column<DateTime>(nullable: false),
            //        UpdateDate = table.Column<DateTime>(nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_CommunicationAttachments", x => x.AttachmentId);
            //        table.ForeignKey(
            //            name: "FK_CommunicationAttachments_CommunicationsHistory_CommunicationsHistoryId",
            //            column: x => x.CommunicationsHistoryId,
            //            principalTable: "CommunicationsHistory",
            //            principalColumn: "CommunicationId",
            //            onDelete: ReferentialAction.Cascade);
            //    });

            //migrationBuilder.CreateIndex(
            //    name: "IX_ActionsHistory_ActionTypeId",
            //    table: "ActionsHistory",
            //    column: "ActionTypeId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_CommunicationAttachments_CommunicationsHistoryId",
            //    table: "CommunicationAttachments",
            //    column: "CommunicationsHistoryId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_CommunicationsHistory_ActionHistoryId",
            //    table: "CommunicationsHistory",
            //    column: "ActionHistoryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CommunicationAttachments");

            migrationBuilder.DropTable(
                name: "DeclareVehicleAccident");

            migrationBuilder.DropTable(
                name: "CommunicationsHistory");

            migrationBuilder.DropTable(
                name: "ActionsHistory");

            migrationBuilder.DropTable(
                name: "ActionType");
        }
    }
}
