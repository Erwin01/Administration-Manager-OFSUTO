﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data.Migrations
{
    public partial class addUserIdtoClaimProcessorCountry : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
   //         migrationBuilder.AddColumn<int>(
   //             name: "UserId",
   //             table: "ClaimProcessorCountry",
   //             type: "int",
   //             nullable: false,
   //             defaultValue: 0);
			////var sql = @"alter PROCEDURE GetClaimsByCountry 
	
			////		AS
			////		BEGIN
			////			-- SET NOCOUNT ON added to prevent extra result sets from
			////			-- interfering with SELECT statements.
			////			SET NOCOUNT ON;

			////			-- Insert statements for procedure here
			////			SELECT 
			////			cp.CountryClaimProcessorId,
			////			case when cp.OpeningReasonId = 1 THEN 'Solicitud de información' ELSE 'Solicitar indemnización' END AS OpeningReason,
			////			c.CountryName AccidentCountry,
			////			c.CountryId AccidentCountryId,
			////			ca.CountryName CauseAccidentCountry,
			////			ca.CountryId CauseAccidentCountryId,
			////			cpr.ClaimProcessorId,
			////			cpr.ClaimProcessorName,
			////			cp.OpeningReasonId,
			////			cp.CreateDate,
			////			cp.UpdateDate,
			////			cp.UserId

			////			from ClaimProcessorCountry cp
			////			INNER JOIN dbo.Country AS c ON cp.AccidentCountryId = c.CountryId 
			////			INNER JOIN dbo.Country AS ca ON cp.CauseRegistrationCountryId = ca.CountryId 
			////			JOIN dbo.ClaimProcessor AS cpr ON cp.ClaimProcessorId = cpr.ClaimProcessorId 
			////		END";

			////migrationBuilder.Sql(sql);

		}

        protected override void Down(MigrationBuilder migrationBuilder)
        {
			var sql = @"
				IF OBJECT_ID('GetClaimsByCountry', 'P') IS NOT NULL
				DROP PROC GetClaimsByCountry
				GO
 
				CREATE PROCEDURE GetClaimsByCountry 
	
				AS
				BEGIN
					-- SET NOCOUNT ON added to prevent extra result sets from
					-- interfering with SELECT statements.
					SET NOCOUNT ON;
					-- Insert statements for procedure here
					SELECT 
					cp.CountryClaimProcessorId,
					case when cp.OpeningReasonId = 1 THEN 'Solicitud de información' ELSE 'Solicitar indemnización' END AS OpeningReason,
					c.CountryName AccidentCountry,
					c.CountryId AccidentCountryId,
					ca.CountryName CauseAccidentCountry,
					ca.CountryId CauseAccidentCountryId,
					cpr.ClaimProcessorId,
					cpr.ClaimProcessorName 
					from ClaimProcessorCountry cp
					INNER JOIN dbo.Country AS c ON cp.AccidentCountryId = c.CountryId 
					INNER JOIN dbo.Country AS ca ON cp.CauseRegistrationCountryId = ca.CountryId 
					JOIN dbo.ClaimProcessor AS cpr ON cp.ClaimProcessorId = cpr.ClaimProcessorId 
				END
            GO";
			migrationBuilder.Sql(sql);
			migrationBuilder.DropColumn(
                name: "UserId",
                table: "ClaimProcessorCountry");
        }
    }
}
