﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Data
{
    interface ICustomDataContext
    {
    }
}
