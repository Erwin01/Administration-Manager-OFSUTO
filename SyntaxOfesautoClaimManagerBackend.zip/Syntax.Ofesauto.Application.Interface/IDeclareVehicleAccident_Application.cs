﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Application.Interface
{
    public interface IDeclareVehicleAccident_Application : IGenericApplication<DeclareVehicleAccidentDTO>
    {
        Task<Response<List<ResponseRecorByClasificationDTO>>> GetRecordsToBeClassified();
        Task<Response<List<ResponseRecorByClasificationDTO>>> GetRecordsHistory();
        Task<Response<bool>> RejectClaim(RejectClaimDTO obj);
        Task<Response<bool>> AssignClaim(AssignClaimDTO obj);
        Task<Response<List<DeclareVehicleAccidentDTO>>> GetAllWithTrazability();
        Task<Response<List<DeclareVehicleAccidentDTO>>> GetAllWithTrazabilityByUserId(int id);
    }
}
