﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;

namespace Syntax.Ofesauto.ClaimsManager.Application.Interface
{
    public interface IActionTypeApplication : IGenericApplication<ActionTypeDTO>
    {
    }
}
