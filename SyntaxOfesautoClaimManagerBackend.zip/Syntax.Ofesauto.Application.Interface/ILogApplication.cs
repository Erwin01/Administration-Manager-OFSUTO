﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Application.Interface
{
    public interface ILogApplication : IGenericApplication<LogDTO>
    {
    }
}
