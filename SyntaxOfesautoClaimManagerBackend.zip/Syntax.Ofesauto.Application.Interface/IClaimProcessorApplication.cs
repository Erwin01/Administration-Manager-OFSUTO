﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Application.Interface
{
    public interface IClaimProcessorApplication : IGenericApplication<ClaimProcessorDTO>
    {
        Task<Response<List<ClaimProcessorDTO>>> GetAllActive();
        Task<Response<List<ResponseTrazabilityDTO>>> GetTrazabilityByProccess(int proccessId);
    }
}
