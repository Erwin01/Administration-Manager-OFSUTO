﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Application.Interface
{
    public interface ISettingsApplication : IGenericApplication<SettingsDTO>
    {
        Task<Response<SettingsDTO>> GetByNameSetting(string name);
    }
}
