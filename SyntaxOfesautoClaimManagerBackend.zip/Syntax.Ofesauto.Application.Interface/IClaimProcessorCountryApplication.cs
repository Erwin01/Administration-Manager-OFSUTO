﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Application.Interface
{
    public interface IClaimProcessorCountryApplication : IGenericApplication<ClaimProcessorCountryDTO>
    {
        Task<Response<ClaimProcessorCountryDTO>> GetClaimByCountry(int sourceCountry, int caussantCountry, int OpeningReasonId);
        Task<Response<List<ResponseClaimsByCountryDto>>> GetListClaimsByCountry();
    }
}
