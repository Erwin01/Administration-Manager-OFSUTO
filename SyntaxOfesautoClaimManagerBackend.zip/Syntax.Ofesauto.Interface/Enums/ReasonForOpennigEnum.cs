﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Interface.Enums
{
    public enum ReasonForOpennig:int
    {
        SolicitudDeInformacion = 1,
        SolicitudIndemnizacion = 2
    }
}
