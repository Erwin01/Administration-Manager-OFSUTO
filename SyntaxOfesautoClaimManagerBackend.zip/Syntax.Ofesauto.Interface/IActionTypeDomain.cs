﻿using Syntax.Ofesauto.ClaimsManager.Domain.Entity;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Interface
{
    public interface IActionTypeDomain : IGenericDomain<ActionType>
    {
    }
}
