﻿using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Interface
{

    #region [ IDECLAREVEHICLEACCIDENT DOMAIN ]
    /// <summary>
    /// Method that allows operations on domain identity
    /// </summary>
    public interface IDeclareVehicleAccidentDomain
    {

        #region [ ASYNCHRONOUS METHODS ]

        #region [ VEHICLE METHODS ]
        Task<IEnumerable<VehicleCategory>> GetAllVehicleCategoryAsync();
        Task<IEnumerable<VehicleBrand>> GetAllVehicleBrandAsync();
        Task<IEnumerable<VehicleModelByVehicleBrand>> GetVehicleModelByVehicleBrandAsync(string insurerByCountryId);
        #endregion


        #region [ DECLARE VEHICLE ACCIDENT METHODS ]
        Task<bool> InsertDeclareVehicleAccidentAsync(DeclareVehicleAccident declareVehicleAccident);
        Task<string> GetDeclareVehicleAccidentById(int declareVehicleAccident);
        Task<bool> InsertDeclareVehicleAccidentAttachmentsAsync(CommunicationAttachments declareVehicleAccidentAttachments);
        Task<bool> InsertDeclareVehicleAccidentActionsAsync(DeclareVehicleAccidentActions declareVehicleAccidentActions);
        Task<IEnumerable<StateAccident>> GetAllStateAccidentAsync();
        Task<ViewClaim> GetViewClaimByIdAsync(string viewClaimById);

        #endregion


        #region [ COMMUNICATIONS HISTORY METHODS ]
        Task<bool> InsertCommunicationsHistoryAsync(CommunicationsHistory communicationsHistory);
        #endregion


        #region [ INVESTIGATION RECORD METHODS ]
        Task<bool> InsertInvestigationRecordAsync(InvestigationRecord investigationRecord);
        #endregion


        #region [ ORGANISM METHODS ]
        Task<bool> InsertOrganismAsync(Organism organism);
        #endregion


        #region [ INSURANCE METHODS ]
        Task<IEnumerable<InsurerByCountry>> GetInsurerByCountryIdAsync(string insurerByCountryId);
        #endregion


        #region [ CLAIMS MANAGER ]
        Task<IEnumerable<GetAllClaimsManager>> GetAllClaimsManagerAsync();
        #endregion

        #endregion

    }
    #endregion
}

