﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Services.WebApi.Email;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Data;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("ClaimsManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class OrganismController : ControllerBase
    {


        /// <summary>
        /// Globals variables
        /// </summary>
        /// 
        private readonly IEmailSender _emailSender;
        public readonly string emailToClaiment = "erwin.paralesda@gmail.com";
        public readonly string emailToProcessor = "eparales@syntax.es";
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;
        private readonly IConnectionFactory _connectionFactory;


        #region [ CONSTRUCTOR ]
        public OrganismController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication, IEmailSender emailSender, IConnectionFactory connectionFactory)
        {
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;
            _emailSender = emailSender;
            _connectionFactory = connectionFactory;

        }
        #endregion

        #region [ INVALIDATED / EXISTS IN ADMINISTRATION MANAGER]
        //[HttpPost]
        //public async Task<IActionResult> InsertOrganismAsync([FromBody] OrganismDTO organismDTO)
        //{
        //    if (organismDTO == null)
        //    {
        //        return BadRequest("Fields cannot be empty");

        //    }

        //    var response = await _declareVehicleAccidentApplication.InsertOrganismAsync(organismDTO);

        //    if (response.IsSuccess)
        //    {

        //        return Ok(response);

        //    }
        //    else
        //    {
        //        return BadRequest(response.Message);
        //    }
        //}
        #endregion
    }
}


// Create actions history
//var connection = _connectionFactory.GetConnection;

//var query = "InsertActionsHistory";
//ActionsHistoryDTO actionsHistoryDTO = new();

//var parameters = new DynamicParameters();

//parameters.Add("ActionId", actionsHistoryDTO.ActionId);
//parameters.Add("DeclareVehicleAccidentId", actionsHistoryDTO.DeclareVehicleAccidentId);
//parameters.Add("StateId", actionsHistoryDTO.StateId);
//parameters.Add("Observations", actionsHistoryDTO.Observations);
//parameters.Add("AttachmentId", actionsHistoryDTO.AttachmentId);
//parameters.Add("UserId", actionsHistoryDTO.UserId);
//parameters.Add("ClaimProcessorId", actionsHistoryDTO.ClaimProcessorId);
//parameters.Add("ActionDate", DateTime.UtcNow);
//parameters.Add("ActionTypeId", actionsHistoryDTO.ActionTypeId);
//parameters.Add("CreateDate", DateTime.UtcNow);
//parameters.Add("UpdateDate", DateTime.UtcNow);

//var insertAction = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);


//if (actionsHistoryDTO.ClaimProcessorId.Equals(ClaimProcessorCountry.claimProcessorEspania))
//{

//    string emailToClaiment = this.emailToClaiment;

//    var message = new Message(new string[] { $"{ emailToClaiment }" }, "OFICINA ESPAÑOLA DE ASEGURADORES DE AUTOMÓVILES", "<span><strong>C./ Sagasta,18 - e 28004 Madrid (España)</strong></span></br><span><strong>Teléfono: 91 446 03 00</strong></span></br><span>Web: <a href=http://ofesauto.es/> </span></br></br><hr><p style='color:black;'text-align:center;'>EL reclamante ha agregado a la reclamación un mensaje y/o documentos.</br><div style='color:black;'text-align:center;'>: " + $"{ actionsHistoryDTO.Observations }" + "</br>: " + "Reclamante Email: <span>" + $"{ this.emailToClaiment }" + "OFICINA ESPAÑOLA DE ASEGURADORAS DE AUTOMÓVILES.</div></br></br> 2021 Ofesauto. All right reserved.</p>", null);
//    _emailSender.SendEmail(message);


//}
//else
//{
//    string emailToProcessor = this.emailToProcessor;

//    var messages = new Message(new string[] { $"{ emailToProcessor }" }, "OFICINA ESPAÑOLA DE ASEGURADORES DE AUTOMÓVILES", "<span><strong>C./ Sagasta,18 - e 28004 Madrid (España)</strong></span></br><span><strong>Teléfono: 91 446 03 00</strong></span></br><span>Web: <a href=http://ofesauto.es/> </span></br></br><hr><p style='color:black;'text-align:center;'>EL reclamante ha agregado a la reclamación un mensaje y/o documentos.</br><div style='color:black;'text-align:center;'>: " + $"{ actionsHistoryDTO.Observations }" + "</br>: " + "Reclamante Email: <span>" + $"{ this.emailToClaiment }" + "OFICINA ESPAÑOLA DE ASEGURADORAS DE AUTOMÓVILES.</div></br></br> 2021 Ofesauto. All right reserved.</p>", null);
//    _emailSender.SendEmail(messages);


//    return Ok(response);

//}


//var queryUpdateOrganism = "UpdateOrganismCodeDva";
//DeclareVehicleAccidentDTO declareVehicleAccidentDTO = new();
//var parameter = new DynamicParameters();

//parameter.Add("DeclareVehicleAccidentId", declareVehicleAccidentDTO.UserId);
//parameter.Add("OrganismId", declareVehicleAccidentDTO.OrganismId);

//var insertCode = await connection.ExecuteAsync(queryUpdateOrganism, param: parameter, commandType: CommandType.StoredProcedure);


