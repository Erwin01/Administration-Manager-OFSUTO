﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("/ClaimsManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class InvestigationController : Controller
    {
        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;
        private readonly IConnectionFactory _connectionFactory;


        #region [ CONSTRUCTOR ]
        public InvestigationController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication, IConnectionFactory connectionFactory)
        {
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;
            _connectionFactory = connectionFactory;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertInvestigationRecordAsync([FromBody] InvestigationRecordDTO investigationRecord)
        {
            if (investigationRecord == null)
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _declareVehicleAccidentApplication.InsertInvestigationRecordAsync(investigationRecord);

            if (response.IsSuccess)
            {

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
