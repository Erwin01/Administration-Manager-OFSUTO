﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("/ClaimsManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class ClaimsManagerController : Controller
    {
        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;

        #region [ CONSTRUCTOR ]
        public ClaimsManagerController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication)
        {
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;

        }
        #endregion


        [HttpGet]
        public async Task<IActionResult> GetAllClaimsManager()
        {

            var response = await _declareVehicleAccidentApplication.GetAllClaimsManagerAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }
    }
}
