﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Services.WebApi.Email;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("/ClaimsManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class CommunicationsHistoryController : Controller
    {
        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IActionsHistoryApplication _actionsHistoryApplication;
        private readonly IEmailSender _emailSender;
        public readonly string emailToClaimant = "eparales@syntax.es";
        public readonly string emailToClaimantProcessor = "testofesauto@gmail.com";

        #region [ CONSTRUCTOR ]
        public CommunicationsHistoryController(IActionsHistoryApplication actionsHistoryApplication, IEmailSender emailSender)
        {
            _actionsHistoryApplication = actionsHistoryApplication;
            _emailSender = emailSender;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertCommunicationsHistory([FromBody] CreateActionsHistoryDTO communicationsHistoryDTO)
        {
            if (communicationsHistoryDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }
            var mapp = AutoMapp<CreateActionsHistoryDTO, ActionsHistoryDTO>.Convert(communicationsHistoryDTO);
            var response = await _actionsHistoryApplication.Add(mapp);

            if (response.IsSuccess)
            {

                // Send emails
                string emailToClaimant = this.emailToClaimant;

                var message = new Message(new string[] { $"{ emailToClaimant }" }, "OFICINA ESPAÑOLA DE ASEGURADORES DE AUTOMÓVILES", "<span><strong>C./Sagasta, 18 - e 2804 Madrid (España)</br>Teléfono: 91 446 03 00</br>Web:</strong> https://www.ofesauto.es/ </br></span></br></br><hr><p style='color:black;'text-align:center;'> </br><div style='color:black;'text-align:center;'>EL reclamante ha agregado a la reclamación un mensaje y/o documentos.</br><p>Reclamante Email: " + $"<strong>{ emailToClaimant }</strong></p>" + "</div></br></br>OFICINA ESPAÑOLA DE ASEGURADORAS DE AUTOMÓVILES.</div></br></br> 2021 Ofesauto. All right reserved.</p>", null);
                _emailSender.SendEmail(message);

                string emailToClaimantProcessor = this.emailToClaimantProcessor;

                var messages = new Message(new string[] { $"{ emailToClaimantProcessor }" }, "OFICINA ESPAÑOLA DE ASEGURADORES DE AUTOMÓVILES", "<span><strong>C./Sagasta, 18 - e 2804 Madrid (España)</br>Teléfono: 91 446 03 00</br>Web:</strong> https://www.ofesauto.es/ </br></span></br></br><hr><p style='color:black;'text-align:center;'> </br><div style='color:black;'text-align:center;'>EL reclamante ha agregado a la reclamación un mensaje y/o documentos.</br><p>Reclamante Email: " + $"<strong>{ emailToClaimant }</strong></p>" + "</div></br></br>OFICINA ESPAÑOLA DE ASEGURADORAS DE AUTOMÓVILES.</div></br></br> 2021 Ofesauto. All right reserved.</p>", null);
                _emailSender.SendEmail(messages);

                return Ok(response);

            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
