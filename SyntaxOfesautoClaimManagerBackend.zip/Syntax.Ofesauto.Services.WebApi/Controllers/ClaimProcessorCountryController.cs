﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimProcessorCountry.Services.WebApi.Controllers
{
    [Route("/ClaimProcessorCountry/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class ClaimProcessorCountryController : Controller
    {
        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IClaimProcessorCountryApplication _ClaimProcessorCountryApplication;

        #region [ CONSTRUCTOR ]
        public ClaimProcessorCountryController(IClaimProcessorCountryApplication ClaimProcessorCountryApplication)
        {
            _ClaimProcessorCountryApplication = ClaimProcessorCountryApplication;
        }
        #endregion


        [HttpGet]
        public async Task<IActionResult> GetAllClaimProcessorCountry()
        {

            var response = await _ClaimProcessorCountryApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }

        [HttpPost]
        public async Task<IActionResult> InsertClaimProcessorCountry([FromBody] ClaimProcessorCountryDTO ClaimProcessorCountryDTO)
        {
            if (ClaimProcessorCountryDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _ClaimProcessorCountryApplication.Add(ClaimProcessorCountryDTO);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateClaimProcessorCountry([FromBody] ClaimProcessorCountryDTO ClaimProcessorCountryDTO, int id)
        {
            if (ClaimProcessorCountryDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _ClaimProcessorCountryApplication.Update(ClaimProcessorCountryDTO,id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetByIdClaimProcessorCountry( int id)
        {
           
            var response = await _ClaimProcessorCountryApplication.GetById(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> DeleteClaimProcessorCountry(int id)
        {
            var response = await _ClaimProcessorCountryApplication.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
