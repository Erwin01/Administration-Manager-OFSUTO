﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Services.WebApi.Email;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("/ClaimsManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class ActionsHistory : Controller
    {
        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IActionsHistoryApplication _ActionsHistoryApplication;

        #region [ CONSTRUCTOR ]
        public ActionsHistory(IActionsHistoryApplication ActionsHistoryApplication)
        {
            _ActionsHistoryApplication = ActionsHistoryApplication;
        }
        #endregion


        [HttpPost]
        public async Task<IActionResult> InsertCommunicationsHistory([FromBody] CreateActionsHistoryDTO ActionsHistoryDTO)
        {
            if (ActionsHistoryDTO == null)
            {
                return BadRequest("Fields cannot be empty");

            }
            var mapp = AutoMapp<CreateActionsHistoryDTO, ActionsHistoryDTO>.Convert(ActionsHistoryDTO);
            var response = await _ActionsHistoryApplication.Add(mapp);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
