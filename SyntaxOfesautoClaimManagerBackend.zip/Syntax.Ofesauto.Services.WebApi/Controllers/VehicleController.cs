﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("ClaimsManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class VehicleController : Controller
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;

        #region [ CONSTRUCTOR ]
        public VehicleController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication)
        {
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;

        }
        #endregion


        #region [ VEHICLE METHODS ]
        [HttpGet]
        public async Task<IActionResult> GetAllVehicleCategoryAsync()
        {

            var response = await _declareVehicleAccidentApplication.GetAllVehicleCategoryAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet]
        public async Task<IActionResult> GetAllVehicleBrandAsync()
        {

            var response = await _declareVehicleAccidentApplication.GetAllVehicleBrandAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }


        [HttpGet]
        public async Task<IActionResult> GetVehicleModelByVehicleBrandAsync(string vehicleBrandId)
        {

            if (string.IsNullOrEmpty(vehicleBrandId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _declareVehicleAccidentApplication.GetVehicleModelByVehicleBrandAsync(vehicleBrandId);


            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }

        #endregion

    }
}
