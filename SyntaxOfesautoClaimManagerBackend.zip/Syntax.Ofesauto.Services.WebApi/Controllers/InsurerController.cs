﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("/ClaimsManager/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class InsurerController : Controller
    {
        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;

        #region [ CONSTRUCTOR ]
        public InsurerController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication)
        {
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;

        }
        #endregion


        [HttpGet]
        public async Task<IActionResult> GetInsurerByCountryAsync(string insurerCountryId)
        {

            if (string.IsNullOrEmpty(insurerCountryId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _declareVehicleAccidentApplication.GetInsurerByCountryIdAsync(insurerCountryId);


            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }
    }
}
