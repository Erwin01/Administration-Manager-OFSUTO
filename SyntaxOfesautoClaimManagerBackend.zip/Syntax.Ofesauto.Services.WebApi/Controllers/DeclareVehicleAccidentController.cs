﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi.Controllers
{
    [Route("[controller]/[action]")]
    //[ApiVersion("1")]
    //[ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class DeclareVehicleAccidentController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        ///         
        private readonly IDeclareVehicleAccident_Application _declareVehicleAccidentService;   
        public DeclareVehicleAccidentController(IDeclareVehicleAccident_Application declareVehicleAccidentService)
        {
            _declareVehicleAccidentService = declareVehicleAccidentService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {

            var response = await _declareVehicleAccidentService.GetAllWithTrazability();
            if (response.IsSuccess)
            {
                var mapp = AutoMapp<DeclareVehicleAccidentDTO, ResponseActionsHistoryDTO>.ConvertList2(response.Data);
                var responseData = new Response<List<ResponseActionsHistoryDTO>> { Data = mapp, IsSuccess = true, Message ="Success"};
                
                return Ok(responseData);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetById(int id)
        {

            var response = await _declareVehicleAccidentService.GetById(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertDeclareVehicleAccidentAsync([FromBody] CreateDeclareVehicleAccidentDTO declareVehicleAccidentDTO)
        {
            if (declareVehicleAccidentDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var mapp = AutoMapp<CreateDeclareVehicleAccidentDTO, DeclareVehicleAccidentDTO>.Convert(declareVehicleAccidentDTO);
            var response = await _declareVehicleAccidentService.Add(mapp);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> RemoveDeclarevehicleAccident(int id)
        {
            var response = await _declareVehicleAccidentService.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }

}
