﻿using Microsoft.AspNetCore.Mvc;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimProcessor.Services.WebApi.Controllers
{
    [Route("/ClaimProcessor/[controller]/[action]")]
    [ApiVersion("1")]
    [ApiExplorerSettings(GroupName = "v1")]
    [ApiController]
    public class ClaimProcessorController : Controller
    {
        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IClaimProcessorApplication _claimProcessorApplication;

        #region [ CONSTRUCTOR ]
        public ClaimProcessorController(IClaimProcessorApplication claimProcessorApplication)
        {
            _claimProcessorApplication = claimProcessorApplication;
        }
        #endregion


        [HttpGet]
        public async Task<IActionResult> GetAllClaimProcessor()
        {

            var response = await _claimProcessorApplication.GetAll();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }

        [HttpPost]
        public async Task<IActionResult> InsertClaimProcessor([FromBody] ClaimProcessorDTO claimProcessorDTO)
        {
            if (claimProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _claimProcessorApplication.Add(claimProcessorDTO);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpPut]
        public async Task<IActionResult> UpdateClaimProcessor([FromBody] ClaimProcessorDTO claimProcessorDTO, int id)
        {
            if (claimProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _claimProcessorApplication.Update(claimProcessorDTO,id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetByIdClaimProcessor( int id)
        {
           
            var response = await _claimProcessorApplication.GetById(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }


        [HttpDelete]
        public async Task<IActionResult> DeleteClaimProcessor(int id)
        {
            var response = await _claimProcessorApplication.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
