using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Application.Main;
using Syntax.Ofesauto.ClaimsManager.Domain.Core;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Repository;
using Syntax.Ofesauto.ClaimsManager.Services.WebApi.Email;
using Syntax.Ofesauto.ClaimsManager.Services.WebApi.Helpers;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using Syntax.Ofesauto.ClaimsManager.Transversal.EmailService.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.EmailService.Model;
using Syntax.Ofesauto.ClaimsManager.Transversal.EmailService.Service;
using Syntax.Ofesauto.ClaimsManager.Transversal.Logging;
using Syntax.Ofesauto.ClaimsManager.Transversal.Mapper;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Services.WebApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            // Others services
            #region [ OTHERS SERVICES ]
            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            });
            services.Configure<MailSettings>(Configuration.GetSection("EmailConfiguration"));
            services.AddControllers();
            services.AddApiVersioning();
            //services.Configure<IISOptions>(options =>
            //{
            //    options.AutomaticAuthentication = false;
            //});
            #endregion



            #region [ CONFIGURE BUFFER / FILES-WEIGTH ]
            services.Configure<FormOptions>(o =>
            {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });
            #endregion


            // Auto mapper configurations
            #region [ AUTO MAPPER ]
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            #endregion


            // Dependences injection
            #region [ DEPENDENCES INJECTION ]
            var appSettingsSection = Configuration.GetSection("Config");

            services.Configure<AppSettings>(appSettingsSection);
            services.AddTransient(typeof(IRepository<>), typeof(Repository<>));
            services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IConnectionFactory, ConnectionFactory>();
            services.AddDbContext<CustomDataContext>(c => c.UseSqlServer(Configuration.GetConnectionString("Ofesauto")));
            services.AddScoped<IDeclareVehicleAccidentApplication, DeclareVehicleAccidentApplication>();
            services.AddScoped<IDeclareVehicleAccidentDomain, DeclareVehicleAccidentDomain>();
            services.AddScoped<IDeclareVehicleAccidentRepository, DeclareVehicleAccidentRepository>();

            /*Services with use EF for Crud and querys*/
            services.AddScoped<IDeclareVehicleAccident, DeclareVehicleAccident_Domain>();
            services.AddScoped<IDeclareVehicleAccident_Application, DeclareVehicleAccidentApplicationService>();
            services.AddScoped<IActionsHistoryDomain, ActionsHistoryDomain>();
            services.AddScoped<IActionsHistoryApplication, ActionHistoryApplication>();

            services.AddScoped<ICommunicationsHistoryDomain, CommunicationsHistoryDomain>();
            services.AddScoped<ICommunicationsHistoryApplication, CommunicationsHistoryApplication>();
            services.AddScoped<ICommunicationAttachmentsDomain, CommunicationAttachmentsDomain>();
            services.AddScoped<ICommunicationAttachmentsApplication, CommunicationAttachmentsApplication>();
            services.AddScoped<IClaimProcessorCountryDomain, ClaimProcessorCountryDomain>();
            services.AddScoped<IClaimProcessorDomain, ClaimProcessorDomain>();
            services.AddScoped<IClaimProcessorApplication, ClaimProcessorApplication>();
            services.AddScoped<IClaimProcessorCountryApplication, ClaimProcessorCountryApplication>();

            services.AddScoped<ISettingsDomain, SettingsDomain>();
            services.AddScoped<ISettingsApplication, SettingsApplication>();
            services.AddScoped<IActionTypeDomain, ActionTypeDomain>();
            services.AddScoped<IActionTypeApplication, ActionTypeApplication>();
            services.AddScoped<IFileHandlerApplication, FileHandlerApplication>();
            services.AddScoped<IMailService, MailService>();
            /*End*/
            services.AddScoped(typeof(IAppLogger<>), typeof(LoggerAdapter<>));
            #endregion

            // Configuration service E-mail
            #region [ CONFIGURATION E-MAIL ]
            var emailConfig = Configuration.GetSection("EmailConfiguration").Get<EmailConfiguration>();
            services.AddSingleton(emailConfig);
            services.AddScoped<IEmailSender, EmailSender>();
            #endregion


            // Api versioning
            #region [ API VERSIONING ]
            services.AddApiVersioning(version =>
            {
                version.AssumeDefaultVersionWhenUnspecified = true;
                version.DefaultApiVersion = new ApiVersion(1, 0);
            });
            #endregion


            //Register the Swagger generator, defining 1 or more Swagger documents
            #region [ SWAGGER DOCUMENTATION MANAGER ]
            services.AddSwaggerGen(c =>
            {

                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Syntax Ofesauto Api - Claims Manager",
                    Version = "v1",
                    Description = "OFICINA ESPA�OLA DE ASEGURADORAS DE AUTOMOVIL",
                    TermsOfService = new Uri("https://www.ofesauto.es/"),
                    Contact = new OpenApiContact
                    {
                        Name = "Syntax Group",
                        Email = "info@syntax.es",
                        Url = new Uri("https://www.syntax.es/")
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Syntax Group",
                        Url = new Uri("https://www.syntax.es/soluciones/")
                    }

                });

                // Set the comments path for the Swagger JSON and URI
                c.ResolveConflictingActions(a => a.First());
                c.OperationFilter<ApplyVersionsSwagger>();
                c.DocumentFilter<ReplaceVersionWithExactValueInPath>();

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = ConfigurationPath.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlFile);

            });
            #endregion


            //Services of authentication using Jason Web Token
            #region [ AUTHENTICATION JWT ]
            var appsetings = appSettingsSection.Get<AppSettings>();

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            //Events in token
            .AddJwtBearer(x =>
            {
                x.Events = new JwtBearerEvents
                {
                    OnTokenValidated = context =>
                    {
                        var userId = int.Parse(context.Principal.Identity.Name);
                        return Task.CompletedTask;
                    },
                    //Exception in the moment of authentication
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                        {
                            context.Response.Headers.Add("Token-Expired", "true");

                        }

                        return Task.CompletedTask;
                    },
                };

                x.RequireHttpsMetadata = false;
                x.SaveToken = false;

                //Validation of token
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };
            });
            #endregion

        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                // Save log in file .txt
                #region [ LOGGER FILE ]
                loggerFactory.AddFile("Log-{Date}.Txt");
                #endregion

                // Swagger endpoints
                #region [ SWAGGER ENDPOINTS ]
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Syntax Ofesauto Api - Claims Manager");
                });
                #endregion

                // Cors
                #region [ CORS ]
                app.UseCors(options =>
                {

                    options.WithOrigins("http://localhost:3000");
                    options.AllowAnyMethod();
                    options.AllowAnyHeader();

                });
                #endregion
                #region [ METHOD STATIC FILES ]
                app.UseStaticFiles();
                app.UseStaticFiles(new StaticFileOptions
                {
                    FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"ClaimsManagerFiles")),
                    RequestPath = new PathString("/ClaimsManagerFiles"),
                });
                #endregion
                app.UseAuthentication();

                


                app.UseRouting();

                app.UseAuthorization();

                app.UseEndpoints(endpoints =>
                {
                    endpoints.MapControllers();
                });
            }
        }
    }
}
