﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using Syntax.Ofesauto.Security.Services.Api.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class ClaimProcessorCountryController : CustomControllerBase
    {

        private readonly ILogger<ClaimProcessorCountryController> _logger;
        private readonly IClaimProcessorCountryApplication _ClaimProcessorCountryService;
        public ClaimProcessorCountryController(IClaimProcessorCountryApplication ClaimProcessorCountryService, ILogger<ClaimProcessorCountryController> logger)
        {
            _logger = logger;
            _ClaimProcessorCountryService = ClaimProcessorCountryService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {

            var response = await _ClaimProcessorCountryService.GetAll();
            if (response.IsSuccess)
            {
                //var mapp = AutoMapp<ClaimProcessorCountryDTO, ResponseActionsHistoryDTO>.ConvertList2(response.Data);
                //var responseData = new Response<List<ResponseActionsHistoryDTO>> { Data = mapp, IsSuccess = true, Message = "Success" };

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetListClaimsByCountry()
        {

            var response = await _ClaimProcessorCountryService.GetListClaimsByCountry();
            if (response.IsSuccess)
            {
                //var mapp = AutoMapp<ClaimProcessorCountryDTO, ResponseActionsHistoryDTO>.ConvertList2(response.Data);
                //var responseData = new Response<List<ResponseActionsHistoryDTO>> { Data = mapp, IsSuccess = true, Message = "Success" };

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetById(int id)
        {

            var response = await _ClaimProcessorCountryService.GetById(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertClaimProcessorCountryAsync([FromBody] ClaimProcessorCountryDTO ClaimProcessorCountryDTO)
        {
            GetDataUser();
            ClaimProcessorCountryDTO.Userid = user.Id;
            if (ClaimProcessorCountryDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _ClaimProcessorCountryService.Add(ClaimProcessorCountryDTO);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateClaimProcessorCountryAsync( [FromBody] ClaimProcessorCountryDTO ClaimProcessorCountryDTO)
        {
            if (ClaimProcessorCountryDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _ClaimProcessorCountryService.Update(ClaimProcessorCountryDTO, ClaimProcessorCountryDTO.CountryClaimProcessorId);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> RemoveClaimProcessorCountry(int id)
        {
            var response = await _ClaimProcessorCountryService.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
