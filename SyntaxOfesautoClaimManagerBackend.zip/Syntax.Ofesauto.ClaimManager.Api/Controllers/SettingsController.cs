﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class SettingsController : ControllerBase
    {

        private readonly ILogger<SettingsController> _logger;
        private readonly ISettingsApplication _SettingsService;
        public SettingsController(ISettingsApplication SettingsService, ILogger<SettingsController> logger)
        {
            _logger = logger;
            _SettingsService = SettingsService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {

            var response = await _SettingsService.GetAll();
            if (response.IsSuccess)
            {
                var mapp = AutoMapp<SettingsDTO, ResponseActionsHistoryDTO>.ConvertList2(response.Data);
                var responseData = new Response<List<ResponseActionsHistoryDTO>> { Data = mapp, IsSuccess = true, Message = "Success" };

                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {

            var response = await _SettingsService.GetById(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetDataLetter()
        {

            var response = await _SettingsService.GetByNameSetting("EmailWhiteLetter");
            var responseData = new Response<WhiteLetter>();
            var ObjResponse = new WhiteLetter();
            ObjResponse.EmailLetter = response.Data.Value;
            response = await _SettingsService.GetByNameSetting("PasswordWhiteLetter");
            ObjResponse.PasswordLetter = response.Data.Value;
            if (response.IsSuccess)
            {
                responseData.Data = ObjResponse;
                responseData.IsSuccess = true;
                responseData.Message = "Success";
                return Ok(responseData);
            }
            else
            {
                return BadRequest(response);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertSettingsAsync([FromBody] SettingsDTO SettingsDTO)
        {
            if (SettingsDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _SettingsService.Add(SettingsDTO);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> SaveLetter([FromBody] WhiteLetter SettingsDTO)
        {
            if (SettingsDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var obj = await _SettingsService.GetByNameSetting("EmailWhiteLetter");
            obj.Data.UpdateDate = DateTime.Now;
            obj.Data.Value = SettingsDTO.EmailLetter;
            var ObjUpdate = obj.Data;
            var response = await _SettingsService.Update(ObjUpdate
                , obj.Data.SettingId);


            obj = await _SettingsService.GetByNameSetting("PasswordWhiteLetter");
            obj.Data.UpdateDate = DateTime.Now;
            obj.Data.Value = SettingsDTO.PasswordLetter;
            ObjUpdate = obj.Data;
            response = await _SettingsService.Update(ObjUpdate
                , obj.Data.SettingId);
            if (response.IsSuccess)
            {
                return Ok(ObjUpdate);
            }
            else
            {
                return BadRequest(response);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> RemoveSettings(int id)
        {
            var response = await _SettingsService.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
