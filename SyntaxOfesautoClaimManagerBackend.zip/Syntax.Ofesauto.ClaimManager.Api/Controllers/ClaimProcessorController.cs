﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class ClaimProcessorController : ControllerBase
    {

        private readonly ILogger<ClaimProcessorController> _logger;
        private readonly IClaimProcessorApplication _ClaimProcessorService;
        public ClaimProcessorController(IClaimProcessorApplication ClaimProcessorService, ILogger<ClaimProcessorController> logger)
        {
            _logger = logger;
            _ClaimProcessorService = ClaimProcessorService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {

            var response = await _ClaimProcessorService.GetAll();
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetAllActive()
        {

            var response = await _ClaimProcessorService.GetAllActive();
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {

            var response = await _ClaimProcessorService.GetById(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet("id")]
        public async Task<IActionResult> GetTrazabilityByProccess(int id)
        {

            var response = await _ClaimProcessorService.GetTrazabilityByProccess(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertClaimProcessorAsync([FromBody] ClaimProcessorDTO ClaimProcessorDTO)
        {
            if (ClaimProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var response = await _ClaimProcessorService.Add(ClaimProcessorDTO);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddEmailRedirect([FromBody] ClaimProcessorEmailRedirectDTO ClaimProcessorDTO)
        {
            if (ClaimProcessorDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            var obj = await _ClaimProcessorService.GetById(ClaimProcessorDTO.ClaimProcessorId);
            obj.Data.UpdateDate = DateTime.Now;
            obj.Data.ClaimProcessorEmailRedirect = ClaimProcessorDTO.ClaimProcessorEmailRedirect;
            var ObjUpdate = obj.Data;            
            var response = await _ClaimProcessorService.Update(ObjUpdate
                , ClaimProcessorDTO.ClaimProcessorId);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> RemoveClaimProcessor(int id)
        {
            var response = await _ClaimProcessorService.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
