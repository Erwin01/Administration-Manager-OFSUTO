﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class ClaimManagerController : ControllerBase
    {

        private readonly ILogger<ClaimManagerController> _logger;
        private readonly ISettingsApplication _setting;
        public ClaimManagerController(ISettingsApplication setting, ILogger<ClaimManagerController> logger)
        {
            _logger = logger;
            _setting = setting;
        }

        #region [ ClaimManagerFiles METHODS ]
        [HttpGet("{file}")]
        public async Task<IActionResult> Uploads(string file)
        {
            try
            {
                _logger.LogInformation($"Consultando archivo {file}");
                var path = await _setting.GetByNameSetting("save_folder");
                var pathToRead = Path.Combine(Directory.GetCurrentDirectory(), path.Data.Value);
                var pathToDownload = Path.Combine(pathToRead, file);
                _logger.LogInformation($"Consultando archivo {pathToDownload}");
                // var response = await _declareVehicleAccidentService.GetRecordsToBeClassified();
                byte[] data = await System.IO.File.ReadAllBytesAsync(pathToDownload);
                return File(data, GetMIMEType(file));
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Error al consultar archivos archivos {ex.Message} Error : {ex.InnerException}");
                return BadRequest(ex.Message);
            }


        }


        private string GetMIMEType(string fileName)
        {
            var provider =
                new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider();
            string contentType;
            if (!provider.TryGetContentType(fileName, out contentType))
            {
                contentType = "application/octet-stream";
            }
            return contentType;
        }

        #endregion
    }
}
