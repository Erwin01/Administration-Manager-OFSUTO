﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class InsurerController : ControllerBase
    {

        private readonly ILogger<InsurerController> _logger;
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;
        public InsurerController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication, ILogger<InsurerController> logger)
        {
            _logger = logger;
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;
        }

        [HttpGet]
        public async Task<IActionResult> GetInsurerByCountryAsync(string insurerCountryId)
        {

            if (string.IsNullOrEmpty(insurerCountryId))
            {
                return BadRequest("Fields cannot be empty");

            }

            var response = await _declareVehicleAccidentApplication.GetInsurerByCountryIdAsync(insurerCountryId);


            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }
    }
}
