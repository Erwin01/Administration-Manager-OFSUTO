﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class ClaimsManagerController : ControllerBase
    {

        /// <summary>
        /// Globals variables
        /// </summary>
        private readonly IDeclareVehicleAccidentApplication _declareVehicleAccidentApplication;

        #region [ CONSTRUCTOR ]
        public ClaimsManagerController(IDeclareVehicleAccidentApplication declareVehicleAccidentApplication)
        {
            _declareVehicleAccidentApplication = declareVehicleAccidentApplication;

        }
        #endregion


        [HttpGet]
        public async Task<IActionResult> GetAllClaimsManager()
        {

            var response = await _declareVehicleAccidentApplication.GetAllClaimsManagerAsync();

            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }

        }
    }
}
