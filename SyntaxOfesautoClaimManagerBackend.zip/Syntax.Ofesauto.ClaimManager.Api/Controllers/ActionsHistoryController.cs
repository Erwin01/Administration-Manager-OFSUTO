﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using Syntax.Ofesauto.Security.Services.Api.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class ActionsHistoryController : CustomControllerBase
    {

        private readonly ILogger<ActionsHistoryController> _logger;
        private readonly IActionsHistoryApplication _ActionsHistoryService;
        public ActionsHistoryController(IActionsHistoryApplication ActionsHistoryService, ILogger<ActionsHistoryController> logger)
        {
            _logger = logger;
            _ActionsHistoryService = ActionsHistoryService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {

            var response = await _ActionsHistoryService.GetAll();
            if (response.IsSuccess)
            {
                var mapp = AutoMapp<ActionsHistoryDTO, ResponseActionsHistoryDTO>.ConvertList2(response.Data);
                var responseData = new Response<List<ResponseActionsHistoryDTO>> { Data = mapp, IsSuccess = true, Message = "Success" };

                return Ok(responseData);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetById(int id)
        {

            var response = await _ActionsHistoryService.GetById(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> InsertActionsHistoryAsync([FromForm] ActionsHistoryDTO ActionsHistoryDTO)
        {
            if (ActionsHistoryDTO == null)
            {
                return BadRequest("Fields cannot be empty");
            }
            GetDataUser();
            ActionsHistoryDTO.EmailSender = user.Email;
            ActionsHistoryDTO.UserId = user.Id;
            var response = await _ActionsHistoryService.Add(ActionsHistoryDTO);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> RemoveActionsHistory(int id)
        {
            var response = await _ActionsHistoryService.Delete(id);
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response.Message);
            }
        }
    }
}
