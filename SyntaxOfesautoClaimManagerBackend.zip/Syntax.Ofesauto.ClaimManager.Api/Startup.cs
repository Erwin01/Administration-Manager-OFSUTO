using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
//using Microsoft.OpenApi.Models;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Application.Main;
using Syntax.Ofesauto.ClaimsManager.Application.Main.Handler;
using Syntax.Ofesauto.ClaimsManager.Domain.Core;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Repository;
using Syntax.Ofesauto.ClaimsManager.Services.WebApi.Helpers;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using Syntax.Ofesauto.ClaimsManager.Transversal.EmailService.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.EmailService.Model;
using Syntax.Ofesauto.ClaimsManager.Transversal.EmailService.Service;
using Syntax.Ofesauto.ClaimsManager.Transversal.Logging;
using Syntax.Ofesauto.ClaimsManager.Transversal.Mapper;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimManager.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            #region [ OTHERS SERVICES ]           
            services.Configure<MailSettings>(Configuration.GetSection("EmailConfiguration"));
            services.AddControllers();
            //services.AddMvc()
            //.AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());
            var appSettingsSection = Configuration.GetSection("Config");

            services.Configure<AppSettings>(appSettingsSection);
            #endregion

            #region [ CONFIGURE BUFFER / FILES-WEIGTH ]
            services.Configure<FormOptions>(o =>
            {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });
            #endregion

            // Api versioning
            #region [ API VERSIONING ]
            services.AddApiVersioning(version =>
            {
                version.AssumeDefaultVersionWhenUnspecified = true;
                version.DefaultApiVersion = new ApiVersion(1, 0);
            });
            #endregion

            // Auto mapper configurations
            #region [ AUTO MAPPER ]
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            #endregion
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Syntax Ofesauto Api - Claims Manager",
                    Version = "v1",
                    Description = "OFICINA ESPA�OLA DE ASEGURADORAS DE AUTOMOVIL",
                    TermsOfService = new Uri("https://www.ofesauto.es/"),
                    Contact = new OpenApiContact
                    {
                        Name = "Syntax Group",
                        Email = "info@syntax.es",
                        Url = new Uri("https://www.syntax.es/")
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Syntax Group",
                        Url = new Uri("https://www.syntax.es/soluciones/")
                    }
                });
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
            });

            services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<ClaimsManager.Transversal.Common.IConnectionFactory, ConnectionFactory>();
            services.AddTransient(typeof(IRepository<>), typeof(Repository<>));
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddDbContext<CustomDataContext>(c => c.UseSqlServer(Configuration.GetConnectionString("Ofesauto")));
            services.AddScoped<IDeclareVehicleAccidentApplication, DeclareVehicleAccidentApplication>();
            services.AddScoped<IDeclareVehicleAccidentDomain, DeclareVehicleAccidentDomain>();
            services.AddScoped<IDeclareVehicleAccidentRepository, DeclareVehicleAccidentRepository>();

            /*Services with use EF for Crud and querys*/
            services.AddScoped<IDeclareVehicleAccident, DeclareVehicleAccident_Domain>();
            services.AddScoped<IDeclareVehicleAccident_Application, DeclareVehicleAccidentApplicationService>();
            services.AddScoped<IActionsHistoryDomain, ActionsHistoryDomain>();
            services.AddScoped<IActionsHistoryApplication, ActionHistoryApplication>();

            services.AddScoped<ICommunicationsHistoryDomain, CommunicationsHistoryDomain>();
            services.AddScoped<ICommunicationsHistoryApplication, CommunicationsHistoryApplication>();
            services.AddScoped<ICommunicationAttachmentsDomain, CommunicationAttachmentsDomain>();
            services.AddScoped<ICommunicationAttachmentsApplication, CommunicationAttachmentsApplication>();
            services.AddScoped<IClaimProcessorCountryDomain, ClaimProcessorCountryDomain>();
            services.AddScoped<IClaimProcessorDomain, ClaimProcessorDomain>();
            services.AddScoped<IClaimProcessorApplication, ClaimProcessorApplication>();
            services.AddScoped<IClaimProcessorCountryApplication, ClaimProcessorCountryApplication>();

            services.AddScoped<ISettingsDomain, SettingsDomain>();
            services.AddScoped<ISettingsApplication, SettingsApplication>();
            services.AddScoped<IActionTypeDomain, ActionTypeDomain>();
            services.AddScoped<IActionTypeApplication, ActionTypeApplication>();
            services.AddScoped<ILogDomain, LogDomain>();
            services.AddScoped<ILogApplication, LogApplication>();
            services.AddScoped<IUserDomain, UserDomain>();
            services.AddScoped<IUserApplication, UserApplication>(); 
            services.AddScoped<IOfesautoProcessDomain, OfesautoProcessDomain>();
            services.AddScoped<IOfesautoProcessApplication, OfesautoProcessApplication>();
            services.AddScoped<IFileHandlerApplication, FileHandlerApplication>();
            services.AddScoped<IFileUploadApplication, FileUploadHandler>();
            services.AddScoped<IMailService, MailService>();
            /*End*/
            services.AddScoped(typeof(IAppLogger<>), typeof(LoggerAdapter<>));



            //Services of authentication using Jason Web Token
            #region [ AUTHENTICATION JWT ]
            var appsetings = appSettingsSection.Get<AppSettings>();

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            //Events in token
            .AddJwtBearer(x =>
            {
                //x.Events = new JwtBearerEvents
                //{
                //    OnTokenValidated = context =>
                //    {
                //        var userId = int.Parse(context.Principal.Identity.Name);
                //        return Task.CompletedTask;
                //    },
                //    //Exception in the moment of authentication
                //    OnAuthenticationFailed = context =>
                //    {
                //        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                //        {
                //            context.Response.Headers.Add("Token-Expired", "true");

                //        }

                //        return Task.CompletedTask;
                //    },
                //};
                var key = Encoding.ASCII.GetBytes(Configuration["Config:Secret"]);
                x.RequireHttpsMetadata = false;
                x.SaveToken = false;

                //Validation of token
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };
            });
            #endregion
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
               
            }

            app.UseDeveloperExceptionPage();
            #region [ SWAGGER ENDPOINTS ]
            app.UseSwagger(c =>
            {
            });

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Syntax Ofesauto Api - Claims Manager");

            });

            #endregion
            #region [ METHOD STATIC FILES ]
            app.UseStaticFiles();
            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"ClaimsManagerFiles")),
                RequestPath = new PathString("/ClaimsManagerFiles"),
            });
            #endregion
            // Save log in file .txt
            #region [ LOGGER FILE ]
            loggerFactory.CreateLogger("Log/Log-{Date}.Txt");
            #endregion

            // Cors
            #region [ CORS ]
            app.UseCors(options =>
            {
                options.WithOrigins("http://localhost:3000", "http://claim-manager.ofesauto.es", "http://admin-manager.ofesauto.es");
                options.AllowAnyMethod();
                options.AllowAnyHeader();
            });
            #endregion
            // Swagger endpoints

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
