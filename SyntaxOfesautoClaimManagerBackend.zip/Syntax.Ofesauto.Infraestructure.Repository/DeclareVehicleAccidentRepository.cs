﻿using Dapper;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Repository
{

    /// <summary>
    /// Method to access the database we use a Dapper micro ORM
    /// </summary>
    /// 
    #region [ DECLAREVEHICLEACCIDENT REPOSITORY ]
    public class DeclareVehicleAccidentRepository : IDeclareVehicleAccidentRepository
    {

        /// <summary>
        /// Object allows accessing the properties of different projects and using the stored procedures
        /// </summary>
        private readonly IConnectionFactory _connectionFactory;

        //public enum ClaimProcessor 
        //{
        //    ClaimProcessorIdEspaña = 2,
        //    ClaimProcessorIdFrancia = 5,

        //}

        #region [ CONSTRUCTOR ]
        public DeclareVehicleAccidentRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }
        #endregion


        #region [ ASYNCHRONOUS METHODS ]

        #region [ VEHICLE METHODS METHODS]
        public async Task<IEnumerable<VehicleCategory>> GetAllVehicleCategoryAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllVehicleCategory";

                var vehicleCategory = await connection.QueryAsync<VehicleCategory>(query, commandType: CommandType.StoredProcedure);

                return vehicleCategory;

            }
        }


        public async Task<IEnumerable<VehicleBrand>> GetAllVehicleBrandAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {

                var query = "GetAllVehicleBrand";

                var vehicleBrand = await connection.QueryAsync<VehicleBrand>(query, commandType: CommandType.StoredProcedure);

                return vehicleBrand;

            }
        }


        public async Task<IEnumerable<VehicleModelByVehicleBrand>> GetVehicleModelByVehicleBrandAsync(string vehicleModelByVehicleBrand)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetVehicleModelByVehicleBrand";
                var parameters = new DynamicParameters();

                parameters.Add("VehicleBrandId", vehicleModelByVehicleBrand);

                var insurerByCountry = await connection.QueryAsync<VehicleModelByVehicleBrand>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return insurerByCountry;

            }
        }
        #endregion


        #region [ DECLARE VEHICLE ACCIDENT METHODS ]
        public async Task<bool> InsertDeclareVehicleAccidentAsync(DeclareVehicleAccident declareVehicleAccident)
        {

            using (var connection = _connectionFactory.GetConnection)
            {

                string claimProcessorId = null;
                string organismId = null;
                string claimantFax = "";

                var query = "InsertDeclareVehicleAccident";
                var parameters = new DynamicParameters();

                parameters.Add("DeclareVehicleAccidentId", declareVehicleAccident.DeclareVehicleAccidentId);
                parameters.Add("UserId", declareVehicleAccident.UserId);
                parameters.Add("ClaimantFax", claimantFax);
                parameters.Add("ClaimantReference", declareVehicleAccident.ClaimantReference);
                parameters.Add("DocumentTypeId", declareVehicleAccident.DocumentTypeId);
                parameters.Add("ApplicationType", declareVehicleAccident.ApplicationType);
                parameters.Add("AccidentDate", DateTime.UtcNow);
                parameters.Add("AccidentCountryId", declareVehicleAccident.AccidentCountryId);
                parameters.Add("AccidentRegionId", declareVehicleAccident.AccidentRegionId);
                parameters.Add("AccidentVersion", declareVehicleAccident.AccidentVersion);
                parameters.Add("ReasonForOpeningId", declareVehicleAccident.ReasonForOpeningId);
                parameters.Add("CauseVehicleCategoryId", declareVehicleAccident.CauseVehicleCategoryId);
                parameters.Add("CauseVehicleBrandId", declareVehicleAccident.CauseVehicleBrandId);
                parameters.Add("CauseVehicleModelId", declareVehicleAccident.CauseVehicleModelId);
                parameters.Add("CauseVehicleRegistration", declareVehicleAccident.CauseVehicleRegistration);
                parameters.Add("CauseCountryRegistrationId", declareVehicleAccident.CauseCountryRegistrationId);
                parameters.Add("CauseInsuranceCompanyId", declareVehicleAccident.CauseInsuranceCompanyId);
                parameters.Add("CauseNumberPolicy", declareVehicleAccident.CauseNumberPolicy);
                parameters.Add("CauseAddress", declareVehicleAccident.CauseAddress);
                parameters.Add("Comments", declareVehicleAccident.Comments);
                parameters.Add("StateId", declareVehicleAccident.StateId);
                parameters.Add("AffectedVehicleBrandId", declareVehicleAccident.AffectedVehicleBrandId);
                parameters.Add("AffectedVehicleCategoryId", declareVehicleAccident.AffectedVehicleCategoryId);
                parameters.Add("AffectedVehicleModelId", declareVehicleAccident.AffectedVehicleModelId);
                parameters.Add("AffectedVehicleRegistration", declareVehicleAccident.AffectedVehicleRegistration);
                parameters.Add("AffectedCountryRegistrationId", declareVehicleAccident.AffectedCountryRegistrationId);
                parameters.Add("AffectedInsuranceCompanyId", declareVehicleAccident.AffectedInsuranceCompanyId);
                parameters.Add("AffectedNumberPolicy", declareVehicleAccident.AffectedNumberPolicy);
                parameters.Add("AffectedName", declareVehicleAccident.AffectedName);
                parameters.Add("AffectedSurname", declareVehicleAccident.AffectedSurname);
                parameters.Add("AffectedAddress", declareVehicleAccident.AffectedAddress);
                parameters.Add("AffectedCityId", declareVehicleAccident.AffectedCityId);
                parameters.Add("AffectedRegionId", declareVehicleAccident.AffectedRegionId);
                parameters.Add("AffectedEmail", declareVehicleAccident.AffectedEmail);
                parameters.Add("AffectedPhoneNumber", declareVehicleAccident.AffectedPhoneNumber);
                parameters.Add("AffectedDamageMaterials", declareVehicleAccident.AffectedDamageMaterials);
                parameters.Add("AffectedDamagePersonals", declareVehicleAccident.AffectedDamagePersonals);
                parameters.Add("AcceptRgpd", declareVehicleAccident.AcceptRgpd);
                parameters.Add("OrganismId", organismId);
                parameters.Add("ClaimsProcessorId", claimProcessorId);
                parameters.Add("CreatedDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);


                var declareAccident = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return declareAccident > 0;

            }
        }


        public async Task<bool> InsertDeclareVehicleAccidentAttachmentsAsync(CommunicationAttachments declareVehicleAccidentAttachments)
        {

            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "InsertDeclareVehicleAccidentAttachments";
                var parameters = new DynamicParameters();

                parameters.Add("AttachmentsId", declareVehicleAccidentAttachments.AttachmentId);
                parameters.Add("DeclareVehicleAccidentId", declareVehicleAccidentAttachments.CommunicationsHistoryId);
                parameters.Add("AttachmentDate", Convert.ToDateTime(declareVehicleAccidentAttachments.AttachmentDate));
                parameters.Add("AttachmentFileName", declareVehicleAccidentAttachments.AttachmentFileName);
                parameters.Add("AttachmentPath", declareVehicleAccidentAttachments.AttachmentPath);
                parameters.Add("AttachmentDescription", declareVehicleAccidentAttachments.AttachmentDescription);
                parameters.Add("CreatedDate", Convert.ToDateTime(declareVehicleAccidentAttachments.AttachmentDate));
                parameters.Add("UpdatedDate", Convert.ToDateTime(declareVehicleAccidentAttachments.AttachmentDate));

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<bool> InsertDeclareVehicleAccidentActionsAsync(DeclareVehicleAccidentActions declareVehicleAccidentActions)
        {

            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "InsertActionsHistory";
                var parameters = new DynamicParameters();
                int ofesautoProcessId = 1;

                parameters.Add("ActionHistoryId", declareVehicleAccidentActions.ActionId);
                parameters.Add("OfesautoProcessId", ofesautoProcessId);
                parameters.Add("StateId", declareVehicleAccidentActions.StateId);
                parameters.Add("Observations", declareVehicleAccidentActions.Observations);
                parameters.Add("AttachmentId", declareVehicleAccidentActions.AttachmentId);
                parameters.Add("UserId", declareVehicleAccidentActions.UserId);
                parameters.Add("ClaimProcessorId", null);
                parameters.Add("ActionDate", DateTime.UtcNow);
                parameters.Add("ActionTypeId", declareVehicleAccidentActions.ActionTypeId);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }


        public async Task<IEnumerable<StateAccident>> GetAllStateAccidentAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllState";

                var stateAccident = await connection.QueryAsync<StateAccident>(query, commandType: CommandType.StoredProcedure);

                return stateAccident;

            }
        }


        public async Task<ViewClaim> GetViewClaimByIdAsync(string viewClaimById)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetClaimsManagerById";
                var parameters = new DynamicParameters();

                parameters.Add("DeclareVehicleAccidentId", viewClaimById);

                var viewClaim = await connection.QuerySingleAsync<ViewClaim>(query, param: parameters, commandType: CommandType.StoredProcedure);


                return viewClaim;

            }
        }

        public async Task<string> GetDeclareVehicleAccidentById(int viewClaimById)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetDeclareVehicleAccidentById";
                var parameters = new DynamicParameters();

                parameters.Add("Id", viewClaimById);

                var viewClaim = await connection.QueryFirstAsync<string>(query, param: parameters, commandType: CommandType.StoredProcedure);
                return viewClaim;

            }
        }
        #endregion


        #region [ INVESTIGATION RECORD METHOD ]
        public async Task<bool> InsertInvestigationRecordAsync(InvestigationRecord investigationRecord)
        {

            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "InsertInvestigationRecord";
                var parameters = new DynamicParameters();

                parameters.Add("InvestigationRecordId", investigationRecord.InvestigationRecordId);
                parameters.Add("InvestigationRecordNumber", investigationRecord.InvestigationRecordNumber);
                parameters.Add("InvestigationRecordDateHigh", DateTime.UtcNow);
                parameters.Add("DeclareVehicleAccidentId", investigationRecord.DeclareVehicleAccidentId);
                parameters.Add("StateId", investigationRecord.StateId);
                parameters.Add("InvestigationRecordClosingDate", DateTime.UtcNow);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }
        #endregion


        #region [ COMMUNICATIONS HISTORY METHODS ]
        public async Task<bool> InsertCommunicationsHistoryAsync(CommunicationsHistory communicationsHistory)
        {

            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "InsertCommunicationsHistory";
                var parameters = new DynamicParameters();

                parameters.Add("CommunicationId", communicationsHistory.CommunicationId);
                parameters.Add("DeclareVehicleAccidentId", communicationsHistory.ActionHistoryId);
                parameters.Add("CommunicationDate", DateTime.UtcNow);
                parameters.Add("CommunicationTo", communicationsHistory.CommunicationTo);
                parameters.Add("CommunicationSubject", communicationsHistory.CommunicationSubject);
                parameters.Add("CommunicationText", communicationsHistory.CommunicationText);
                parameters.Add("CommunicationFileNameHtml", communicationsHistory.CommunicationFileNameHtml);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);
                parameters.Add("CommunicationFrom", communicationsHistory.CommunicationFrom);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }
        #endregion


        #region [ ORGANISM METHODS ]
        public async Task<bool> InsertOrganismAsync(Organism organism)
        {

            using (var connection = _connectionFactory.GetConnection)
            {
                // Asignado a particulares
                int organismTypeId = 6;

                var query = "InsertOrganism";
                var parameters = new DynamicParameters();

                parameters.Add("OrganismId", organism.OrganismId);
                parameters.Add("OrganismTypeId", organismTypeId);
                parameters.Add("CountryId", organism.CountryId);
                parameters.Add("RegionId", organism.RegionId);
                parameters.Add("CityId", organism.CityId);
                parameters.Add("OrganismName", organism.OrganismName);
                parameters.Add("OrganismLastName", organism.OrganismLastName);
                parameters.Add("OrganismAddress", organism.OrganismAddress);
                parameters.Add("DocumentTypeId", organism.DocumentTypeId);
                parameters.Add("OrganismPostalCode", organism.OrganismPostalCode);
                parameters.Add("OrganismCIF", organism.OrganismCIF);
                parameters.Add("OrganismWebSite", organism.OrganismWebSite);
                parameters.Add("OrganismCode", organism.OrganismCode);
                parameters.Add("OrganismReasonLowId", null);
                parameters.Add("OrganismLowDate", DateTime.UtcNow);
                parameters.Add("OrganismIdPassTo", organism.OrganismIdPassTo = null);
                parameters.Add("OrganismHightDate", DateTime.UtcNow);
                parameters.Add("OrganismSubTypeId", organism.OrganismSubTypeId);
                parameters.Add("CreateDate", DateTime.UtcNow);
                parameters.Add("UpdateDate", DateTime.UtcNow);

                var result = await connection.ExecuteAsync(query, param: parameters, commandType: CommandType.StoredProcedure);

                return result > 0;

            }
        }
        #endregion


        #region [ INSURER METHODS ]
        public async Task<IEnumerable<InsurerByCountry>> GetInsurerByCountryIdAsync(string insurerByCountryId)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetInsurerByCountry";
                var parameters = new DynamicParameters();

                parameters.Add("InsurerCountryId", insurerByCountryId);

                var insurerByCountry = await connection.QueryAsync<InsurerByCountry>(query, param: parameters, commandType: CommandType.StoredProcedure);

                return insurerByCountry;

            }
        }
        #endregion


        #region [ CLAIMS MANAGER METHODS ]
        public async Task<IEnumerable<GetAllClaimsManager>> GetAllClaimsManagerAsync()
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "GetAllClaimsManager";

                var claimsManagers = await connection.QueryAsync<GetAllClaimsManager>(query, commandType: CommandType.StoredProcedure);

                return claimsManagers;

            }
        }
        #endregion

        #endregion
    }
}
#endregion