﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class SettingsDTO
    {
        public int SettingId { get; set; }        
        public string Name { get; set; }        
        public string Value { get; set; }        
        public string Description { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
