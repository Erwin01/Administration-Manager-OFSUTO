﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{


    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class StateActionHistoryDTO
    {

        [Key]
        public int StateId { get; set; }

        [Display(Name = "Status Name")]
        public string StateName { get; set; }

        [Display(Name = "Status Name English")]
        public string StateNamEnglish { get; set; }


        public int UserId { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }


    }

}