﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{

    #region [ VEHICLE CATEGORY DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class VehicleCategoryDTO
    {

        public int VehicleCategoryId { get; set; }

        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }

        [Display(Name = "Category Name English")]
        public string CategoryNamEnglish { get; set; }
    
    }
    #endregion

}
