﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{


    #region [ View Claim DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    /// 
    public class ViewClaimDTO
    {


        [Display(Name = "Claimant Fax")]
        public string ClaimantFax { get; set; }

        [Display(Name = "Claimant Reference")]
        public string ClaimantReference { get; set; }

        public string DocumentTypeName { get; set; }

        [Display(Name = "Aplication Type")]
        public string ApplicationType { get; set; }

        [Display(Name = "Accident Date")]
        public DateTime AccidentDate { get; set; }

        public string AccidentCountryId { get; set; }

        public string AccidentRegionId { get; set; }

        [Display(Name = "Accident Version")]
        public string AccidentVersion { get; set; }

        public int ReasonForOpeningId { get; set; }

        public string CauseVehicleCategoryBrandId { get; set; }

        public string CauseVehicleBrandId { get; set; }

        public string CauseVehicleModelId { get; set; }

        [Display(Name = "Cause Vehicle Registration")]
        public string CauseVehicleRegistration { get; set; }

        public string CauseCountryRegistrationId { get; set; }

        public string CauseInsurerCompanyId { get; set; }

        [Display(Name = "Cause Number Policy")]
        public string CauseNumberPolicy { get; set; }

        [Display(Name = "Cause Address")]
        public string CauseAddress { get; set; }

        [Display(Name = "Comments")]
        public string Comments { get; set; }

        public string StateId { get; set; }

        public string AffectedVehicleBrandId { get; set; }

        public string AffectedVehicleCategoryId { get; set; }

        public string AffectedVehicleModelId { get; set; }

        [Display(Name = "Affected Vehicle Registration")]
        public string AffectedVehicleRegistration { get; set; }

        public string AffectedCountryRegistrationId { get; set; }

        public string AffectedInsuranceCompanyId { get; set; }

        [Display(Name = "Affected Number Policy")]
        public string AffectedNumberPolicy { get; set; }

        [Display(Name = "Affected Name")]
        public string AffectedName { get; set; }

        [Display(Name = "Affected Surname")]
        public string AffectedSurname { get; set; }

        [Display(Name = "Affected Address")]
        public string AffectedAddress { get; set; }

        public string AffectedCityId { get; set; }

        public string AffectedRegionId { get; set; }

        [Display(Name = "Affected Email")]
        public string AffectedEmail { get; set; }

        [Display(Name = "Affected Phone Number")]
        public string AffectedPhoneNumber { get; set; }

        [Display(Name = "Affected Damage Materials")]
        public string AffectedDamageMaterials { get; set; }

        [Display(Name = "Affected Damage Personals")]
        public string AffectedDamagePersonals { get; set; }

        public string AttachmentId { get; set; }

        public string AttachmentFileName { get; set; }

        [Display(Name = "Accept RGPD")]
        public string AcceptRgpd { get; set; }
    }
    #endregion
}
