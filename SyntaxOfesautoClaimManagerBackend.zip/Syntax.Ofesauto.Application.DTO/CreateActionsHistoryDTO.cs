﻿using System;
using System.Collections.Generic;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class CreateActionsHistoryDTO
    {
        

        #region [ ACTIONS HISTORY DTO ]
        /// <summary>
        /// Method that allows placing only the attributes that are going to be exposed
        /// </summary>
        public int OfesautoProcessId { get; set; }
        public int IdentificationRegister { get; set; }
        public int StateId { get; set; }
        public string Observations { get; set; }
        public int ActionTypeId { get; set; }
        public DateTime ActionDate { get; set; } = DateTime.Now;
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime UpdateDate { get; set; } = DateTime.Now;
        public string SubjectCommunication { get; set; }
        public string Message { get; set; }
        /** Relations dtos*/
        public List<FileUploadDto> Files { get; set; }
       
    }
    #endregion
}
