﻿using System;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class ClaimProcessorEmailRedirectDTO
    {
        public int ClaimProcessorId { get; set; }             
        public string ClaimProcessorEmailRedirect { get; set; }            
        public DateTime UpdateDate { get; set; }
    }
}