﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class FileUploadDto
    {
        public IFormFile file { get; set; }
        public string fileName { get; set; }
        public string[] AllowedExtensions { get; set; }
        public string SavePath { get; set; }
    }
}
