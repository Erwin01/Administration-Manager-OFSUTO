﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class AssignClaimDTO
    {
        [Required]
        public int ProcessorId { get; set; }
        [Required]
        public int ClaimId { get; set; }

        public int UserId { get; set; }
        public string Email { get; set; }
        public int ActionTypeId { get; set; }
        public int OffesautoProcessId { get; set; }
    }
}
