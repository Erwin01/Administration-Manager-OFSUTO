﻿using System;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class ActionTypeDTO
    {
        public int ActionTypeId { get; set; }
        
        public string ActionTypeName { get; set; }
        
        public string ActionTypeDescription { get; set; }
        
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public bool SendCommunication { get; set; }
    }
}