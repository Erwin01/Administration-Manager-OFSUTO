﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
   public class WhiteLetter
    {
        public string EmailLetter { get; set; }
        public string PasswordLetter { get; set; }
    }
}
