﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{

    #region [ VEHICLE MODEL DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class VehicleModelDTO
    {

        public int VehicleModelId { get; set; }

        [Display(Name = "Model Name")]
        public string ModelName { get; set; }

        [Display(Name = "Model Name English")]
        public string ModelNamEnglish { get; set; }

    }
    #endregion

}
