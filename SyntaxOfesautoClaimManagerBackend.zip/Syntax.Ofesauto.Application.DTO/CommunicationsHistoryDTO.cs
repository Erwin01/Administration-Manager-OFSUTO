﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class CommunicationsHistoryDTO
    {
        public CommunicationsHistoryDTO()
        {

        }

        public CommunicationsHistoryDTO(int actionHistoryId, string communicationTo, string communicationSubject,
                                        string communicationText, string communicationFileNameHtml, string communicationFrom)
        {
            ActionHistoryId = actionHistoryId;
            CommunicationTo = communicationTo;
            CommunicationSubject = communicationSubject;
            CommunicationText = communicationText;
            CommunicationFileNameHtml = communicationFileNameHtml;
            CommunicationFrom = communicationFrom;
            CommunicationDate = DateTime.UtcNow;
            CreateDate = DateTime.UtcNow;
            UpdateDate = DateTime.UtcNow;
        }
        #region [ COMMUNICATIONS HISTORY DTO ]
        /// <summary>
        /// Method that allows placing only the attributes that are going to be exposed
        /// </summary>
        /// 
        //public int CommunicationId { get; set; }
        public int CommunicationId { get; set; }

        public int ActionHistoryId { get; set; }

        public DateTime CommunicationDate { get; set; }
        public string CommunicationTo { get; set; }
        public string CommunicationSubject { get; set; }
        public string CommunicationText { get; set; }
        public string CommunicationFileNameHtml { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public string CommunicationFrom { get; set; }
        public List<CommunicationAttachmentsDTO> CommunicationAttachments { get; set; }
        #endregion
    }
}
