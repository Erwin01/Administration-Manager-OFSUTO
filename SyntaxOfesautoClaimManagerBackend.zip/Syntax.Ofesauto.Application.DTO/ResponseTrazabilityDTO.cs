﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
   public class ResponseTrazabilityDTO
    {
        public int ActionHistoryId { get; set; }

        public int ActionTypeId { get; set; }
        public int IdentificationRegister { get; set; }
        public string Reason { get; set; }
        public string ActionType { get; set; }

        public int OfesautoProcessId { get; set; }
        public int StateId { get; set; }
        public int UserId { get; set; }
        public string State { get; set; }
        public string MadeBy { get; set; }
        public DateTime ActionDate { get; set; }
        public string Documents { get; set; }
        public List<CommunicationAttachmentsDTO> Attachments { get; set; } = new List<CommunicationAttachmentsDTO>();
    }
}
