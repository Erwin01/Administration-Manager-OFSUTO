﻿using System;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class ClaimProcessorCountryDTO
    {
        public int CountryClaimProcessorId { get; set; }        
        public int ClaimProcessorId { get; set; }        
        public int AccidentCountryId { get; set; }        
        public int CauseRegistrationCountryId { get; set; }        
        public int OpeningReasonId { get; set; }
        public int Userid { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime UpdateDate { get; set; } = DateTime.Now;
    }
}