﻿using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{

    #region [ VEHICLE BRAND DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    /// 
    public class VehicleBrandDTO
    {
       
        public int VehicleBrandId { get; set; }

        [Display(Name = "Brand Name")]
        public string BrandName { get; set; }

        [Display(Name = "Brand Name English")]
        public string BrandNamEnglish { get; set; }

    }
    #endregion

}