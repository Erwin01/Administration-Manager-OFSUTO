﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{

    #region [ DECLARE VEHICLE ACCIDENT ATTACHMENTS DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    /// 
    public class CommunicationAttachmentsDTO
    {
        public int CommunicationAttachmentsId { get; set; }
        
        public int AttachmentId { get; set; }

        public int CommunicationsHistoryId { get; set; }

        [Display(Name = "Attachment Date")]
        public DateTime AttachmentDate { get; set; }

        [Display(Name = "Attachment FileName")]
        public string AttachmentFileName { get; set; }

        [Display(Name = "Attachment Path")]
        public string AttachmentPath { get; set; }

        [Display(Name = "Attachment Description")]
        public string AttachmentDescription { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdateDate { get; set; }

    }
    #endregion

}
