﻿using System;
using System.Collections.Generic;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class ResponseActionsHistoryDTO
    {


        public int DeclareVehicleAccidentId { get; set; }
        public string ClaimantFax { get; set; }
        public string ClaimantReference { get; set; }

        public int DocumentTypeId { get; set; }
        public string ApplicationType { get; set; }
        public DateTime AccidentDate { get; set; }

        public int AccidentCountryId { get; set; }

        public int AccidentRegionId { get; set; }
        public string AccidentVersion { get; set; }

        public int ReasonForOpeningId { get; set; }

        public Byte CauseVehicleCategoryId { get; set; }

        public int CauseVehicleBrandId { get; set; }

        public int CauseVehicleModelId { get; set; }
        public string CauseVehicleRegistration { get; set; }

        public Byte CauseCountryRegistrationId { get; set; }

        public int CauseInsuranceCompanyId { get; set; }
        public string CauseNumberPolicy { get; set; }
        public string CauseAddress { get; set; }
        public string Comments { get; set; }

        public Byte StateId { get; set; }

        public int AffectedVehicleBrandId { get; set; }

        public Byte AffectedVehicleCategoryId { get; set; }

        public int AffectedVehicleModelId { get; set; }
        public string AffectedVehicleRegistration { get; set; }

        public int AffectedCountryRegistrationId { get; set; }

        public int AffectedInsuranceCompanyId { get; set; }
        public string AffectedNumberPolicy { get; set; }
        public string AffectedName { get; set; }
        public string AffectedSurname { get; set; }

        public string AffectedAddress { get; set; }

        public int AffectedCityId { get; set; }

        public int AffectedRegionId { get; set; }
        public string AffectedEmail { get; set; }
        public string AffectedPhoneNumber { get; set; }
        public bool AffectedDamageMaterials { get; set; }
        public bool AffectedDamagePersonals { get; set; }
        public bool AcceptRgpd { get; set; }
        public int UserId { get; set; }
        public int? ClaimsProcessorId { get; set; }
        public string EmailSender { get; set; }
        public DateTime UpdateDate { get; set; } = DateTime.UtcNow;
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public List<ActionsHistoryDTO> ActionHistory { get; set; }

    }
   
}
