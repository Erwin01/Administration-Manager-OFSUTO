﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{


    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class UserDTO
    {

        public int UserId { get; set; }

        public int UserTypeId { get; set; }
        public string UserName { get; set; }
        public string LastName { get; set; }
        public int DocumentTypeId { get; set; }
        public string UserIdNumber { get; set; }

        public string UserAddress { get; set; }
        public int CountryId { get; set; }

        public int RegionId { get; set; }
        public int CitytId { get; set; }
        public string PostalCode { get; set; }
        public int PhoneCodeId { get; set; }
        public string PhoneNumber { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        public string Password { get; set; }
        public string VerificationCode { get; set; }
        public string Photo { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }


    }

}