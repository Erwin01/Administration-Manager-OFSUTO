﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{


    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class OfesautoProcessDTO
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string NamEnglish { get; set; }
        public string Description { get; set; }


        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }


    }

}