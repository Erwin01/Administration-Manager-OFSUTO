﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{
    public class GetClaimsManagerTrazabilityDTO
    {

        public int DeclareVehicleAccidentId { get; set; }

        [Display(Name = "Accident Date")]
        public DateTime AccidentDate { get; set; }


    }
}
