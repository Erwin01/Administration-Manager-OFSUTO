﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Application.DTO
{

    #region [ INSURER DTO ]
    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    public class InsurerDTO
    {
        
        public int InsurerId { get; set; }

        [Display(Name = "Insurer Code")]
        public int InsurerCode { get; set; }

        [Display(Name = "Insurer Name")]
        public string InsurerName { get; set; }

        [Display(Name = "Insurer Address")]
        public string InsurerAddress { get; set; }

        [Display(Name = "Insurer Postal Code")]
        public int InsurerPostalCode { get; set; }

        public int InsurerCountryId { get; set; }

        [Display(Name = "Insurer Phone")]
        public int InsurerPhone { get; set; }

        [Display(Name = "Insurer Email")]
        public string InsurerEmail { get; set; }

        [Display(Name = "Insurer Fax")]
        public int InsurerFax { get; set; }

        [Display(Name = "Insurer Nif")]
        public string InsurerNif { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdatedDate { get; set; }

    }
    #endregion

}
