﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    [Keyless]
    public class ResponsesJson
    {
        public string data { get; set; }
    }
}
