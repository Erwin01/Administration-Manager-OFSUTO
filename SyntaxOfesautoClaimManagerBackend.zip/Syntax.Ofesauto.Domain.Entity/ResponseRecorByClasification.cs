﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{

    #region [ DECLARE VEHICLE ACCIDENT DTO ]

    /// <summary>
    /// Method that allows placing only the attributes that are going to be exposed
    /// </summary>
    ///  [Keyless]
    ///  
    [Keyless]
    public class ResponseRecorByClasification
    {

        public int DeclareVehicleAccidentId { get; set; }

        public DateTime AccidentDate { get; set; }
        public string Claimant { get; set; }
        public int AccidentCountryId { get; set; }
        public string AccidentCountry { get; set; }
        [Display(Name = "Accident Version")]
        public string AccidentVersion { get; set; }
        public int ReasonForOpeningId { get; set; }
        public string AffectedCountry { get; set; }
        public string ActionType { get; set; }
        public string DocumentTypeName { get; set; }
        public string UserNumber { get; set; }
        public string CauseCountry { get; set; }
        public string Proccessor { get; set; }
        public string State { get; set; }
        //public string EmailSender { get; set; }
        public int UserId { get; set; }
        public int? ClaimsProcessorId { get; set; }
        public DateTime UpdateDate { get; set; } = DateTime.UtcNow;
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }
    #endregion

}
