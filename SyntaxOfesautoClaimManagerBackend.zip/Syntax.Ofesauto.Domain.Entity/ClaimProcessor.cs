﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class ClaimProcessor
    {
        [Key]
        public int ClaimProcessorId { get; set; }
        [Required]
        public int UserId { get; set; }
        [Required]
        public string ClaimProcessorName { get; set; }
        [Required]
        public string ClaimProcessorEmail { get; set; }
        public string ClaimProcessorEmailRedirect { get; set; }
        public string ClaimProcessorCodeUser { get; set; }
        [Required]
        public Byte StateId { get; set; }
        [Required]
        public DateTime CreateDate { get; set; }
        [Required]
        public DateTime UpdateDate { get; set; }
        
    }
}
