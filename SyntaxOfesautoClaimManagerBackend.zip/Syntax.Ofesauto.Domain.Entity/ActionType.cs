﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class ActionType
    {
        public int ActionTypeId { get; set; }
        [Required]
        public string ActionTypeName { get; set; }
        [Required]
        public string ActionTypeDescription { get; set; }
        [Required]
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public bool SendCommunication { get; set; }
    }
}
