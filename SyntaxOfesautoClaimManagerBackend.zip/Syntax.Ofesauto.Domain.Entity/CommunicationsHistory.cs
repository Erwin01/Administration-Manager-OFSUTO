﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class CommunicationsHistory
    {

        [Key]
        public int CommunicationId { get; set; }
        [Required]
        public int ActionHistoryId { get; set; }
        [Required]
        public DateTime CommunicationDate { get; set; }
        public string CommunicationTo { get; set; }
        public string CommunicationSubject { get; set; }
        public string CommunicationText { get; set; }
        public string CommunicationFileNameHtml { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public string CommunicationFrom { get; set; }
        [ForeignKey("ActionHistoryId")]
        public  ActionsHistory ActionsHistory { get; set; }
        public List<CommunicationAttachments> CommunicationAttachments { get; set; }
    }
}
