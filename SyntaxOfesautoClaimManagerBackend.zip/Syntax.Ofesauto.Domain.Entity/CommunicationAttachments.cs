﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class CommunicationAttachments
    {
        [Key]
        public int CommunicationAttachmentsId { get; set; }
        [Required]
        public int AttachmentId { get; set; }
        [Required]
        public int CommunicationsHistoryId { get; set; }

        [Display(Name = "Attachment Date")]
        public DateTime AttachmentDate { get; set; }

        [Display(Name = "Attachment FileName")]
        [Required]
        public string AttachmentFileName { get; set; }

        [Display(Name = "Attachment Path")]
        [Required]
        public string AttachmentPath { get; set; }

        [Display(Name = "Attachment Description")]
        public string AttachmentDescription { get; set; }

        [Display(Name = "Created Date")]
        [Required]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdateDate { get; set; }
        public  CommunicationsHistory CommunicationsHistory { get; set; }
    }
}
