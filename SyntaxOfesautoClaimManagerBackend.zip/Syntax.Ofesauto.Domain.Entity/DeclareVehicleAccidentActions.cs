﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class DeclareVehicleAccidentActions
    {

        public int ActionId { get; set; }

        public int DeclareVehicleAccidentId { get; set; }

       // public int OfesautoProcessId { get; set; }

        public int StateId { get; set; }

        [Display(Name = "Observations")]
        public string Observations { get; set; }

        public int AttachmentId { get; set; }

        public int UserId { get; set; }

        public int ClaimProcessorId { get; set; }

        [Display(Name = "Action Date")]
        public DateTime ActionDate { get; set; }

        public int ActionTypeId { get; set; }
        //public int? InvestigationId { get; set; }
        //public int? IncidentId { get; set; }
        //public int? CompensationId { get; set; }

        
        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreatedDate { get; set; }


        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdateDate { get; set; }
    }
}
