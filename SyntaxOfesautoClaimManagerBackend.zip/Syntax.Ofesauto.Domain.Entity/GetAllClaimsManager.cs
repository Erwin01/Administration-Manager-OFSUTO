﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class GetAllClaimsManager
    {

        public DateTime AccidentDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ClaimantReference { get; set; }
        public string CauseVehicleRegistration { get; set; }
        public string StateName { get; set; }
        public DateTime CommunicationDate { get; set; }
        public string CommunicationSubject { get; set; }
        public string CommunicationFileNameHtml { get; set; }
        public string CommunicationFrom { get; set; }
    }
}
