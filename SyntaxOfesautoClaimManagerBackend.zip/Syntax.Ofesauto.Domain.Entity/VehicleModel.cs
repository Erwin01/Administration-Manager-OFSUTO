﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class VehicleModel
    {
        [Key]
        public int VehicleModelId { get; set; }

        [Display(Name = "Model Name")]
        [Required(ErrorMessage = "The field is mandatory")]
        public string ModelName { get; set; }

        [Display(Name = "Category Name English")]
        public string ModelNamEnglish { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Updated Date")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd hh:mm}", ApplyFormatInEditMode = false)]
        public DateTime UpdateDate { get; set; }

    }
}
