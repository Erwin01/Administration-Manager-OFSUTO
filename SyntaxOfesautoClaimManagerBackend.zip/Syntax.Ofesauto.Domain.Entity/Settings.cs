﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Syntax.Ofesauto.ClaimsManager.Domain.Entity
{
    public class Settings
    {
        [Key]
        [Required]
        public int SettingId { get; set; }
        [Required]
        public string Name { get; set; }       
        [Required]
        public string Value { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        [DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }

    }
}
