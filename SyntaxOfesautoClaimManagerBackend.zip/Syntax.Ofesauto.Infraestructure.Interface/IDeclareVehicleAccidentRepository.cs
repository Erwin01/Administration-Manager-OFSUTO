﻿using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface
{

    /// <summary>
    /// Method that allows you to perform the CRUD
    /// </summary>
    /// 
    #region [ DECLAREVEHICLEACCIDENT REPOSITORY ]
    public interface IDeclareVehicleAccidentRepository
    {

        #region [ ASYNCHRONOUS METHODS ]

        #region [ VEHICLE MEHODS ]
        Task<IEnumerable<VehicleCategory>> GetAllVehicleCategoryAsync();
        Task<IEnumerable<VehicleBrand>> GetAllVehicleBrandAsync();
        Task<IEnumerable<VehicleModelByVehicleBrand>> GetVehicleModelByVehicleBrandAsync(string insurerByCountryId);
        #endregion


        #region [ DECLARE VEHICLE ACCIDENT METHODS ]
        Task<bool> InsertDeclareVehicleAccidentAsync(DeclareVehicleAccident declareVehicleAccident);
        Task<string> GetDeclareVehicleAccidentById(int declareVehicleAccident);
        Task<bool> InsertDeclareVehicleAccidentAttachmentsAsync(CommunicationAttachments declareVehicleAccidentAttachments);
        Task<bool> InsertDeclareVehicleAccidentActionsAsync(DeclareVehicleAccidentActions declareVehicleAccidentActions);
        Task<IEnumerable<StateAccident>> GetAllStateAccidentAsync();
        Task<ViewClaim> GetViewClaimByIdAsync(string viewClaimById);

        #endregion


        #region [ COMMUNICATIONS HISTORY ]
        Task<bool> InsertCommunicationsHistoryAsync(CommunicationsHistory communicationsHistory);
        #endregion


        #region [ INVESTIGATION RECORD METHODS]
        Task<bool> InsertInvestigationRecordAsync(InvestigationRecord investigationRecord);
        #endregion


        #region [ ORGANISM METHODS ]
        Task<bool> InsertOrganismAsync(Organism organism);
        #endregion


        #region [ INSURER METHODS ]
        Task<IEnumerable<InsurerByCountry>> GetInsurerByCountryIdAsync(string insurerByCountryId);
        #endregion


        #region [ CLAIMS MANAGER ]
        Task<IEnumerable<GetAllClaimsManager>> GetAllClaimsManagerAsync();
        #endregion

        #endregion

    }
    #endregion
}
