﻿using System.Linq;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main
{
    public class OfesautoProcessApplication : IOfesautoProcessApplication
    {
        private readonly IOfesautoProcessDomain _repository;
        private readonly IAppLogger<OfesautoProcessApplication> _logger;
        public OfesautoProcessApplication(IOfesautoProcessDomain repository,
            IAppLogger<OfesautoProcessApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<OfesautoProcessDTO>> Add(OfesautoProcessDTO obj)
        {           
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<OfesautoProcessDTO, OfesautoProcess>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.Id = add.Id;
                return Response<OfesautoProcessDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OfesautoProcessDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.Id > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);
              
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<OfesautoProcessDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<OfesautoProcess, OfesautoProcessDTO>.ConvertList2(ListData);
                return Response<List<OfesautoProcessDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<OfesautoProcessDTO>>.Sucess(null, ex.Message, false);
            }
        }
       
        public async Task<Response<OfesautoProcessDTO>> GetById(int id)
        {
            Response<OfesautoProcessDTO> ListRta = new Response<OfesautoProcessDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<OfesautoProcess, OfesautoProcessDTO>.Convert(ListData);
                return Response<OfesautoProcessDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<OfesautoProcessDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<OfesautoProcessDTO>> GetByNameOfesautoProcess(string name)
        {
            Response<OfesautoProcessDTO> ListRta = new Response<OfesautoProcessDTO>();
            try
            {

                var ListData = await _repository.GetByParamFirst(c => c.Name == name);
                ListRta.Data = Infraestructure.Data.AutoMapp<OfesautoProcess, OfesautoProcessDTO>.Convert(ListData);
                return Response<OfesautoProcessDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<OfesautoProcessDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<OfesautoProcessDTO>>> GetByParam(Func<OfesautoProcessDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

      

        public async Task<Response<OfesautoProcessDTO>> Update(OfesautoProcessDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<OfesautoProcessDTO, OfesautoProcess>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<OfesautoProcessDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<OfesautoProcessDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
