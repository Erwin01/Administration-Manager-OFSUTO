﻿using AutoMapper;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main
{
    public class DeclareVehicleAccidentApplication : IDeclareVehicleAccidentApplication
    {

        /// <summary>
        /// Variables globlals
        /// </summary>
        private readonly IDeclareVehicleAccidentDomain _declareVehicleAccidentDomain;
        private readonly IMapper _mapper;
        private readonly IAppLogger<DeclareVehicleAccidentApplication> _logger;

        /// <summary>
        /// This method allows to perform dependency injection
        /// </summary>
        /// <param name="declareVehicleAccidentDomain"></param>
        /// <param name="imapper"></param>
        public DeclareVehicleAccidentApplication(IDeclareVehicleAccidentDomain declareVehicleAccidentDomain, IMapper imapper, IAppLogger<DeclareVehicleAccidentApplication> appLogger)
        {
            _declareVehicleAccidentDomain = declareVehicleAccidentDomain;
            _mapper = imapper;
            _logger = appLogger;
        }


        #region [ ASYNCHRONOUS METHODS ]


        #region [ VEHICLE METHODS ]
        /// <summary>
        /// Get All Vehicles Categorys
        /// </summary>
        /// <returns></returns>
        public async Task<Response<IEnumerable<VehicleCategoryDTO>>> GetAllVehicleCategoryAsync()
        {
            var response = new Response<IEnumerable<VehicleCategoryDTO>>();

            try
            {

                var vehicleCategory = await _declareVehicleAccidentDomain.GetAllVehicleCategoryAsync();
                response.Data = _mapper.Map<IEnumerable<VehicleCategoryDTO>>(vehicleCategory);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get All Vehicles Brands
        /// </summary>
        /// <returns></returns>
        public async Task<Response<IEnumerable<VehicleBrandDTO>>> GetAllVehicleBrandAsync()
        {
            var response = new Response<IEnumerable<VehicleBrandDTO>>();

            try
            {

                var vehicleBrand = await _declareVehicleAccidentDomain.GetAllVehicleBrandAsync();
                response.Data = _mapper.Map<IEnumerable<VehicleBrandDTO>>(vehicleBrand);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// Get Vehicles Model By Vehicle Brand
        /// </summary>
        /// <param name="vehicleModelByVehicleBrand"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<VehicleModelByVehicleBrandDTO>>> GetVehicleModelByVehicleBrandAsync(string vehicleModelByVehicleBrand)
        {
            var response = new Response<IEnumerable<VehicleModelByVehicleBrandDTO>>();

            try
            {

                var vehicleModelByBrand = await _declareVehicleAccidentDomain.GetVehicleModelByVehicleBrandAsync(vehicleModelByVehicleBrand);
                response.Data = _mapper.Map<IEnumerable<VehicleModelByVehicleBrandDTO>>(vehicleModelByBrand);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ DECLARE VEHICLE ACCIDENT METHODS]
        /// <summary>
        /// Insert Declare Vehicle Accident
        /// </summary>
        /// <param name="declareVehicleAccidentDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> InsertDeclareVehicleAccidentAsync(GetClaimsManagerTrazabilityDTO declareVehicleAccidentDTO)
        {
            var response = new Response<bool>();

            try
            {
                var declareVehicleAccident = _mapper.Map<DeclareVehicleAccident>(declareVehicleAccidentDTO);
                response.Data = await _declareVehicleAccidentDomain.InsertDeclareVehicleAccidentAsync(declareVehicleAccident);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Insert Declare Vehicle Accident Attachments
        /// </summary>
        /// <param name="declareVehicleAccidentAttachmentsDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> InsertDeclareVehicleAccidentAttachmentsAsync(CommunicationAttachmentsDTO declareVehicleAccidentAttachmentsDTO)
        {
            var response = new Response<bool>();

            try
            {
                var declareVehicleAccidentAttachment = _mapper.Map<CommunicationAttachments>(declareVehicleAccidentAttachmentsDTO);
                response.Data = await _declareVehicleAccidentDomain.InsertDeclareVehicleAccidentAttachmentsAsync(declareVehicleAccidentAttachment);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Insert Actions History
        /// </summary>
        /// <param name="declareVehicleAccidentActionsDTO"></param>
        /// <returns> Action </returns>
        public async Task<Response<bool>> InsertDeclareVehicleAccidentActionsAsync(DeclareVehicleAccidentActionsDTO declareVehicleAccidentActionsDTO)
        {
            var response = new Response<bool>();

            try
            {
                var declareVehicleAccidentActions = _mapper.Map<DeclareVehicleAccidentActions>(declareVehicleAccidentActionsDTO);
                response.Data = await _declareVehicleAccidentDomain.InsertDeclareVehicleAccidentActionsAsync(declareVehicleAccidentActions);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        /// <summary>
        /// Get All States Accident
        /// </summary>
        /// <returns></returns>
        public async Task<Response<IEnumerable<StateAccidentDTO>>> GetAllStateAccidentAsync()
        {
            var response = new Response<IEnumerable<StateAccidentDTO>>();

            try
            {

                var stateAccident = await _declareVehicleAccidentDomain.GetAllStateAccidentAsync();
                response.Data = _mapper.Map<IEnumerable<StateAccidentDTO>>(stateAccident);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }

        /// <summary>
        /// View Claim By Id
        /// </summary>
        /// <param name="organismId"></param>
        /// <returns></returns>
        public async Task<Response<ViewClaimDTO>> GetViewClaimByIdAsync(string viewClaimById)
        {
            var response = new Response<ViewClaimDTO>();

            try
            {

                var viewClaim = await _declareVehicleAccidentDomain.GetViewClaimByIdAsync(viewClaimById);
                response.Data = _mapper.Map<ViewClaimDTO>(viewClaim);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("A user was consulted!" + $"{viewClaimById}");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ COMMUNICATIONS HISTORY METHODS ]
        /// <summary>
        /// Insert Communications History
        /// </summary>
        /// <param name="communicationsHistoryDTO"></param>
        /// <returns> Communication </returns>
        public async Task<Response<bool>> InsertCommunicationsHistoryAsync(CommunicationsHistoryDTO communicationsHistoryDTO)
        {
            var response = new Response<bool>();

            try
            {
                var communicationHistory = _mapper.Map<CommunicationsHistory>(communicationsHistoryDTO);
                response.Data = await _declareVehicleAccidentDomain.InsertCommunicationsHistoryAsync(communicationHistory);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ INVESTIGATION RECORD METHODS ]
        /// <summary>
        /// Insert Investigation
        /// </summary>
        /// <param name="investigationRecordDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> InsertInvestigationRecordAsync(InvestigationRecordDTO investigationRecordDTO)
        {
            var response = new Response<bool>();

            try
            {
                var investigation = _mapper.Map<InvestigationRecord>(investigationRecordDTO);
                response.Data = await _declareVehicleAccidentDomain.InsertInvestigationRecordAsync(investigation);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ METHODS ORGANISM ] 
        /// <summary>
        /// Insert Organism
        /// </summary>
        /// <param name="organismDTO"></param>
        /// <returns></returns>
        public async Task<Response<bool>> InsertOrganismAsync(OrganismDTO organismDTO)
        {
            var response = new Response<bool>();

            try
            {
                var organism = _mapper.Map<Organism>(organismDTO);
                response.Data = await _declareVehicleAccidentDomain.InsertOrganismAsync(organism);

                if (response.Data)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful registration";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion


        #region [ INSURER METHODS ]
        /// <summary>
        /// Get Insurer By Country
        /// </summary>
        /// <param name="insurerByCountryId"></param>
        /// <returns></returns>
        public async Task<Response<IEnumerable<InsurerByCountryDTO>>> GetInsurerByCountryIdAsync(string insurerByCountryId)
        {
            var response = new Response<IEnumerable<InsurerByCountryDTO>>();

            try
            {

                var insurerByCountry = await _declareVehicleAccidentDomain.GetInsurerByCountryIdAsync(insurerByCountryId);
                response.Data = _mapper.Map<IEnumerable<InsurerByCountryDTO>>(insurerByCountry);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }


        #endregion


        #region [ CLAIMS MANAGER METHODS ]
        /// <summary>
        /// Get All Claims Manager
        /// </summary>
        /// <returns> Claims Manager </returns>
        public async Task<Response<IEnumerable<GetAllClaimsManagerDTO>>> GetAllClaimsManagerAsync()
        {
            var response = new Response<IEnumerable<GetAllClaimsManagerDTO>>();

            try
            {

                var claimsManager = await _declareVehicleAccidentDomain.GetAllClaimsManagerAsync();
                response.Data = _mapper.Map<IEnumerable<GetAllClaimsManagerDTO>>(claimsManager);


                if (response.Data != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                    _logger.LogInformation("Succesful query!");
                }
            }
            catch (Exception e)
            {

                response.Message = e.Message;
                _logger.LogError(e.Message);
            }

            return response;
        }
        #endregion

        #endregion
    }
}
