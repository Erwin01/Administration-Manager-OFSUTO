﻿using System.Linq;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using System.IO;
using Syntax.Ofesauto.ClaimsManager.Transversal.EmailService.Interface;
using Microsoft.AspNetCore.Http;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main
{
    public class ActionHistoryApplication : IActionsHistoryApplication
    {
        private readonly IActionsHistoryDomain _repository;
        private readonly ISettingsApplication _setting;
        private readonly IActionTypeApplication _actionType;
        private readonly ICommunicationsHistoryApplication _CommunicationHis;
        private readonly ICommunicationAttachmentsApplication _CommunicationAttch;
        private readonly IUserApplication _IUserApplication;
        private readonly IFileHandlerApplication _fileHandler;
        private readonly IMailService _mailService;
        private readonly IAppLogger<ActionHistoryApplication> _logger;
        public ActionHistoryApplication(IActionsHistoryDomain repository, ISettingsApplication setting, 
                                        IActionTypeApplication actionType,  
                                        ICommunicationsHistoryApplication CommunicationHis, ICommunicationAttachmentsApplication CommunicationAttch, 
                                        IFileHandlerApplication fileHandler,IAppLogger<ActionHistoryApplication> appLogger,
                                        IMailService mailService, IUserApplication userApplication
            )
        {
            _repository = repository;
            _logger = appLogger;
            _setting = setting;
            _actionType = actionType;
            _fileHandler = fileHandler;
            _CommunicationHis = CommunicationHis;
            _CommunicationAttch = CommunicationAttch;
            _mailService = mailService;
            _IUserApplication = userApplication;
        }

        public async Task<Response<ActionsHistoryDTO>> Add(ActionsHistoryDTO obj)
        {           
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<ActionsHistoryDTO, ActionsHistory>.Convert(obj);
                var add = await _repository.Add(mapp);
                var success = false;
                obj.ActionHistoryId = add.ActionHistoryId;
                var action = await _actionType.GetById(obj.ActionTypeId);
                if (action.Data.SendCommunication)
                {
                    var subject = string.Empty;
                    var textNewClaim = string.Empty;
                    var templateEmailNewClaim = string.Empty;
                    var fromEmail = string.Empty;
                    var titleEmail = string.Empty;
                    
                    if (obj.FirstTime.Value)
                    {
                        var setting = await _setting.GetByNameSetting("SubjectNewClaim");
                        subject = $"{setting.Data.Value} REC-{obj.IdentificationRegister}";
                        setting = await _setting.GetByNameSetting("TextNewClaim");
                        textNewClaim = setting.Data.Value;                                   
                        setting = await _setting.GetByNameSetting("titleEmailNewClaim");
                        titleEmail = setting.Data.Value;
                        textNewClaim = textNewClaim.Replace("@email", obj.EmailSender);
                        textNewClaim = textNewClaim.Replace("@referencia", obj.Referencia.ToString());
                    }
                    else
                    {
                        titleEmail = obj.SubjectCommunication;
                        subject = obj.SubjectCommunication;
                        textNewClaim = obj.Message;
                    }
                    var setting1 = await _setting.GetByNameSetting("TemplateEmailNewClaim");
                    templateEmailNewClaim = setting1.Data.Value;
                    setting1 = await _setting.GetByNameSetting("FromEmail");
                    fromEmail = setting1.Data.Value;
                    var template = string.Empty;
                    using (StreamReader reader = new StreamReader(templateEmailNewClaim))
                    {
                        template = reader.ReadToEnd();
                    }
                   
                    template = template.Replace("@tittle", titleEmail);
                    template = template.Replace("@textContent", textNewClaim);
                    var communicationHistory = new CommunicationsHistoryDTO(obj.ActionHistoryId, obj.EmailSender, subject, textNewClaim, templateEmailNewClaim, fromEmail);
                    var result = await _CommunicationHis.Add(communicationHistory);
                    var listAttach = new List<CommunicationAttachmentsDTO>();
                    var listAttachSend = new List<IFormFile>();
                    if (result.Data.CommunicationId > 0)
                    {
                        if (obj.Files != null)
                        {
                            if (obj.Files.Count > 0)
                            {
                                var files = await _fileHandler.SaveAllFiles(obj.Files);
                                var i = 1;
                                foreach (var file in files.Data)
                                {
                                    if (file.file != null)
                                    {
                                        listAttachSend.Add(file.file);
                                        listAttach.Add(new CommunicationAttachmentsDTO { AttachmentId = i, CommunicationsHistoryId = result.Data.CommunicationId, AttachmentDate = DateTime.Now, AttachmentFileName = file.fileName, AttachmentPath = file.SavePath, CreateDate = DateTime.Now, UpdateDate = DateTime.Now });
                                        i++;
                                    }
                                    _logger.LogInformation($"Guardando archivos {file.fileName}");
                                }
                                var commAttachResponse = await _CommunicationAttch.AddList(listAttach);
                                if (commAttachResponse.IsSuccess)
                                {
                                    _logger.LogInformation($"Exito al guardar archivos {commAttachResponse.Message}");
                                }
                                else
                                {
                                    _logger.LogInformation($" Error guardando archivos {commAttachResponse.Message}");
                                }
                            }
                        }
                        await _mailService.SendEmailAsync(new Transversal.EmailService.MailRequest { Body= template, Subject = subject, ToEmail = obj.EmailSender, Attachments= listAttachSend });
                        success = true;
                    }
                }
                return Response<ActionsHistoryDTO>.Sucess(obj, "Success", success);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<ActionsHistoryDTO>.Error(null, ex,"Ha ocurrido un error", false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.ActionHistoryId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);
              
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<ActionsHistoryDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<ActionsHistory, ActionsHistoryDTO>.ConvertList2(ListData);
                return Response<List<ActionsHistoryDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<ActionsHistoryDTO>>.Sucess(null, ex.Message, false);
            }
        }
       
        public async Task<Response<ActionsHistoryDTO>> GetById(int id)
        {
            Response<ActionsHistoryDTO> ListRta = new Response<ActionsHistoryDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<ActionsHistory, ActionsHistoryDTO>.Convert(ListData);
                return Response<ActionsHistoryDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<ActionsHistoryDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<ActionsHistoryDTO>>> GetByParam(Func<ActionsHistoryDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<Response<ActionsHistoryDTO>> GetByParamFirst(Func<ActionsHistoryDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<ActionsHistoryDTO>> Update(ActionsHistoryDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<ActionsHistoryDTO, ActionsHistory>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<ActionsHistoryDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<ActionsHistoryDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
