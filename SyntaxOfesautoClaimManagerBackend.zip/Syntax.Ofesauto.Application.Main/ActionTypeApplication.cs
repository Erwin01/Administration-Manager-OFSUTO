﻿using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main
{
    public class ActionTypeApplication : IActionTypeApplication
    {
        private readonly IActionTypeDomain _repository;
        private readonly IAppLogger<ActionTypeApplication> _logger;
        public ActionTypeApplication(IActionTypeDomain repository,
            IAppLogger<ActionTypeApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<ActionTypeDTO>> Add(ActionTypeDTO obj)
        {           
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<ActionTypeDTO, ActionType>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.ActionTypeId = add.ActionTypeId;
                return Response<ActionTypeDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<ActionTypeDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.ActionTypeId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);
              
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<ActionTypeDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<ActionType, ActionTypeDTO>.ConvertList2(ListData);
                return Response<List<ActionTypeDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<ActionTypeDTO>>.Sucess(null, ex.Message, false);
            }
        }
       
        public async Task<Response<ActionTypeDTO>> GetById(int id)
        {
            Response<ActionTypeDTO> ListRta = new Response<ActionTypeDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<ActionType, ActionTypeDTO>.Convert(ListData);
                return Response<ActionTypeDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<ActionTypeDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<ActionTypeDTO>>> GetByParam(Func<ActionTypeDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<Response<ActionTypeDTO>> GetByParamFirst(Func<ActionTypeDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<ActionTypeDTO>> Update(ActionTypeDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<ActionTypeDTO, ActionType>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<ActionTypeDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<ActionTypeDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
