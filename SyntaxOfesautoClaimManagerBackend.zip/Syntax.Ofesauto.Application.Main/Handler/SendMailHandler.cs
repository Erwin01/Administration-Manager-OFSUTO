﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
namespace Syntax.Ofesauto.ClaimsManager.Application.Main.Handler
{
    public class SendMailHandler
    {
        public void SendMail(string body, List<Attachment> attachment)
        {

        }
        
    }
}
