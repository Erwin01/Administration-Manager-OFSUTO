﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Hosting;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main.Handler
{

    public class FileUploadHandler: IFileUploadApplication
    {
        private readonly IAppLogger<FileUploadHandler> _logger;
        private readonly ILogDomain _logRepository;
        public FileUploadHandler(ILogDomain logRepository)
        {
            _logRepository = logRepository;
        }
        public async Task<Response<string>> Upload(IFormFile file, string path)
        {
            try
            {
                
                string ext = Path.GetExtension(file.FileName);
                var filename = $"{Guid.NewGuid().ToString()}{ext}";
                var filePath = Path.Combine(path, filename);
         
               
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), filePath);
           

                if (file.Length > 0)
                {
                    //if (file.AllowedExtensions.FirstOrDefault(c => c.ToLower() == ext.ToLower()) != null)
                    //{
                   
                    using (var stream = new FileStream(pathToSave, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                            return Response<string>.Sucess(filename, $"Archivo {file.FileName} guardado en el servidor", true);
                        }
                    //}
                    //return Response<string>.Sucess(string.Empty, $"Error subiendo el archivo {file.FileName} al servidor, extension no permitida", false);
                }
                return Response<string>.Sucess(string.Empty, $"Error subiendo el archivo {file.FileName} al servidor", false);
            }
            catch (Exception ex)
            {
               await _logRepository.Add(new Domain.Entity.IssuesLog
               {
                   CreatedOnDate = DateTime.Now,
                   Description = $"Message: {ex.Message} Stacktrace: {ex.StackTrace} Inner: {ex.InnerException}",
                   Source = "ResultData",
                   Type = ex.GetType().ToString()
               });
                return Response<string>.Error(string.Empty,  ex,$"Error subiendo el archivo {file.FileName} al servidor {ex.Message}", false);
            }
        }

    }
}
