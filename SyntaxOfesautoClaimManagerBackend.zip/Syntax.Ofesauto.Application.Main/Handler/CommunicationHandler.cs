﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main.Handler
{
    public class CommunicationHandler
    {

    }
}
