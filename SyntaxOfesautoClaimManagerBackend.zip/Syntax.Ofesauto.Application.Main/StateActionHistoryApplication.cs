﻿using System.Linq;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main
{
    public class StateActionHistoryApplication : IStateActionHistoryApplication
    {
        private readonly IStateActionHistoryDomain _repository;
        private readonly IAppLogger<StateActionHistoryApplication> _logger;
        public StateActionHistoryApplication(IStateActionHistoryDomain repository,
            IAppLogger<StateActionHistoryApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<StateActionHistoryDTO>> Add(StateActionHistoryDTO obj)
        {           
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<StateActionHistoryDTO, StateActionHistory>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.StateId = add.StateId;
                return Response<StateActionHistoryDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<StateActionHistoryDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {
                var add = await _repository.GetById(id);
                if (add.StateId > 0)
                {
                    await _repository.Delete(id);
                    return Response<bool>.Sucess(true, "Success", true);
                }
                else
                    return Response<bool>.Sucess(false, "Not found", false);
              
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<bool>.Sucess(false, ex.Message, false);
            }
        }

        public async Task<Response<List<StateActionHistoryDTO>>> GetAll()
        {
            try
            {
                var ListData = await _repository.GetAll();
                var mapp = Infraestructure.Data.AutoMapp<StateActionHistory, StateActionHistoryDTO>.ConvertList2(ListData);
                return Response<List<StateActionHistoryDTO>>.Sucess(mapp, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<List<StateActionHistoryDTO>>.Sucess(null, ex.Message, false);
            }
        }
       
        public async Task<Response<StateActionHistoryDTO>> GetById(int id)
        {
            Response<StateActionHistoryDTO> ListRta = new Response<StateActionHistoryDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<StateActionHistory, StateActionHistoryDTO>.Convert(ListData);
                return Response<StateActionHistoryDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<StateActionHistoryDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<StateActionHistoryDTO>> GetByNameStateActionHistory(string name)
        {
            Response<StateActionHistoryDTO> ListRta = new Response<StateActionHistoryDTO>();
            try
            {

                var ListData = await _repository.GetByParamFirst(c => c.StateName == name);
                ListRta.Data = Infraestructure.Data.AutoMapp<StateActionHistory, StateActionHistoryDTO>.Convert(ListData);
                return Response<StateActionHistoryDTO>.Sucess(ListRta.Data, "Success", true);
            }
            catch (Exception ex)
            {
                return Response<StateActionHistoryDTO>.Sucess(null, ex.Message, false);
            }
        }

        public async Task<Response<List<StateActionHistoryDTO>>> GetByParam(Func<StateActionHistoryDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

      

        public async Task<Response<StateActionHistoryDTO>> Update(StateActionHistoryDTO obj, int id)
        {
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<StateActionHistoryDTO, StateActionHistory>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                return Response<StateActionHistoryDTO>.Sucess(obj, "Success", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Response<StateActionHistoryDTO>.Sucess(null, ex.Message, false);
            }
        }
    }
}
