﻿using System.Linq;
using Syntax.Ofesauto.ClaimsManager.Application.DTO;
using Syntax.Ofesauto.ClaimsManager.Domain.Entity;
using Syntax.Ofesauto.ClaimsManager.Domain.Interface;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Data;
using Syntax.Ofesauto.ClaimsManager.Infraestructure.Interface;
using Syntax.Ofesauto.ClaimsManager.Transversal.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Syntax.Ofesauto.ClaimsManager.Application.Interface;

namespace Syntax.Ofesauto.ClaimsManager.Application.Main
{
    public class CommunicationsHistoryApplication : ICommunicationsHistoryApplication
    {
        private readonly ICommunicationsHistoryDomain _repository;
        private readonly IAppLogger<CommunicationsHistoryApplication> _logger;
        public CommunicationsHistoryApplication(ICommunicationsHistoryDomain repository,
            IAppLogger<CommunicationsHistoryApplication> appLogger
            )
        {
            _repository = repository;
            _logger = appLogger;
        }

        public async Task<Response<CommunicationsHistoryDTO>> Add(CommunicationsHistoryDTO obj)
        {
            var response = new Response<CommunicationsHistoryDTO>();
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<CommunicationsHistoryDTO, CommunicationsHistory>.Convert(obj);
                var add = await _repository.Add(mapp);

                obj.CommunicationId = add.CommunicationId;
                return Response<CommunicationsHistoryDTO>.Sucess(obj,"Success", true);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
                _logger.LogError(ex.Message);
                return response;
            }
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();
            try
            {

                var add = await _repository.GetById(id);

                if (add.ActionHistoryId > 0)
                {
                    await _repository.Delete(id);
                    response.IsSuccess = true;
                    response.Message = "Successful query";
                }
                else
                    response.Message = "Not found";
                return response;
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
                _logger.LogError(ex.Message);
                return response;
            }
        }

        public async Task<Response<List<CommunicationsHistoryDTO>>> GetAll()
        {
            Response<List<CommunicationsHistoryDTO>> ListRta = new Response<List<CommunicationsHistoryDTO>>();
            try
            {
                var ListData = await _repository.GetAll();
                ListRta.Data = Infraestructure.Data.AutoMapp<CommunicationsHistory, CommunicationsHistoryDTO>.ConvertList2(ListData);
                ListRta.Message = "Success query";
                ListRta.IsSuccess = true;
                return ListRta;
            }
            catch (Exception ex)
            {
                ListRta.Message = ex.Message;
                ListRta.IsSuccess = false;
                return ListRta;
            }
        }

    
        public async Task<Response<CommunicationsHistoryDTO>> GetById(int id)
        {
            Response<CommunicationsHistoryDTO> ListRta = new Response<CommunicationsHistoryDTO>();
            try
            {
                var ListData = await _repository.GetById(id);
                ListRta.Data = Infraestructure.Data.AutoMapp<CommunicationsHistory, CommunicationsHistoryDTO>.Convert(ListData);
                ListRta.Message = "Success query";
                ListRta.IsSuccess = true;
                return ListRta;
            }
            catch (Exception ex)
            {
                ListRta.Message = ex.Message;
                ListRta.IsSuccess = false;
                return ListRta;
            }
        }

        public Task<Response<List<CommunicationsHistoryDTO>>> GetByParam(Func<CommunicationsHistoryDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public Task<Response<CommunicationsHistoryDTO>> GetByParamFirst(Func<CommunicationsHistoryDTO, bool> pre)
        {
            throw new NotImplementedException();
        }

        public async Task<Response<CommunicationsHistoryDTO>> Update(CommunicationsHistoryDTO obj, int id)
        {
            var response = new Response<CommunicationsHistoryDTO>();
            try
            {
                var mapp = Infraestructure.Data.AutoMapp<CommunicationsHistoryDTO, CommunicationsHistory>.Convert(obj);
                var add = await _repository.Update(mapp, id);
                response.Data = obj;
                response.IsSuccess = true;
                response.Message = "Successful query";
                return response;
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
                _logger.LogError(ex.Message);
                return response;
            }
        }
    }
}
